/*!
 * Website Doctor — Dashboard Update tab (GitHub auto-update UI + orchestration).
 * Requires wd-updater.js (WDUpdater) to be loaded first.
 */
(function () {
  "use strict";
  if (!window.WDUpdater) { console.warn("[Website Doctor] WDUpdater not loaded; Update tab disabled."); return; }
  var U = window.WDUpdater;
  var $ = function (id) { return document.getElementById(id); };
  var DB_NAME = "wdUpdateDB";
  var STORE = "kv";
  var RECHECK_MS = 30 * 60 * 1000;

  var S = {
    permission: "unknown",       // "granted" | "prompt" | "none" | "unknown"
    handle: null,                // FileSystemDirectoryHandle
    connectedName: null,
    autoEnabled: false,
    checking: false,
    update: null,                // {tag, sha, notes} when a newer release exists
    busy: false,
    cancelled: false,
    lastStatus: "Ready.",
    lastCheck: 0
  };

  // ------------------------------------------------------------ storage
  function dbOpen() {
    return new Promise(function (res, rej) {
      try {
        var r = indexedDB.open(DB_NAME, 1);
        r.onupgradeneeded = function () { try { r.result.createObjectStore(STORE); } catch (e) {} };
        r.onsuccess = function () { res(r.result); };
        r.onerror = function () { rej(r.error || new Error("db open failed")); };
      } catch (e) { rej(e); }
    });
  }
  function dbGet(key) {
    return dbOpen().then(function (db) {
      return new Promise(function (res, rej) {
        try {
          var tx = db.transaction(STORE, "readonly");
          var req = tx.objectStore(STORE).get(key);
          req.onsuccess = function () { db.close(); res(req.result === undefined ? null : req.result); };
          req.onerror = function () { db.close(); rej(req.error); };
        } catch (e) { rej(e); }
      });
    }).catch(function () { return null; });
  }
  function dbSet(key, val) {
    return dbOpen().then(function (db) {
      return new Promise(function (res) {
        try {
          var tx = db.transaction(STORE, "readwrite");
          tx.objectStore(STORE).put(val, key);
          tx.oncomplete = function () { db.close(); res(true); };
          tx.onerror = function () { db.close(); res(false); };
        } catch (e) { res(false); }
      });
    });
  }
  function dbDel(key) {
    return dbOpen().then(function (db) {
      try {
        var tx = db.transaction(STORE, "readwrite");
        tx.objectStore(STORE).delete(key);
        tx.oncomplete = function () { db.close(); };
      } catch (e) {}
    }).catch(function () {});
  }

  // ------------------------------------------------------------ ui helpers
  function status(msg, kind) {
    S.lastStatus = msg;
    var el = $("wdUpStatus");
    if (el) {
      el.textContent = msg;
      el.setAttribute("data-kind", kind || "info");
    }
  }
  function setBusy(b) {
    S.busy = b;
    ["wdUpCheck", "wdUpInstall", "wdUpAuto", "wdUpChange", "wdUpDisconnect", "wdUpRestore"].forEach(function (id) {
      var el = $(id); if (el) el.disabled = b;
    });
  }
  function isUpdateHbdEnabled() { return S.autoEnabled; }

  function ensureSection() {
    var panels = $("dashPanels");
    if (!panels || $("section-update")) return;
    var sec = document.createElement("section");
    sec.id = "section-update";
    sec.className = "dash-section";
    sec.setAttribute("data-section", "update");
    sec.hidden = true;
    sec.innerHTML =
      '<div class="dash-section-head"><h2>' +
      '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v10"/><path d="m7 10 5 5 5-5"/><path d="M4 19h16"/></svg>' +
      'Update</h2><p>Keep Website Doctor current from GitHub. Enabled auto-update downloads and installs new releases to your extension folder automatically, with a backup and a safety check on every step.</p></div>' +
      '<div class="card" style="margin-bottom:18px"><h3 class="card-title">Status</h3>' +
      '<div class="stat-row" style="gap:12px"><span class="stat-row-label">Installed</span><span class="stat-row-value" id="wdUpCurrent">v\u2026</span></div>' +
      '<div class="stat-row" style="gap:12px"><span class="stat-row-label">Latest on GitHub</span><span class="stat-row-value" id="wdUpLatest">checking\u2026</span></div>' +
      '<div class="stat-row" style="gap:12px"><span class="stat-row-label">Extension folder</span><span class="stat-row-value" id="wdUpFolder">not connected</span></div>' +
      '<div class="stat-row" style="gap:12px"><span class="stat-row-label">Last check</span><span class="stat-row-value" id="wdUpCheckedAt">\u2014</span></div>' +
      '<div class="wd-up-status" id="wdUpStatus" data-kind="info">Ready.</div>' +
      '</div>' +
      '<div class="card" style="margin-bottom:18px"><h3 class="card-title">Auto-update</h3>' +
      '<div class="wd-up-auto-row">' +
      '<label class="wd-up-switch">' +
      '<input type="checkbox" id="wdUpAuto">' +
      '<span class="wd-up-slider"></span>' +
      '<span class="wd-up-switch-label"><b>Auto-update from GitHub</b><br>' +
      '<small>When a new release appears, download it, back up your current copy and install it with one click \u2014 or fully automatically when the folder is connected.</small></span>' +
      '</label>' +
      '</div></div>' +
      '<div class="card" style="margin-bottom:18px"><h3 class="card-title">Actions</h3>' +
      '<div class="wd-up-actions">' +
      '<button id="wdUpConnect" class="dash-btn dash-btn-primary" type="button">Connect extension folder</button>' +
      '<button id="wdUpChange" class="dash-btn" type="button" hidden>Change folder</button>' +
      '<button id="wdUpReconnect" class="dash-btn" type="button" hidden>Reconnect folder (allow)</button>' +
      '<button id="wdUpDisconnect" class="dash-btn" type="button" hidden>Disconnect</button>' +
      '<button id="wdUpCheck" class="dash-btn" type="button">Check now</button>' +
      '<button id="wdUpInstall" class="dash-btn dash-btn-primary" type="button" hidden>Update now</button>' +
      '<button id="wdUpPickFile" class="dash-btn" type="button">Install from file\u2026</button>' +
      '<input id="wdUpFileInput" type="file" accept=".zip,application/zip" style="display:none">' +
      '</div>' +
      '<p class="wd-up-hint">Auto-update needs access to your extension folder. Choose the folder you loaded at <b>chrome://extensions</b> (for example <code>webdeve-unpacked</code>). You choose it once; it is saved in the browser.</p>' +
      '</div>' +
      '<div class="card"><h3 class="card-title">Safety &amp; restore</h3>' +
      '<p style="color:var(--muted);font-size:12.5px;line-height:1.6;margin:-3px 0 10px">Every update first <b>verifies the package</b>, then <b>backs up your current version</b> into the browser, then installs <b>file by file</b> and re-checks every file. If anything fails, the previous version is restored automatically. Backups are also on disk in your project\u2019s <code>backups</code> folder if you used the PowerShell script.</p>' +
      '<button id="wdUpRestore" class="dash-btn" type="button" hidden>Restore pre-update backup</button>' +
      '<span id="wdUpBackupInfo" class="wd-up-backup-info"></span>' +
      '</div>';
    var main = document.querySelector(".dash-main");
    (main || $("dashPanels") || document.body).appendChild(sec);
  }

  function updateNavBtn() { return document.querySelector('#dashNav [data-sec="update"]'); }

  // ------------------------------------------------------------ banner
  function setBadge() {
    var btn = updateNavBtn();
    if (btn) {
      var existing = btn.querySelector(".dash-nav-count");
      if (existing) existing.parentNode.removeChild(existing);
      if (S.update && !S.busy) {
        var span = document.createElement("span");
        span.className = "dash-nav-count red";
        span.textContent = "1";
        btn.appendChild(span);
      }
    }
    var pill = $("dashUpdate");
    if (pill && S.update) {
      pill.setAttribute("data-state", "available");
      var txt = $("dashUpdateText");
      if (txt) txt.textContent = "Update " + S.update.tag + " available";
    }
  }
  function banner() {
    var b = $("dashUpdateBanner");
    if (!b) {
      b = document.createElement("div");
      b.id = "dashUpdateBanner";
      b.className = "wd-up-banner";
      b.hidden = true;
      var main = document.querySelector(".dash-main") || $("dashPanels");
      if (main) main.insertBefore(b, main.firstChild);
    }
    if (!S.update) { b.hidden = true; b.innerHTML = ""; return; }
    var tag = S.update.tag;
    var canAuto = S.autoEnabled && S.handle;
    b.hidden = false;
    b.innerHTML =
      '<svg class="wd-up-banner-ico" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l2.5 4.5L19 8l-4 3.5 1 5-4-2.5L8 16.5l1-5L5 8l4.5-.5L12 3z"/></svg>' +
      '<div class="wd-up-banner-txt"><b>Website Doctor ' + U.normTag(tag) + ' is available</b><span>' +
      (canAuto ? "Auto-update is on \u2014 the update will be installed to your extension folder automatically." : "Open the Update tab to enable auto-update or update now.") +
      '</span></div>' +
      '<div class="wd-up-banner-actions">' +
      '<button class="dash-btn dash-btn-primary" type="button" data-wd-up="open">Update tab</button>' +
      (canAuto ? "" : '<button class="dash-btn" type="button" data-wd-up="install">Update now</button>') +
      '</div>';
  }

  // header pill state used at init and in check()
  function setPill(state, text, title) {
    var p = $("dashUpdate");
    if (p) { p.setAttribute("data-state", state); p.title = title || text; }
    var t = $("dashUpdateText");
    if (t) t.textContent = text;
  }

  // ------------------------------------------------------------ check
  function check(force) {
    if (S.checking) return;
    S.checking = true;
    if (force) {
      try { chrome.runtime.sendMessage({ action: "checkUpdate", force: true }, function () {}); } catch (e) {}
    }
    var btn = $("wdUpCheck"); if (btn) btn.disabled = true;
    status("Checking GitHub for updates\u2026", "info");
    setPill("checking", "Checking for updates…", "Looking on GitHub for a newer version.");
    chrome.runtime.sendMessage({ action: "checkUpdate", force: !!force }, function (res) {
      S.checking = false; if (btn) btn.disabled = false;
      if (chrome.runtime.lastError) {
        status("Update check failed: " + chrome.runtime.lastError.message, "error");
        setPill("error", "Update check failed", "Could not reach the background checker. Click to retry.");
        return;
      }
      S.lastCheck = Date.now();
      var at = $("wdUpCheckedAt"); if (at) at.textContent = new Date().toLocaleTimeString();
      if (!res || !res.ok) {
        status("Update check failed.", "error");
        setPill("error", "Update check failed", (res && res.error) || "Click to retry.");
        return;
      }
      var cur = $("wdUpCurrent"); if (cur) cur.textContent = "v" + res.current;
      var lat = $("wdUpLatest");
      if (res.latest) { if (lat) lat.textContent = res.latest.replace(/^v/, "v"); }
      else if (lat) lat.textContent = "unknown (offline?)";
      if (res.update && res.latest) {
        U.fetchLatestTag().then(function (t) {
          S.update = t ? { tag: t.tag, sha: t.sha, notes: "" } : { tag: res.latest, sha: null, notes: "" };
          if (S.update.sha) U.fetchNotes(S.update.sha).then(function (n) { S.update.notes = n; });
          setBadge(); banner(); syncUI();
          setPill("available", "Update " + res.latest + " available", "Latest version: " + res.latest + ". Click to open the Update tab.");
          if (S.autoEnabled && S.handle) {
            status(res.latest + " found. Auto-update is on \u2014 installing\u2026", "ok");
            setTimeout(function () { if (S.autoEnabled && S.handle && S.update && !S.busy) doUpdate(); }, 1200);
          } else {
            status(res.latest + " is available \u2014 auto-update is " + (S.autoEnabled ? "on but the folder is not connected yet." : "off."), "ok");
          }
        }).catch(function () {
          S.update = { tag: res.latest, sha: null, notes: "" }; setBadge(); banner(); syncUI();
          setPill("available", "Update " + res.latest + " available", "Latest version: " + res.latest);
        });
      } else {
        S.update = null; setBadge(); banner();
        status("You are on the latest version (v" + res.current + ").", "ok");
        setPill("current", "Up to date", "You are running v" + res.current + ". Click to check again.");
      }
    });
  }

  // ------------------------------------------------------------ folder
  function permissionText() {
    if (S.permission === "granted") return "connected";
    if (S.permission === "prompt") return "needs permission \u2014 click Reconnect folder";
    return "not connected";
  }
  function syncUI() {
    var f = $("wdUpFolder"); if (f) f.textContent = S.connectedName ? S.connectedName + " (" + permissionText() + ")" : permissionText();
    var t = $("wdUpAuto"); if (t) t.checked = S.autoEnabled;
    var hasConn = !!(S.handle && S.permission !== "none");
    var recon = $("wdUpReconnect"), chg = $("wdUpChange"), disc = $("wdUpDisconnect"), con = $("wdUpConnect");
    if (recon) recon.hidden = S.permission !== "prompt";
    if (chg) chg.hidden = !S.handle;
    if (disc) disc.hidden = !S.handle;
    if (con) con.hidden = !!S.handle && S.permission !== "none";
    var inst = $("wdUpInstall"); if (inst) inst.hidden = !(S.update && hasConn);
    var rb = $("wdUpRestore");
    dbGet("wdUpdateBackup").then(function (b) {
      if (rb) rb.hidden = !b;
      var bi = $("wdUpBackupInfo");
      if (bi) bi.textContent = b && b.version && b.when ? ("Pre-update backup from " + new Date(b.when).toLocaleString() + " (v" + b.version + ") ready.") : (b ? "Pre-update backup ready." : "");
    });
  }

  function ownFileForVerify() {
    return fetch("background.js", { cache: "no-store" })
      .then(function (r) {
        if (!r.ok) return null;
        return r.arrayBuffer().then(function (ab) { return { path: "background.js", bytes: new Uint8Array(ab) }; });
      })
      .catch(function () { return null; });
  }

  function connect() {
    if (!window.showDirectoryPicker) {
      status("This Chrome build does not expose the folder picker API. Load a current Chrome build.", "error");
      return;
    }
    window.showDirectoryPicker({ mode: "readwrite", id: "website-doctor-folder" })
      .then(function (h) {
        return ownFileForVerify().then(function (own) {
          return U.verifyFolder(h, { name: chrome.runtime.getManifest().name, version: chrome.runtime.getManifest().version, ownFile: own })
            .then(function (v) {
              if (!v.ok) { status(v.error, "error"); return null; }
              S.handle = h; S.connectedName = h.name; S.permission = "granted";
              return dbSet("wdFolderHandle", h).then(function () {
                status("Folder \u201C" + h.name + "\u201D connected. Auto-update can now install releases there.", "ok");
                syncUI(); banner();
                return h;
              });
            });
        });
      })
      .catch(function (e) {
        if (e && e.name === "AbortError") { status("Folder selection was cancelled.", "info"); return; }
        status("Could not connect the folder: " + ((e && e.message) || e), "error");
      });
  }

  function reconnect(interactive) {
    if (!S.handle) { connect(); return; }
    var h = S.handle;
    var ask = function () {
      return h.requestPermission({ mode: "readwrite" }).then(function (p) {
        S.permission = p;
        if (p === "granted") status("Folder permission granted.", "ok");
        else status("Folder permission not granted \u2014 click Reconnect again and allow access.", "error");
        syncUI(); banner();
      });
    };
    h.queryPermission({ mode: "readwrite" }).then(function (p) {
      if (p === "granted") { S.permission = "granted"; status("Folder permission is granted.", "ok"); syncUI(); banner(); return; }
      S.permission = "prompt"; syncUI();
      if (interactive) return ask();
    }).catch(function () {
      S.permission = "prompt"; syncUI(); if (interactive) ask();
    });
  }

  // ------------------------------------------------------------ update
  function doUpdate() {
    if (S.busy || S.checking) return;
    if (!S.update) { status("No update to install.", "info"); return; }
    if (!S.handle) { status("Connect your extension folder first (Update tab \u2192 Connect extension folder).", "error"); return; }
    if (S.permission !== "granted") { reconnect(true); return; }
    setBusy(true); S.cancelled = false;
    var tag = S.update.tag.replace(/^v/i, "v");
    status("Downloading " + tag + " from GitHub\u2026", "info");
    U.fetchPackage(tag, null, function (p) { status("Downloading " + tag + " (" + p.url.split("/")[2] + ")\u2026", "info"); })
      .then(function (pkg) {
        if (S.cancelled) throw cancelError();
        var v = U.validatePackage(pkg.files, { currentVersion: chrome.runtime.getManifest().version, expectedVersion: tag });
        if (!v.ok) throw new Error("Update package is not valid: " + v.errors.join(" "));
        status("Package verified (v" + v.version + ", " + v.fileCount + " files, " + Math.round(v.totalBytes / 1024) + " KB). Backing up\u2026", "info");
        return U.install({
          dir: S.handle,
          files: pkg.files,
          onStep: function (name, info) {
            if (name === "backup") status("Backing up your current version\u2026", "info");
            else if (name === "install") status("Installing" + (info && info.done != null ? " " + info.done + "/" + info.total : "\u2026"), "info");
            else if (name === "verify") status("Verifying every installed file\u2026", "info");
            else if (name === "rollback") status("A write failed \u2014 restoring your previous version\u2026", "error");
          },
          saveBackup: async function (snapshot) {
            var zip = U.writeZip(snapshot);
            await dbSet("wdUpdateBackup", { zip: zip, version: chrome.runtime.getManifest().version, when: Date.now(), tag: tag });
          }
        }).then(function (res) {
          S.update = null; setBadge(); banner();
          return dbSet("wdJustUpdated", { to: v.version, at: Date.now() }).then(function () {
            status("Updated to v" + v.version + " (" + res.files + " files). Reloading the extension\u2026", "ok");
            setTimeout(function () { try { chrome.runtime.reload(); } catch (e) {} }, 1400);
          });
        });
      })
      .catch(function (e) {
        setBusy(false);
        if (S.cancelled) { status("Update cancelled.", "info"); return; }
        status(((e && e.message) || String(e)), "error");
        if (e.rolledBack === false || e.rollbackErrors) status(e.message, "error");
        syncUI();
      })
      .then(function () { setBusy(false); syncUI(); });
  }
  function cancelError() { var e = new Error("cancelled"); e.cancelled = true; return e; }

  // Install a package the user picked from disk (manual update path).
  function installFromFile(file) {
    if (S.busy || S.checking) return;
    if (!S.handle) { status("Connect your extension folder first (Update tab \u2192 Connect extension folder).", "error"); return; }
    if (S.permission !== "granted") { reconnect(true); return; }
    setBusy(true);
    status("Reading " + file.name + "\u2026", "info");
    file.arrayBuffer()
      .then(function (ab) { return U.readZip(ab).then(function (files) { return U.locateExtension(files); }); })
      .then(function (files) {
        var v = U.validatePackage(files, { currentVersion: chrome.runtime.getManifest().version });
        if (!v.ok) throw new Error("Package is not valid: " + v.errors.join(" "));
        status("Package verified (v" + v.version + ", " + v.fileCount + " files, " + Math.round(v.totalBytes / 1024) + " KB). Backing up\u2026", "info");
        return U.install({
          dir: S.handle,
          files: files,
          onStep: function (name, info) {
            if (name === "backup") status("Backing up your current version\u2026", "info");
            else if (name === "install") status("Installing" + (info && info.done != null ? " " + info.done + "/" + info.total : "\u2026"), "info");
            else if (name === "verify") status("Verifying every installed file\u2026", "info");
            else if (name === "rollback") status("A write failed \u2014 restoring your previous version\u2026", "error");
          },
          saveBackup: async function (snapshot) {
            var zip = U.writeZip(snapshot);
            await dbSet("wdUpdateBackup", { zip: zip, version: chrome.runtime.getManifest().version, when: Date.now(), tag: "file:" + file.name });
          }
        }).then(function (res) {
          var filesOutCount = res ? res.files : 0;
          S.update = null; setBadge(); banner(); setPill("current", "Up to date", "Manually installed from " + file.name);
          return dbSet("wdJustUpdated", { to: v.version, at: Date.now() }).then(function () {
            status("Installed v" + v.version + " from " + file.name + " (" + filesOutCount + " files). Reloading\u2026", "ok");
            setTimeout(function () { try { chrome.runtime.reload(); } catch (e) {} }, 1400);
          });
        });
      })
      .catch(function (e) {
        status((e && e.message) || String(e), "error");
      })
      .then(function () { setBusy(false); syncUI(); });
  }

  function restoreBackup() {
    dbGet("wdUpdateBackup").then(function (b) {
      if (!b || !b.zip) { status("No pre-update backup found.", "error"); return; }
      if (!S.handle) { status("Connect your extension folder first.", "error"); return; }
      setBusy(true);
      status("Restoring the backup\u2026", "info");
      U.readZip(b.zip)
        .then(function (files) { return U.restoreBackup(S.handle, files); })
        .then(function (rb) {
          if (!rb.ok) status("Restore incomplete: " + rb.errors.slice(0, 3).join("; "), "error");
          else status("Restored the pre-update backup. Reload the extension at chrome://extensions.", "ok");
        })
        .catch(function (e) { status("Restore failed: " + ((e && e.message) || e), "error"); })
        .then(function () { setBusy(false); syncUI(); });
    });
  }

  // ------------------------------------------------------------ wire
  function wire() {
    var con = $("wdUpConnect"); if (con) con.addEventListener("click", connect);
    var chg = $("wdUpChange"); if (chg) chg.addEventListener("click", function () { S.handle = null; S.connectedName = null; S.permission = "unknown"; dbDel("wdFolderHandle"); connect(); });
    var disc = $("wdUpDisconnect"); if (disc) disc.addEventListener("click", function () { S.handle = null; S.connectedName = null; S.permission = "unknown"; dbDel("wdFolderHandle"); status("Folder disconnected.", "info"); syncUI(); banner(); });
    var recon = $("wdUpReconnect"); if (recon) recon.addEventListener("click", function () { reconnect(true); });
    var chk = $("wdUpCheck"); if (chk) chk.addEventListener("click", function () { check(true); });
    var inst = $("wdUpInstall"); if (inst) inst.addEventListener("click", doUpdate);
    var rb = $("wdUpRestore"); if (rb) rb.addEventListener("click", restoreBackup);
    var pickEl = $("wdUpPickFile"), fileEl = $("wdUpFileInput");
    if (pickEl && fileEl) {
      pickEl.addEventListener("click", function () { fileEl.click(); });
      fileEl.addEventListener("change", function () {
        var f = fileEl.files && fileEl.files[0]; fileEl.value = "";
        if (!f) return;
        installFromFile(f);
      });
    }
    var auto = $("wdUpAuto");
    if (auto) auto.addEventListener("change", function () {
      S.autoEnabled = !!auto.checked;
      dbSet("wdAutoUpdate", S.autoEnabled ? "on" : "off");
      status(S.autoEnabled
        ? (S.handle ? "Auto-update is on. The next release will be installed automatically." : "Auto-update is on. Connect your extension folder to enable automatic install.")
        : "Auto-update is off. You can still install updates with Update now.", "info");
      banner();
    });
    document.addEventListener("click", function (e) {
      var b = e.target && e.target.closest ? e.target.closest("[data-wd-up]") : null;
      if (!b) return;
      var a = b.getAttribute("data-wd-up");
      if (a === "open" || a === "install") {
        var navBtn = updateNavBtn();
        if (navBtn) navBtn.click();
        var m = document.querySelector(".dash-main"); if (m) m.scrollTop = 0;
      }
      if (a === "install") { S.autoEnabled = true; dbSet("wdAutoUpdate", "on"); doUpdate(); }
    });
  }

  // section visibility is owned by dashboard.js activate()
  

  // ------------------------------------------------------------ init
  function init() {
    try {
      ensureSection();
      wire();
      $("wdUpCurrent").textContent = "v" + chrome.runtime.getManifest().version;
      $("wdUpLatest").textContent = "checking\u2026";
      dbGet("wdFolderHandle").then(function (h) {
        if (!h) return;
        S.handle = h; S.connectedName = h.name;
        h.queryPermission({ mode: "readwrite" }).then(function (p) {
          S.permission = p === "granted" ? "granted" : "prompt"; syncUI();
        }).catch(function () { S.permission = "prompt"; syncUI(); });
        syncUI();
      });
      dbGet("wdAutoUpdate").then(function (v) {
        S.autoEnabled = v === "on";
        var t = $("wdUpAuto"); if (t) t.checked = S.autoEnabled;
        syncUI();
      });
      dbGet("wdJustUpdated").then(function (j) {
        if (j && j.to) {
          status("Website Doctor was updated to v" + j.to + ".", "ok");
          dbDel("wdJustUpdated");
        }
      });
      check(false);
      setInterval(function () { check(false); }, RECHECK_MS);
    } catch (e) {
      console.warn("[Website Doctor] Update tab init failed:", e && e.message);
    }
  }

  // exposed for dashboard.js (buildNav badge + Update section routing)
  window.WDUpdate = {
    check: check,
    hasUpdate: function () { return !!S.update; },
    doUpdate: doUpdate
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, { once: true });
  else setTimeout(init, 0);
})();
