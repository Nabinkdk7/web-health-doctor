(function () {
  "use strict";
  if (window.__wdUpdateToastInstalled) return;
  window.__wdUpdateToastInstalled = true;

  var HOST_ID = "wd-update-toast-host";

  function ensureRoot() {
    var host = document.getElementById(HOST_ID);
    if (!host) {
      host = document.createElement("div");
      host.id = HOST_ID;
      host.style.cssText = "position:fixed;top:18px;right:18px;z-index:2147483647;pointer-events:none;";
      document.documentElement.appendChild(host);
    }
    var root = host.shadowRoot;
    if (!root) root = host.attachShadow({ mode: "open" });
    return root;
  }

  function showToast(tag) {
    var root = ensureRoot();
    root.innerHTML =
      '<style>' +
      '.t{pointer-events:auto;font-family:Inter,Segoe UI,system-ui,sans-serif;min-width:280px;max-width:360px;' +
      'background:rgba(17,22,36,.95);border:1px solid rgba(0,210,255,.35);border-radius:12px;padding:12px 14px;' +
      'color:#e8edf9;box-shadow:0 18px 40px -12px rgba(0,0,0,.7);display:flex;gap:10px;align-items:flex-start;' +
      'transform:translateX(120%);transition:transform .35s cubic-bezier(.2,.8,.3,1)}' +
      '.t.in{transform:translateX(0)}' +
      '.a{flex:none;width:8px;height:8px;border-radius:50%;background:#00D2FF;box-shadow:0 0 8px #00D2FF;margin-top:5px}' +
      '.b{flex:1 1 auto}.b b{display:block;font-size:13px;margin-bottom:2px}.b span{font-size:12px;color:#a7b1cf}' +
      '.b button{margin-top:8px;background:linear-gradient(135deg,#6366f1,#8b5cf6);border:0;color:#fff;font-weight:700;' +
      'font-size:12px;padding:7px 12px;border-radius:8px;cursor:pointer}' +
      '.c{flex:none;border:0;background:transparent;color:#8d97b6;font-size:16px;cursor:pointer;line-height:1}' +
      '</style>' +
      '<div class="t" id="t"><span class="a"></span><div class="b"><b>Website Doctor update</b>' +
      '<span>Version ' + tag + ' is available.</span>' +
      '<button id="open">Open dashboard</button></div>' +
      '<button class="c" id="x" aria-label="Dismiss">×</button></div>';
    var t = root.getElementById("t");
    requestAnimationFrame(function () { requestAnimationFrame(function () { t.classList.add("in"); }); });
    root.getElementById("x").addEventListener("click", function () { t.classList.remove("in"); });
    root.getElementById("open").addEventListener("click", function () {
      try {
        chrome.runtime.sendMessage({ action: "wdOpenDashboard" }, function () {});
      } catch (e) {}
      t.classList.remove("in");
    });
    setTimeout(function () { t.classList.remove("in"); }, 9000);
  }

  try {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (msg && msg.action === "wdUpdateAvailable") { showToast(msg.tag || "latest"); sendResponse && sendResponse({ ok: true }); }
    });
  } catch (e) {}
})();
