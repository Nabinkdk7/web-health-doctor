(function () {
  "use strict";
  if (window.__wdUpdateToastInstalled) return;
  window.__wdUpdateToastInstalled = true;

  var HOST_ID = "wd-update-toast-host";

  function ensureRoot() {
    var host = document.getElementById(HOST_ID);
    if (!host) {
      host = document.createElement("div");
      host.id = HOST_ID;
      host.style.cssText = "position:fixed;bottom:18px;right:18px;z-index:2147483647;pointer-events:none;";
      document.documentElement.appendChild(host);
    }
    var root = host.shadowRoot;
    if (!root) root = host.attachShadow({ mode: "open" });
    return root;
  }

  function showToast(tag) {
    var root = ensureRoot();
    root.innerHTML =
      '<style>' +
      '.t{pointer-events:auto;font-family:Inter,Segoe UI,system-ui,sans-serif;min-width:300px;max-width:360px;' +
      'background:rgba(22,24,32,.92);backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.12);' +
      'border-radius:14px;padding:12px 12px 12px 12px;color:#e8edf9;box-shadow:0 22px 50px -14px rgba(0,0,0,.7);' +
      'display:flex;gap:11px;align-items:center;transform:translateY(120%);transition:transform .38s cubic-bezier(.2,.8,.3,1)}' +
      '.t.in{transform:translateY(0)}' +
      '.a{flex:none;width:38px;height:38px;border-radius:10px;background:#111624;border:1px solid rgba(255,255,255,.1);' +
      'display:flex;align-items:center;justify-content:center;color:#8b95f9;font-weight:800;font-size:13px}' +
      '.b{flex:1 1 auto;min-width:0}.b b{display:block;font-size:13px}.b span{font-size:12px;color:#a7b1cf}' +
      '.acts{display:flex;gap:2px;align-self:flex-start}.acts button{border:0;background:transparent;color:#8d97b6;' +
      'font-size:15px;cursor:pointer;padding:2px 6px;border-radius:6px}.acts button:hover{background:rgba(255,255,255,.08);color:#fff}' +
      '</style>' +
      '<div class="t" id="t"><span class="a">WD</span><div class="b"><b>Web Doctor</b>' +
      '<span>Version ' + tag + ' is ready to install.</span></div>' +
      '<div class="acts"><button id="open" title="Open dashboard">…</button><button id="x" aria-label="Dismiss">×</button></div></div>';
    var t = root.getElementById("t");
    requestAnimationFrame(function () { requestAnimationFrame(function () { t.classList.add("in"); }); });
    root.getElementById("x").addEventListener("click", function () { t.classList.remove("in"); });
    root.getElementById("open").addEventListener("click", function () {
      try {
        chrome.runtime.sendMessage({ action: "wdOpenDashboard" }, function () {});
      } catch (e) {}
      t.classList.remove("in");
    });
    setTimeout(function () { t.classList.remove("in"); }, 9000);
  }

  try {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (msg && msg.action === "wdUpdateAvailable") { showToast(msg.tag || "latest"); sendResponse && sendResponse({ ok: true }); }
    });
  } catch (e) {}
})();
