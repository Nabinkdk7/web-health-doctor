<#
  Website Doctor - apply a GitHub update (with automatic backup)
  =============================================================
  Chrome cannot overwrite a loaded extension's own files, so the dashboard
  downloads the new version and this script installs it:

    1. Backs up the current extension folder to ..\backups\ (always, first).
    2. Uses the zip the dashboard downloaded (newest website-doctor-*.zip in
       Downloads), or -ZipPath, or fetches the tag straight from GitHub.
    3. Checks the package has a manifest.json, then replaces the files.

  Then press Reload on Website Doctor at chrome://extensions.

  Usage (right-click > Run with PowerShell, or from a PowerShell window):
    .\website-doctor-update.ps1                      # newest downloaded zip, else latest GitHub tag
    .\website-doctor-update.ps1 -Version v2.2.0      # a specific GitHub tag
    .\website-doctor-update.ps1 -ZipPath "C:\path\website-doctor-2.2.0.zip"
#>
param(
  [string]$Version = "",
  [string]$ZipPath = "",
  [string]$ExtensionPath = ""
)

$ErrorActionPreference = "Stop"

$Owner = "Nabinkdk7"
$Repo  = "web-health-doctor"
$Api   = "https://api.github.com"

if ($ExtensionPath -eq "") { $ExtensionPath = Split-Path -Parent $PSScriptRoot }
$ExtensionPath = [System.IO.Path]::GetFullPath($ExtensionPath)
if (-not (Test-Path -LiteralPath (Join-Path $ExtensionPath "manifest.json"))) {
  throw "No manifest.json in $ExtensionPath - point -ExtensionPath at the extension folder."
}

$tmp = Join-Path $env:TEMP ("website-doctor-" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tmp | Out-Null
try {
  # ---- 1. Pick the package ----
  if ($ZipPath -eq "" -and $Version -eq "") {
    $dl = Join-Path $env:USERPROFILE "Downloads"
    $found = Get-ChildItem -LiteralPath $dl -Filter "website-doctor-*.zip" -ErrorAction SilentlyContinue |
      Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($found) { $ZipPath = $found.FullName }
  }
  if ($ZipPath -ne "") {
    if (-not (Test-Path -LiteralPath $ZipPath)) { throw "Zip not found: $ZipPath" }
    $pkg = $ZipPath
    Write-Host "Using downloaded package: $pkg" -ForegroundColor Cyan
  } else {
    if ($Version -eq "") {
      $tags = Invoke-RestMethod -Uri "$Api/repos/$Owner/$Repo/tags?per_page=100" -Headers @{ "User-Agent" = "website-doctor-updater" }
      if (-not $tags -or $tags.Count -eq 0) { throw "No tags published on GitHub for $Owner/$Repo." }
      $Version = $tags[0].name
    }
    $pkg = Join-Path $tmp "package.zip"
    $url = "https://github.com/$Owner/$Repo/archive/refs/tags/$Version.zip"
    Write-Host "Downloading $Version from GitHub..." -ForegroundColor Cyan
    Write-Host "  $url"
    Invoke-WebRequest -Uri $url -OutFile $pkg -UseBasicParsing
  }

  # ---- 2. Unpack + validate (GitHub archives nest files in one folder) ----
  $x = Join-Path $tmp "x"
  Expand-Archive -LiteralPath $pkg -DestinationPath $x -Force
  $src = $x
  if (-not (Test-Path -LiteralPath (Join-Path $src "manifest.json"))) {
    $inner = Get-ChildItem -LiteralPath $x -Directory | Select-Object -First 1
    if ($inner) { $src = $inner.FullName }
  }
  # The repo publishes the extension as an uploaded zip (webdoctor.zip) inside
  # the tag archive, so look one zip deeper when no loose manifest is found.
  if (-not (Test-Path -LiteralPath (Join-Path $src "manifest.json"))) {
    $innerZips = Get-ChildItem -LiteralPath $x -Recurse -Filter "*.zip" | Sort-Object Length -Descending
    foreach ($iz in $innerZips) {
      $y = Join-Path $tmp ("y-" + [Guid]::NewGuid().ToString("N"))
      Expand-Archive -LiteralPath $iz.FullName -DestinationPath $y -Force
      $cand = $y
      if (-not (Test-Path -LiteralPath (Join-Path $cand "manifest.json"))) {
        $d = Get-ChildItem -LiteralPath $y -Directory | Select-Object -First 1
        if ($d) { $cand = $d.FullName }
      }
      if (Test-Path -LiteralPath (Join-Path $cand "manifest.json")) {
        $src = $cand
        Write-Host "Found extension inside $($iz.Name)" -ForegroundColor Cyan
        break
      }
    }
  }
  if (-not (Test-Path -LiteralPath (Join-Path $src "manifest.json"))) {
    throw "Package is invalid: manifest.json not found. Nothing was changed."
  }
  $newVer = (Get-Content -Raw -LiteralPath (Join-Path $src "manifest.json") | ConvertFrom-Json).version
  $oldVer = (Get-Content -Raw -LiteralPath (Join-Path $ExtensionPath "manifest.json") | ConvertFrom-Json).version

  # ---- 3. Backup FIRST ----
  $backups = Join-Path (Split-Path -Parent $ExtensionPath) "backups"
  New-Item -ItemType Directory -Force -Path $backups | Out-Null
  $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
  $bk = Join-Path $backups "website-doctor-v$oldVer-before-update-$stamp.zip"
  Compress-Archive -Path (Join-Path $ExtensionPath "*") -DestinationPath $bk -Force
  if (-not (Test-Path -LiteralPath $bk)) { throw "Backup failed - update aborted, nothing was changed." }
  Write-Host "Backup saved: $bk" -ForegroundColor Green

  # ---- 4. Replace files ----
  Get-ChildItem -LiteralPath $ExtensionPath -Force |
    Where-Object { $_.Name -notin @(".git", ".gitignore") } |
    ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force }
  Copy-Item -Path (Join-Path $src "*") -Destination $ExtensionPath -Recurse -Force

  Write-Host ""
  Write-Host "Updated Website Doctor v$oldVer -> v$newVer" -ForegroundColor Green
  Write-Host "  $ExtensionPath"
  Write-Host ""
  Write-Host "Next: chrome://extensions -> Reload on Website Doctor." -ForegroundColor Yellow
  Write-Host "To undo: unzip the backup above over the same folder and Reload."
}
finally {
  if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force }
}
