<#
  Web Doctor - dynamic version switch (apply step)
  ================================================
  Chrome MV3 extensions cannot replace their own loaded files, so this script
  is the "apply" side of the Version Manager: it pulls the chosen version
  straight from the GitHub API and swaps it over your unpacked extension
  folder. The extension's Version tab fetches + downloads automatically; this
  script finishes the switch. Reload the extension afterwards.

  Usage:
    .\webdoctor-update.ps1 -Version v1.2.0
    .\webdoctor-update.ps1 -Version v1.2.0 -ExtensionPath "C:\path\to\extension"
    .\webdoctor-update.ps1            # applies the latest tag by default

  Requirements: PowerShell 5.1+, internet access. GitHub is called read-only.
#>
param(
  [string]$Version = "",
  [string]$ExtensionPath = ""
)

$ErrorActionPreference = "Stop"

$Owner = "Nabinkdk7"
$Repo  = "web-health-doctor"
$Api   = "https://api.github.com"

function Resolve-Tag {
  if ($Version -ne "") { return $Version }
  $tags = Invoke-RestMethod -Uri "$Api/repos/$Owner/$Repo/tags?per_page=100" -Headers @{ "User-Agent" = "web-doctor-updater" }
  if (-not $tags -or $tags.Count -eq 0) { throw "No tags found on GitHub for $Owner/$Repo." }
  return $tags[0].name
}

if ($ExtensionPath -eq "") {
  $ExtensionPath = Split-Path -Parent $PSScriptRoot
}
$ExtensionPath = [System.IO.Path]::GetFullPath($ExtensionPath)
if (-not (Test-Path -LiteralPath $ExtensionPath)) { throw "Extension path not found: $ExtensionPath" }

$tag = Resolve-Tag
$zipUrl = "https://github.com/$Owner/$Repo/archive/refs/tags/$tag.zip"

Write-Host "Fetching $tag from GitHub API..." -ForegroundColor Cyan
Write-Host "  $zipUrl"

$tmp = Join-Path $env:TEMP ("webdoctor-" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tmp | Out-Null
try {
  $pkg = Join-Path $tmp "package.zip"
  Invoke-WebRequest -Uri $zipUrl -OutFile $pkg -UseBasicParsing
  Expand-Archive -LiteralPath $pkg -DestinationPath (Join-Path $tmp "x") -Force
  $srcRoot = Get-ChildItem -LiteralPath (Join-Path $tmp "x") -Directory | Select-Object -First 1
  if (-not $srcRoot) { throw "Package for $tag is empty." }
  if (-not (Test-Path -LiteralPath (Join-Path $srcRoot.FullName "manifest.json"))) {
    throw "Package for $tag is invalid: manifest.json not found."
  }

  $keep = @()
  Get-ChildItem -LiteralPath $ExtensionPath | Where-Object {
    $_.Name -notin @( ".git", ".gitignore" )
  } | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force }

  Copy-Item -Path (Join-Path $srcRoot.FullName "*") -Destination $ExtensionPath -Recurse -Force

  Write-Host ""
  Write-Host "Applied $tag to:" -ForegroundColor Green
  Write-Host "  $ExtensionPath" -ForegroundColor Green
  Write-Host ""
  Write-Host "Next step: reload the extension at chrome://extensions (Reload button on Web Doctor)." -ForegroundColor Yellow
}
finally {
  if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force }
}