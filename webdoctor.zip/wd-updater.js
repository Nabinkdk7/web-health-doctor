/*!
 * Website Doctor — in-browser update engine (no DOM, no chrome.* calls).
 * Shared by dashboard-update.js (browser) and the Node test-suite.
 *
 * Flow: fetch the release package from GitHub -> read the zip (incl. the
 * repo's nested webdoctor.zip) -> validate the manifest and every file it
 * references -> snapshot the connected extension folder (backup) -> write
 * the new files (manifest.json last) -> read every file back and compare
 * bytes -> on ANY failure, restore the snapshot byte-for-byte.
 *
 * Folder access uses the File System Access API (FileSystemDirectoryHandle);
 * the same interface is implemented by the Origin Private File System and by
 * the in-memory mock used in tests.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.WDUpdater = api;
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  var OWNER = "Nabinkdk7";
  var REPO = "web-health-doctor";
  var PACKAGE_NAME = "webdoctor.zip";
  var API = "https://api.github.com";
  var MAX_PACKAGE_BYTES = 50 * 1024 * 1024;
  var MAX_UNPACKED_BYTES = 200 * 1024 * 1024;
  var MAX_FILES = 3000;
  // Never snapshot, overwrite, or delete these folders inside the extension.
  var SKIP_DIRS = { ".git": 1, "node_modules": 1, "backups": 1, ".qodo": 1 };

  // ---------------------------------------------------------------- versions
  function versionParts(v) {
    var m = String(v == null ? "" : v).trim().replace(/^v/i, "").match(/^(\d+)(?:\.(\d+))?(?:\.(\d+))?(?:\.(\d+))?$/);
    if (!m) return null;
    return [m[1], m[2], m[3], m[4]].map(function (x) { return parseInt(x || "0", 10); });
  }

  // 1 if a > b, -1 if a < b, 0 if equal, null if either is not a version.
  function compare(a, b) {
    var pa = versionParts(a), pb = versionParts(b);
    if (!pa || !pb) return null;
    for (var i = 0; i < 4; i++) {
      if (pa[i] !== pb[i]) return pa[i] > pb[i] ? 1 : -1;
    }
    return 0;
  }

  function normTag(t) { return String(t == null ? "" : t).trim().replace(/^v/i, ""); }

  // ---------------------------------------------------------------- bytes
  var CRC_TABLE = (function () {
    var t = new Uint32Array(256);
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[n] = c >>> 0;
    }
    return t;
  })();

  function crc32(u8) {
    var c = 0xFFFFFFFF;
    for (var i = 0; i < u8.length; i++) c = CRC_TABLE[(c ^ u8[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  function sameBytes(a, b) {
    if (!a || !b || a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }

  function utf8(u8) { return new TextDecoder("utf-8").decode(u8); }

  function toU8(x) {
    if (x instanceof Uint8Array) return x;
    if (x instanceof ArrayBuffer) return new Uint8Array(x);
    if (ArrayBuffer.isView(x)) return new Uint8Array(x.buffer, x.byteOffset, x.byteLength);
    throw new Error("Expected binary data.");
  }

  function inflateRaw(u8) {
    if (typeof DecompressionStream === "undefined") {
      return Promise.reject(new Error("This browser cannot unpack zip files (DecompressionStream is missing). Update Chrome."));
    }
    var stream = new Blob([u8]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
    return new Response(stream).arrayBuffer().then(function (ab) { return new Uint8Array(ab); });
  }

  // Zip entry names -> safe relative paths. Rejects traversal and absolute paths.
  function safePath(name) {
    var p = String(name).replace(/\\/g, "/");
    if (/^[a-zA-Z]:/.test(p) || p.charAt(0) === "/") throw new Error("Unsafe absolute path in package: " + name);
    var parts = p.split("/").filter(function (s) { return s !== "" && s !== "."; });
    for (var i = 0; i < parts.length; i++) {
      if (parts[i] === "..") throw new Error("Unsafe path in package: " + name);
    }
    return parts.join("/");
  }

  // ---------------------------------------------------------------- zip read
  // Returns Promise<{ [path]: Uint8Array }>. Stored + deflate; CRC-checked.
  function readZip(input) {
    return Promise.resolve().then(function () {
      var u8 = toU8(input);
      var dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
      if (u8.length < 22) throw new Error("Not a zip file (too small).");
      var eocd = -1;
      var stop = Math.max(0, u8.length - 22 - 65535);
      for (var i = u8.length - 22; i >= stop; i--) {
        if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
      }
      if (eocd < 0) throw new Error("Not a zip file (no end-of-central-directory record).");
      var count = dv.getUint16(eocd + 10, true);
      var cdOff = dv.getUint32(eocd + 16, true);
      if (count === 0xFFFF || cdOff === 0xFFFFFFFF) throw new Error("ZIP64 packages are not supported.");
      if (count > MAX_FILES) throw new Error("Package has too many files (" + count + ").");

      var entries = [];
      var p = cdOff;
      var total = 0;
      for (var n = 0; n < count; n++) {
        if (p + 46 > u8.length || dv.getUint32(p, true) !== 0x02014b50) throw new Error("Corrupt zip (bad central directory entry " + n + ").");
        var flags = dv.getUint16(p + 8, true);
        var method = dv.getUint16(p + 10, true);
        var crc = dv.getUint32(p + 16, true);
        var csize = dv.getUint32(p + 20, true);
        var usize = dv.getUint32(p + 24, true);
        var nlen = dv.getUint16(p + 28, true);
        var xlen = dv.getUint16(p + 30, true);
        var clen = dv.getUint16(p + 32, true);
        var lho = dv.getUint32(p + 42, true);
        var rawName = utf8(u8.subarray(p + 46, p + 46 + nlen));
        p += 46 + nlen + xlen + clen;
        if (/[\\/]$/.test(rawName)) continue; // directory entry
        if (flags & 1) throw new Error("Encrypted zip entries are not supported: " + rawName);
        total += usize;
        if (total > MAX_UNPACKED_BYTES) throw new Error("Package is too large when unpacked.");
        entries.push({ name: safePath(rawName), method: method, crc: crc, csize: csize, usize: usize, lho: lho });
      }

      var out = Object.create(null);
      return entries.reduce(function (chain, e) {
        return chain.then(function () {
          if (e.lho + 30 > u8.length || dv.getUint32(e.lho, true) !== 0x04034b50) throw new Error("Corrupt zip (bad local header for " + e.name + ").");
          var start = e.lho + 30 + dv.getUint16(e.lho + 26, true) + dv.getUint16(e.lho + 28, true);
          if (start + e.csize > u8.length) throw new Error("Corrupt zip (truncated data for " + e.name + ").");
          var data = u8.subarray(start, start + e.csize);
          var done;
          if (e.method === 0) done = Promise.resolve(new Uint8Array(data));
          else if (e.method === 8) done = inflateRaw(data);
          else throw new Error("Unsupported zip compression method " + e.method + " for " + e.name + ".");
          return done.then(function (bytes) {
            if (bytes.length !== e.usize) throw new Error("Size mismatch for " + e.name + " (corrupt download?).");
            if (crc32(bytes) !== e.crc) throw new Error("Checksum mismatch for " + e.name + " (corrupt download?).");
            if (e.name) out[e.name] = bytes;
          });
        });
      }, Promise.resolve()).then(function () { return out; });
    });
  }

  // ---------------------------------------------------------------- zip write
  // Stored (uncompressed) zip with CRC32 + UTF-8 names. Used for backups.
  function writeZip(files, when) {
    var enc = new TextEncoder();
    var d = when instanceof Date ? when : new Date();
    var dosTime = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
    var dosDate = ((Math.max(1980, d.getFullYear()) - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    var parts = [], central = [], offset = 0;
    Object.keys(files).sort().forEach(function (path) {
      var name = enc.encode(path);
      var data = toU8(files[path]);
      var crc = crc32(data);
      var lh = new Uint8Array(30 + name.length), lv = new DataView(lh.buffer);
      lv.setUint32(0, 0x04034b50, true); lv.setUint16(4, 20, true); lv.setUint16(6, 0x0800, true);
      lv.setUint16(8, 0, true); lv.setUint16(10, dosTime, true); lv.setUint16(12, dosDate, true);
      lv.setUint32(14, crc, true); lv.setUint32(18, data.length, true); lv.setUint32(22, data.length, true);
      lv.setUint16(26, name.length, true); lv.setUint16(28, 0, true); lh.set(name, 30);
      var ch = new Uint8Array(46 + name.length), cv = new DataView(ch.buffer);
      cv.setUint32(0, 0x02014b50, true); cv.setUint16(4, 20, true); cv.setUint16(6, 20, true);
      cv.setUint16(8, 0x0800, true); cv.setUint16(10, 0, true); cv.setUint16(12, dosTime, true);
      cv.setUint16(14, dosDate, true); cv.setUint32(16, crc, true); cv.setUint32(20, data.length, true);
      cv.setUint32(24, data.length, true); cv.setUint16(28, name.length, true);
      cv.setUint32(42, offset, true); ch.set(name, 46);
      parts.push(lh, data); central.push(ch);
      offset += lh.length + data.length;
    });
    var cdSize = central.reduce(function (s, c) { return s + c.length; }, 0);
    var eocd = new Uint8Array(22), ev = new DataView(eocd.buffer);
    ev.setUint32(0, 0x06054b50, true); ev.setUint16(8, central.length, true); ev.setUint16(10, central.length, true);
    ev.setUint32(12, cdSize, true); ev.setUint32(16, offset, true);
    var all = parts.concat(central, [eocd]);
    var out = new Uint8Array(offset + cdSize + 22), at = 0;
    all.forEach(function (c) { out.set(c, at); at += c.length; });
    return out;
  }

  // ---------------------------------------------------------------- package
  // Finds the extension inside a package: manifest at the root, inside one
  // wrapping folder (GitHub tag archives), or inside a nested zip (this repo
  // ships webdoctor.zip). Returns files re-rooted at the manifest.
  function locateExtension(files, depth) {
    depth = depth || 0;
    return Promise.resolve().then(function () {
      if (files["manifest.json"]) return files;
      var best = null;
      Object.keys(files).forEach(function (k) {
        if (/(^|\/)manifest\.json$/.test(k)) {
          var prefix = k.slice(0, k.length - "manifest.json".length);
          if (best === null || prefix.length < best.length) best = prefix;
        }
      });
      if (best !== null) {
        var re = Object.create(null);
        Object.keys(files).forEach(function (k) {
          if (k.indexOf(best) === 0 && k.length > best.length) re[k.slice(best.length)] = files[k];
        });
        return re;
      }
      if (depth >= 2) throw new Error("No manifest.json found in the update package.");
      var zips = Object.keys(files).filter(function (k) { return /\.zip$/i.test(k); });
      if (!zips.length) throw new Error("No manifest.json found in the update package.");
      zips.sort(function (a, b) {
        var an = /(^|\/)webdoctor\.zip$/i.test(a) ? 0 : 1, bn = /(^|\/)webdoctor\.zip$/i.test(b) ? 0 : 1;
        return an !== bn ? an - bn : files[b].length - files[a].length;
      });
      var tryAt = function (i) {
        if (i >= zips.length) throw new Error("No manifest.json found in the update package.");
        return readZip(files[zips[i]])
          .then(function (inner) { return locateExtension(inner, depth + 1); })
          .catch(function () { return tryAt(i + 1); });
      };
      return tryAt(0);
    });
  }

  function manifestRefs(mf) {
    var refs = [];
    var add = function (v) { if (typeof v === "string" && v && !/^https?:/i.test(v)) refs.push(v.split("#")[0].split("?")[0]); };
    var addIcons = function (o) {
      if (typeof o === "string") add(o);
      else if (o && typeof o === "object") Object.keys(o).forEach(function (k) { add(o[k]); });
    };
    if (mf.background) add(mf.background.service_worker);
    if (mf.action) { add(mf.action.default_popup); addIcons(mf.action.default_icon); }
    addIcons(mf.icons);
    add(mf.options_page);
    if (mf.options_ui) add(mf.options_ui.page);
    if (mf.side_panel) add(mf.side_panel.default_path);
    add(mf.devtools_page);
    (mf.content_scripts || []).forEach(function (cs) {
      (cs.js || []).forEach(add);
      (cs.css || []).forEach(add);
    });
    return refs;
  }

  // Validates an unpacked package. opts.currentVersion -> must be newer;
  // opts.expectedVersion -> manifest must match the release tag.
  function validatePackage(files, opts) {
    opts = opts || {};
    var errors = [];
    var raw = files && files["manifest.json"];
    if (!raw) return { ok: false, errors: ["manifest.json is missing from the package."] };
    var mf = null;
    try {
      mf = JSON.parse(utf8(raw).replace(/^\uFEFF/, ""));
    } catch (e) {
      return { ok: false, errors: ["manifest.json is not valid JSON: " + e.message] };
    }
    if (!mf || typeof mf !== "object") return { ok: false, errors: ["manifest.json is empty."] };
    if (mf.manifest_version !== 3) errors.push("manifest_version must be 3.");
    if (!mf.name) errors.push("manifest.json has no name.");
    if (!versionParts(mf.version)) errors.push("manifest.json has an invalid version: " + mf.version);
    manifestRefs(mf).forEach(function (r) {
      var p;
      try { p = safePath(r); } catch (e) { errors.push(e.message); return; }
      if (!files[p]) errors.push("File referenced by manifest.json is missing: " + p);
    });
    if (opts.expectedVersion && versionParts(mf.version) && compare(mf.version, opts.expectedVersion) !== 0) {
      errors.push("Package version " + mf.version + " does not match release " + opts.expectedVersion + ".");
    }
    if (opts.currentVersion && versionParts(mf.version) && compare(mf.version, opts.currentVersion) !== 1) {
      errors.push("Package version " + mf.version + " is not newer than the installed " + normTag(opts.currentVersion) + ".");
    }
    var bytes = 0, count = 0;
    Object.keys(files).forEach(function (k) { bytes += files[k].length; count++; });
    return { ok: errors.length === 0, errors: errors, manifest: mf, version: mf.version, name: mf.name, fileCount: count, totalBytes: bytes };
  }

  // ---------------------------------------------------------------- GitHub
  function packageUrls(tag) {
    var t = encodeURIComponent(tag);
    return [
      "https://raw.githubusercontent.com/" + OWNER + "/" + REPO + "/" + t + "/" + PACKAGE_NAME,
      "https://codeload.github.com/" + OWNER + "/" + REPO + "/zip/refs/tags/" + t
    ];
  }

  function getFetch(f) {
    var fn = f || (typeof fetch !== "undefined" ? fetch : null);
    if (!fn) throw new Error("fetch is unavailable.");
    return fn;
  }

  // Highest semver tag on GitHub (not the API's order). -> {tag, sha} | null
  function fetchLatestTag(fetchImpl) {
    var f = getFetch(fetchImpl);
    return f(API + "/repos/" + OWNER + "/" + REPO + "/tags?per_page=100", { cache: "no-store" })
      .then(function (res) {
        if (!res.ok) throw new Error("GitHub returned HTTP " + res.status + (res.status === 403 ? " (rate limited, try again later)" : ""));
        return res.json();
      })
      .then(function (list) {
        var best = null;
        (list || []).forEach(function (t) {
          if (!t || !versionParts(t.name)) return;
          if (!best || compare(t.name, best.tag) === 1) best = { tag: t.name, sha: t.commit && t.commit.sha };
        });
        return best;
      });
  }

  // Release notes = the tagged commit's message (best effort).
  function fetchNotes(sha, fetchImpl) {
    if (!sha) return Promise.resolve("");
    var f = getFetch(fetchImpl);
    return f(API + "/repos/" + OWNER + "/" + REPO + "/commits/" + encodeURIComponent(sha), { cache: "no-store" })
      .then(function (res) { return res.ok ? res.json() : null; })
      .then(function (j) { return (j && j.commit && j.commit.message) || ""; })
      .catch(function () { return ""; });
  }

  // Downloads + unpacks the release. Tries raw webdoctor.zip, then the tag archive.
  function fetchPackage(tag, fetchImpl, onProgress) {
    var f = getFetch(fetchImpl);
    var urls = packageUrls(tag);
    var errs = [];
    var attempt = function (i) {
      if (i >= urls.length) return Promise.reject(new Error("Could not download the update: " + errs.join(" | ")));
      var url = urls[i];
      if (onProgress) onProgress({ url: url, attempt: i + 1 });
      return f(url, { cache: "no-store" })
        .then(function (res) {
          if (!res.ok) throw new Error("HTTP " + res.status);
          return res.arrayBuffer();
        })
        .then(function (ab) {
          if (ab.byteLength > MAX_PACKAGE_BYTES) throw new Error("package is larger than 50 MB");
          return readZip(ab).then(locateExtension).then(function (files) {
            return { files: files, url: url, bytes: ab.byteLength };
          });
        })
        .catch(function (e) {
          errs.push(url.replace(/^https:\/\//, "") + " -> " + ((e && e.message) || e));
          return attempt(i + 1);
        });
    };
    return attempt(0);
  }

  // ---------------------------------------------------------------- folder IO
  function baseName(p) { var i = p.lastIndexOf("/"); return i < 0 ? p : p.slice(i + 1); }

  function dirOf(root, path, create) {
    var parts = path.split("/");
    parts.pop();
    return parts.reduce(function (chain, name) {
      return chain.then(function (d) { return d.getDirectoryHandle(name, { create: !!create }); });
    }, Promise.resolve(root));
  }

  function isMissing(e) { return e && (e.name === "NotFoundError" || e.name === "TypeMismatchError"); }

  function readFile(root, path) {
    return dirOf(root, path, false)
      .then(function (d) { return d.getFileHandle(baseName(path)); })
      .then(function (fh) { return fh.getFile(); })
      .then(function (file) { return file.arrayBuffer(); })
      .then(function (ab) { return new Uint8Array(ab); })
      .catch(function (e) { if (isMissing(e)) return null; throw e; });
  }

  function writeFile(root, path, data) {
    return dirOf(root, path, true)
      .then(function (d) { return d.getFileHandle(baseName(path), { create: true }); })
      .then(function (fh) { return fh.createWritable(); })
      .then(function (w) {
        return Promise.resolve(w.write(data))
          .then(function () { return w.close(); })
          .catch(function (e) {
            return Promise.resolve(w.abort ? w.abort() : null).catch(function () {}).then(function () { throw e; });
          });
      });
  }

  function removeFile(root, path) {
    return dirOf(root, path, false)
      .then(function (d) { return d.removeEntry(baseName(path)); })
      .catch(function (e) { if (isMissing(e)) return; throw e; });
  }

  function listEntries(dir) {
    var out = [];
    var it = dir.entries();
    var step = function () {
      return it.next().then(function (r) {
        if (r.done) return out;
        out.push(r.value);
        return step();
      });
    };
    return step();
  }

  // Every file in the folder (recursive, skipping SKIP_DIRS) -> {path: bytes}
  function snapshotDir(dir, prefix, out) {
    prefix = prefix || "";
    out = out || Object.create(null);
    return listEntries(dir).then(function (entries) {
      entries.sort(function (a, b) { return a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0; });
      return entries.reduce(function (chain, ent) {
        return chain.then(function () {
          var name = ent[0], h = ent[1];
          if (h.kind === "directory") {
            if (SKIP_DIRS[name]) return;
            return snapshotDir(h, prefix + name + "/", out);
          }
          return h.getFile()
            .then(function (f) { return f.arrayBuffer(); })
            .then(function (ab) { out[prefix + name] = new Uint8Array(ab); });
        });
      }, Promise.resolve());
    }).then(function () { return out; });
  }

  // Confirms the connected folder is the extension Chrome is running:
  // same manifest name + version, and an identical copy of a running file.
  function verifyFolder(dir, running) {
    return readFile(dir, "manifest.json").then(function (raw) {
      if (!raw) return { ok: false, error: "That folder has no manifest.json. Choose the folder you loaded at chrome://extensions (e.g. webdeve-unpacked)." };
      var mf;
      try { mf = JSON.parse(utf8(raw).replace(/^\uFEFF/, "")); } catch (e) {
        return { ok: false, error: "manifest.json in that folder is not valid JSON." };
      }
      if (running.name && mf.name !== running.name) {
        return { ok: false, error: "That folder contains \u201C" + mf.name + "\u201D, not \u201C" + running.name + "\u201D." };
      }
      if (running.version && compare(mf.version, running.version) !== 0) {
        return { ok: false, error: "That folder is v" + mf.version + " but Chrome is running v" + running.version + ". Choose the folder Chrome actually loaded, or press Reload at chrome://extensions first." };
      }
      if (!running.ownFile) return { ok: true, manifest: mf };
      return readFile(dir, running.ownFile.path).then(function (bytes) {
        if (!bytes || !sameBytes(bytes, running.ownFile.bytes)) {
          return { ok: false, error: "That folder is a different copy of the extension (" + running.ownFile.path + " does not match the running one). Choose the folder Chrome loaded." };
        }
        return { ok: true, manifest: mf };
      });
    });
  }

  // Restores `snapshot` exactly; removes `touched` files that were not in it.
  function restore(dir, snapshot, touched) {
    var errors = [];
    var paths = Object.keys(snapshot);
    return paths.reduce(function (chain, p) {
      return chain.then(function () {
        return readFile(dir, p).then(function (cur) {
          if (cur && sameBytes(cur, snapshot[p])) return;
          return writeFile(dir, p, snapshot[p]);
        }).catch(function (e) { errors.push(p + ": " + ((e && e.message) || e)); });
      });
    }, Promise.resolve()).then(function () {
      return (touched || []).reduce(function (chain, p) {
        return chain.then(function () {
          if (snapshot[p]) return;
          return removeFile(dir, p).catch(function (e) { errors.push(p + ": " + ((e && e.message) || e)); });
        });
      }, Promise.resolve());
    }).then(function () {
      return paths.reduce(function (chain, p) {
        return chain.then(function () {
          return readFile(dir, p).then(function (cur) {
            if (!cur || !sameBytes(cur, snapshot[p])) errors.push("Not restored: " + p);
          }).catch(function () { errors.push("Not restored: " + p); });
        });
      }, Promise.resolve());
    }).then(function () { return { ok: errors.length === 0, errors: errors }; });
  }

  // Full restore of a backup over the folder (removes files added since).
  function restoreBackup(dir, backupFiles) {
    return snapshotDir(dir).then(function (current) {
      return restore(dir, backupFiles, Object.keys(current));
    });
  }

  // Installs a validated package into `dir`.
  //   o.dir, o.files, o.saveBackup(snapshot) -> Promise (MUST resolve, else abort)
  //   o.onStep(name, info)
  function install(o) {
    var step = o.onStep || function () {};
    var snapshot = null;
    var written = [];
    var paths = Object.keys(o.files).sort(function (a, b) {
      if (a === "manifest.json") return 1;
      if (b === "manifest.json") return -1;
      return a < b ? -1 : a > b ? 1 : 0;
    });
    var unchanged = function (msg) {
      var err = new Error(msg + " Nothing was changed.");
      err.stage = "backup";
      err.nothingChanged = true;
      return err;
    };
    step("backup", {});
    return snapshotDir(o.dir)
      .then(function (snap) {
        if (!snap["manifest.json"]) throw unchanged("The connected folder has no manifest.json.");
        snapshot = snap;
        return Promise.resolve()
          .then(function () { return o.saveBackup ? o.saveBackup(snap) : null; })
          .catch(function (e) { throw unchanged("Backup failed, so the update was cancelled: " + ((e && e.message) || e) + "."); });
      }, function (e) {
        throw unchanged("Could not read the extension folder: " + ((e && e.message) || e) + ".");
      })
      .then(function () {
        step("install", { done: 0, total: paths.length });
        return paths.reduce(function (chain, p, i) {
          return chain.then(function () {
            return writeFile(o.dir, p, o.files[p]).then(function () {
              written.push(p);
              step("install", { done: i + 1, total: paths.length, path: p });
            });
          });
        }, Promise.resolve());
      })
      .then(function () {
        step("verify", {});
        return paths.reduce(function (chain, p) {
          return chain.then(function () {
            return readFile(o.dir, p).then(function (back) {
              if (!back || !sameBytes(back, o.files[p])) throw new Error("Verification failed: " + p + " did not save correctly.");
            });
          });
        }, Promise.resolve());
      })
      .then(function () {
        return { ok: true, files: paths.length, snapshot: snapshot };
      }, function (err) {
        if (err && err.nothingChanged) throw err;
        step("rollback", {});
        return restore(o.dir, snapshot, paths).then(function (rb) {
          var e2 = new Error(((err && err.message) || String(err)) + (rb.ok
            ? " Your previous version was restored automatically."
            : " Automatic restore was incomplete (" + rb.errors.slice(0, 3).join("; ") + "). Use Restore backup in the Update tab."));
          e2.stage = "install";
          e2.rolledBack = rb.ok;
          e2.rollbackErrors = rb.errors;
          throw e2;
        });
      });
  }

  return {
    OWNER: OWNER,
    REPO: REPO,
    PACKAGE_NAME: PACKAGE_NAME,
    versionParts: versionParts,
    compare: compare,
    normTag: normTag,
    crc32: crc32,
    sameBytes: sameBytes,
    safePath: safePath,
    readZip: readZip,
    writeZip: writeZip,
    locateExtension: locateExtension,
    manifestRefs: manifestRefs,
    validatePackage: validatePackage,
    packageUrls: packageUrls,
    fetchLatestTag: fetchLatestTag,
    fetchNotes: fetchNotes,
    fetchPackage: fetchPackage,
    readFile: readFile,
    writeFile: writeFile,
    removeFile: removeFile,
    snapshotDir: snapshotDir,
    verifyFolder: verifyFolder,
    restore: restore,
    restoreBackup: restoreBackup,
    install: install
  };
});
