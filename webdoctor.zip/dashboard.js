/*!
 * WEB DOCTOR 2 — Developer Dashboard
 * Full-page audit view over the SAME real scan results the popup produces.
 * Reads the latest scan from chrome.storage.session (saved by popup.js) and
 * can re-run the analyzer against the previously scanned tab (or the current
 * active tab) via background.js analyzeTab. Never fabricates values.
 */
(function () {
  "use strict";

  var WD = window.WDCommon;
  var esc = function (s) { return WD.escapeHtml(s); };
  var fmtBytes = WD.formatBytes;
  var $ = function (id) { return document.getElementById(id); };

  var dashData = null;

  // Persist a scan both as the "latest" entry and keyed by tab, so side-panel
  // views can switch context when the active tab changes.
  function persistScan(data, ts, url, tabId) {
    try {
      if (!chrome.storage || !chrome.storage.session) return;
      chrome.storage.session.set({ wdScan: { data: data, ts: ts, url: url, tabId: tabId } });
      if (typeof tabId === "number") {
        chrome.storage.session.get("wdScanByTab", function (o) {
          var map = (o && o.wdScanByTab) || {};
          map[String(tabId)] = { data: data, ts: ts, url: url, tabId: tabId };
          var keys = Object.keys(map);
          if (keys.length > 12) {
            keys.sort(function (a, b) { return (map[a].ts || 0) - (map[b].ts || 0); })
              .slice(0, keys.length - 12).forEach(function (k) { delete map[k]; });
          }
          chrome.storage.session.set({ wdScanByTab: map });
        });
      }
    } catch (e) {}
  }
  var dashIssues = [];
  var dashTabId = null;
  var dashUrl = "";
  var dashTs = 0;
  var catsMap = {};

  var SECTIONS = [
    { key: "overview", label: "Overview", cats: [] },
    { key: "performance", label: "Performance & CWV", cats: ["performance", "cwv"] },
    { key: "dom", label: "DOM & Structure", cats: ["dom", "hidden", "structure"] },
    { key: "seo", label: "SEO", cats: ["seo"] },
    { key: "accessibility", label: "Accessibility", cats: ["accessibility"] },
    { key: "devices", label: "Devices", cats: ["responsive"] },
    { key: "javascript", label: "JavaScript", cats: ["javascript"] },
    { key: "css", label: "CSS", cats: ["css", "typography"] },
    { key: "images", label: "Images", cats: ["images"] },
    { key: "links", label: "Links", cats: ["links"] },
    { key: "forms", label: "Forms", cats: ["forms"] },
    { key: "technology", label: "Technology & Platform", cats: ["technology", "elementor", "security"] },
    { key: "ai", label: "AI Chat", cats: [] },
    { key: "reports", label: "Reports", cats: [] }
  ];

  function sevScale(i) {
    if (i.level === "critical") return "red";
    if (i.level === "warning") return "yellow";
    if (i.level === "good") return "green";
    return "gray";
  }

  function formatTs(ts) {
    if (!ts) return "unknown time";
    try {
      return new Date(ts).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "medium" });
    } catch (e) {
      return String(ts);
    }
  }

  function hostOf(url) {
    try { return new URL(url).hostname; } catch (e) { return url || ""; }
  }

  // ------------------------------------------------------------
  // States
  // ------------------------------------------------------------
  function showState(name) {
    var st = { loading: "dashStateLoading", noscan: "dashStateNoScan", error: "dashStateError" };
    Object.keys(st).forEach(function (k) {
      var el = $(st[k]);
      if (el) el.hidden = k !== name;
    });
    var panels = $("dashPanels");
    var app = $("dashApp");
    if (panels) panels.hidden = name !== "data";
    if (name === "noscan" || name === "loading" || name === "error") {
      $("dashNav").innerHTML = "";
    }
    if (app) app.setAttribute("data-state", name);
  }

  function showError(title, msg) {
    $("dashErrorTitle").textContent = title || "Scan unavailable";
    $("dashErrorMsg").textContent = msg || "The scan could not be completed.";
    hideOverlay();
    showState("error");
  }

  // ------------------------------------------------------------
  // Scan lifecycle
  // ------------------------------------------------------------
  function loadLatest() {
    showState("loading");
    if (!chrome.storage || !chrome.storage.session) {
      showState("noscan");
      $("dashNoScanError").textContent =
        "This browser does not expose chrome.storage.session, so the popup cannot share " +
        "its results here. In a supported Chrome build, scan once from the popup, then open the dashboard.";
      return;
    }
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var active = tabs && tabs[0] ? tabs[0] : null;
      chrome.storage.session.get(["wdScan", "wdScanByTab", "wdSidePanelTabId"], function (o) {
        if (chrome.runtime.lastError) {
          showState("noscan");
          $("dashNoScanError").textContent = chrome.runtime.lastError.message || "";
          return;
        }
        var chosen = null;
        if (o && o.wdSidePanelTabId != null && o.wdScanByTab && o.wdScanByTab[String(o.wdSidePanelTabId)]) {
          chosen = o.wdScanByTab[String(o.wdSidePanelTabId)];
        }
        if (!chosen && active && o && o.wdScanByTab && o.wdScanByTab[String(active.id)]) {
          chosen = o.wdScanByTab[String(active.id)];
        }
        if (!chosen && o && o.wdScan) chosen = o.wdScan;
        if (!chosen || !chosen.data || !chosen.data.page || !chosen.data.page.url) {
          showState("noscan");
          return;
        }
        dashTabId = typeof chosen.tabId === "number" ? chosen.tabId : null;
        dashUrl = chosen.url || chosen.data.page.url || "";
        dashTs = chosen.ts || 0;
        enterData(chosen.data);
      });
    });
  }

  function enterData(data) {
    dashData = data;
    dashIssues = WD.collectIssues(data);
    catsMap = {};
    dashIssues.forEach(function (i) {
      (catsMap[i.category] = catsMap[i.category] || []).push(i);
    });
    hideOverlay();
    renderAll();
    showState("data");
    applyHash();
  }

  function applyHash() {
    var h = (location.hash || "").replace("#", "");
    if (h && SECTIONS_BY_KEY[h]) activate(h);
  }

  function overlay(text, sub) {
    var ov = $("dashOverlay");
    ov.hidden = false;
    $("dashOverlayTitle").textContent = text || "Scanning\u2026";
    $("dashOverlayMsg").textContent = sub || "";
    $("dashOverlayMsg").className = "";
  }

  function overlayErr(msg) {
    $("dashOverlayTitle").textContent = "Scan failed";
    $("dashOverlayMsg").textContent = msg || "Unknown error";
    $("dashOverlayMsg").className = "err";
    var dwell = Math.min(9000, Math.max(3200, 1400 + String(msg || "").length * 45));
    setTimeout(hideOverlay, dwell);
  }

  function hideOverlay() { $("dashOverlay").hidden = true; }

  function pickTarget(cb) {
    var tryStored = dashTabId !== null;
    var useStored = function () {
      chrome.tabs.get(dashTabId, function (tab) {
        if (!chrome.runtime.lastError && tab && /^https?:/i.test(tab.url || "")) {
          cb(null, dashTabId);
          return;
        }
        pickActive(cb);
      });
    };
    if (tryStored) useStored();
    else pickActive(cb);
  }

  function pickActive(cb) {
    chrome.tabs.query({}, function (tabs) {
      if (chrome.runtime.lastError) { cb("Could not list tabs: " + chrome.runtime.lastError.message); return; }
      var self = chrome.runtime.getURL("dashboard.html");
      var first = null;
      var activeOne = null;
      (tabs || []).forEach(function (t) {
        if (!t || !t.url) return;
        if (t.url.indexOf(self) === 0) return;
        if (!/^https?:/i.test(t.url)) return;
        if (!first) first = t;
        if (t.active) activeOne = t;
      });
      var best = activeOne || first;
      if (!best) { cb("No scannable tab found. Open the website to audit in a normal tab, then press Rescan."); return; }
      cb(null, best.id);
    });
  }

  function runScan(silent) {
    overlay("Scanning\u2026", "Injecting the analyzer into the target tab and collecting real measurements.");
    pickTarget(function (err, tabId) {
      if (err) { overlayErr(err); return; }
      chrome.runtime.sendMessage({ action: "analyzeTab", tabId: tabId }, function (res) {
        if (chrome.runtime.lastError) { overlayErr(chrome.runtime.lastError.message); return; }
        if (!res || !res.success) {
          overlayErr((res && res.error) || "The analyzer did not respond on that tab. Reload the page and try again.");
          return;
        }
        var data = res.data;
        var ts = Date.now();
        var url = (data && data.page && data.page.url) || "";
        persistScan(data, ts, url, tabId);
        dashTabId = tabId;
        dashUrl = url;
        dashTs = ts;
        enterData(data);
      });
    });
  }

  // ------------------------------------------------------------
  // Render helpers
  // ------------------------------------------------------------
  function chip(label, value, cls) {
    if (value === null || value === undefined || value === "") return "";
    return '<div class="dash-chip"><b class="' + (cls || "gray") + '">' + esc(value) + '</b><span>' + esc(label) + '</span></div>';
  }

  function chips(rows) {
    var html = "";
    (rows || []).forEach(function (r) { html += chip(r[0], r[1], r[2]); });
    return html ? '<div class="dash-metric-chips">' + html + "</div>" : "";
  }

  function sectIcon(key) {
    return WD.WD_CAT_ICONS[key] || WD.WD_CAT_ICONS.responsive || WD.WD_CAT_ICONS.other;
  }

  function head(key, blurb) {
    return '<div class="dash-section-head"><h2>' + sectIcon(key) + esc(SECTIONS_BY_KEY[key].label) + "</h2>"
      + (blurb ? "<p>" + esc(blurb) + "</p>" : "") + "</div>";
  }

  var SECTIONS_BY_KEY = {};
  SECTIONS.forEach(function (s) { SECTIONS_BY_KEY[s.key] = s; });

  function issueCard(i) {
    var d = WD.wdIssueDetail(i);
    var itemsHtml = "";
    if (i.items && i.items.length) {
      itemsHtml = i.items.slice(0, 8).map(function (it) {
        var sn = (it.snippet !== undefined && it.snippet !== null)
          ? '<span class="issue-snippet">' + esc(String(it.snippet)) + "</span>" : "";
        return '<div class="issue-elem"><code>' + esc(it.selector || "?") + "</code>"
          + (it.url ? '<span class="mono">' + esc(it.url) + "</span>" : "")
          + sn + "</div>";
      }).join("");
      itemsHtml = '<div class="fact"><code>Affected elements</code><div class="issue-elems">' + itemsHtml + "</div></div>";
    }
    var body = '<div class="dash-issue-body" hidden>'
      + '<div class="fact"><code>Evidence</code><div>' + esc(d.evidence) + "</div></div>"
      + '<div class="fact"><code>Why it matters</code><div>' + esc(d.why) + "</div></div>"
      + '<div class="fact"><code>Fix</code><div>' + esc(d.fix) + "</div></div>"
      + '<div class="fact"><code>Measured with</code><div class="mono">' + esc(d.tech) + "</div></div>"
      + itemsHtml
      + "</div>";
    return '<div class="dash-issue" data-sev="' + i.level + '">'
      + '<div class="dash-issue-head" role="button" tabindex="0" aria-expanded="false">'
      + '<span class="issue-label ' + esc(i.level) + '">' + esc(i.level) + "</span>"
      + '<span class="dash-issue-title">' + esc(i.title) + "</span>"
      + '<span class="chev" aria-hidden="true">' + WD.WD_CHEV_DOWN + "</span>"
      + "</div>" + body + "</div>";
  }

  function issueList(issues) {
    if (!issues.length) {
      return '<div class="issues-empty"><b>No issues found here</b><span>That check is passing — real values were measured, nothing to report.</span></div>';
    }
    return '<div class="dash-issue-grid">' + issues.map(issueCard).join("") + "</div>";
  }

  function sumIssues(issues) {
    var s = { critical: 0, warning: 0, info: 0, good: 0 };
    issues.forEach(function (i) { if (s[i.level] !== undefined) s[i.level]++; });
    return s;
  }

  function sectionIssues(cats) {
    var out = [];
    cats.forEach(function (k) { (catsMap[k] || []).forEach(function (i) { out.push(i); }); });
    return out;
  }

  function catBlurb(cats) {
    for (var i = 0; i < cats.length; i++) {
      if (WD.WD_TECH[cats[i]]) return WD.WD_TECH[cats[i]];
    }
    return "Analyzed from the live page scan.";
  }

  function statusRows(list) {
    var s = sumIssues(list);
    return '<div class="dash-metric-chips">'
      + chip("Critical", s.critical, "red")
      + chip("Warnings", s.warning, "yellow")
      + chip("Info", s.info, "gray")
      + chip("Passing checks", s.good, "green")
      + "</div>";
  }

  // One combined chip strip per section: severity counts AND the section's own
  // measured numbers live in the same grid. Rendering them as two separate
  // .dash-metric-chips blocks stacked identical-looking rows was the main thing
  // making the dashboard read as unpolished.
  function sectionChips(key, list) {
    var s = sumIssues(list);
    var rows = [
      ["Critical", s.critical, "red"],
      ["Warnings", s.warning, "yellow"],
      ["Info", s.info, "gray"],
      ["Passing checks", s.good, "green"]
    ];
    return chips(rows.concat(metricRows(key)));
  }

  // ------------------------------------------------------------
  // Section renderers
  // ------------------------------------------------------------
  function renderSection(secEl, s) {
    var issues = sectionIssues(s.cats);
    secEl.innerHTML = head(s.key, catBlurb(s.cats))
      + sectionChips(s.key, issues)
      + issueList(issues);
  }

  // renderSection + an optional deep-dive block (detailed tables / galleries)
  // inserted between the metric chips and the issue cards.
  function renderSectionWithExtra(secEl, s, extraHtml) {
    var issues = sectionIssues(s.cats);
    secEl.innerHTML = head(s.key, catBlurb(s.cats))
      + sectionChips(s.key, issues)
      + (extraHtml || "")
      + issueList(issues);
  }

  // ---- Devices section + Responsive Breakpoint Audit ---------------------
  // The Devices panel hosts the full responsive issue list AND the breakpoint
  // audit tooling (moved out of the popup): it scans the live page at 1280 /
  // 1024 / 768 / 390 px and offers conservative suggested CSS for anything
  // provably broken right now. The dashboard is itself a focused tab, so every
  // live-page tool names its target through pickTarget() instead of reading
  // the browser's "active tab" (which would be the dashboard itself).
  var deviceAuditAutoRan = false;
  var lastDeviceAudit = null;
  var deviceActiveBp = null;
  var deviceView = "after";
  var deviceSource = "page";

  function fixKindLabel(kind) {
    return {
      pageOverflow: "horizontal overflow",
      oversizedContainers: "fixed-width container",
      minWidthFloors: "min-width floor",
      oversizedImages: "oversized image",
      textOverflow: "text overflow",
      offscreen: "off-screen element",
      overPadding: "fixed padding wider than the viewport"
    }[kind] || kind;
  }

  function deviceAuditStatus(msg, kind) {
    var st = document.getElementById("respAuditStatus");
    if (!st) return;
    if (msg) {
      st.textContent = msg;
      st.className = "devmod-status" + (kind ? " " + kind : "");
    } else {
      st.className = "devmod-status hidden";
      st.textContent = "";
    }
  }

  function devmodStatus(id, msg, kind) {
    var st = document.getElementById(id);
    if (!st) return;
    if (msg) {
      st.textContent = msg;
      st.className = "devmod-status" + (kind ? " " + kind : "");
    } else {
      st.className = "devmod-status hidden";
      st.textContent = "";
    }
  }

  function deviceFixCssText(fixes) {
    return fixes.map(function (f, i) {
      return "/* Suggested fix " + (i + 1) + " \u2014 " + (f.kindLabel || f.kind) + " */\n" + f.sel + " { " + f.css + " }";
    }).join("\n\n");
  }

  function deviceToolMsg(payload, cb) {
    pickTarget(function (err, tabId) {
      if (err) { if (cb) cb(null, err); return; }
      if (!chrome.tabs || !chrome.tabs.sendMessage) { if (cb) cb(null, "Cannot reach this page. Run an analysis first."); return; }
      var injectedOnce = false;
      var attempt = function () {
        chrome.tabs.sendMessage(tabId, payload, function (res) {
          if (chrome.runtime.lastError) {
            if (!injectedOnce) {
              injectedOnce = true;
              if (chrome.scripting && chrome.scripting.executeScript) {
                chrome.scripting.executeScript({ target: { tabId: tabId }, files: ["content.js"] }, function () {
                  if (chrome.runtime.lastError) {
                    if (cb) cb(null, chrome.runtime.lastError.message || "Cannot reach this page. Run an analysis first.");
                    return;
                  }
                  setTimeout(function () {
                    chrome.tabs.sendMessage(tabId, payload, function (res2) {
                      if (chrome.runtime.lastError) { if (cb) cb(null, "Cannot reach this page. Run an analysis first."); return; }
                      if (cb) cb(res2, null);
                    });
                  }, 80);
                });
              } else {
                if (cb) cb(null, "Cannot reach this page. Run an analysis first.");
              }
            } else {
              if (cb) cb(null, "Cannot reach this page. Run an analysis first.");
            }
            return;
          }
          if (cb) cb(res, null);
        });
      };
      attempt();
    });
  }

  function locateOnTarget(selector, cb) {
    pickTarget(function (err, tabId) {
      if (err) { if (cb) cb(null, err); return; }
      var locateFn = function (sel) {
        var el = null;
        try { el = document.querySelector(sel); } catch (e) { el = null; }
        if (!el) return { success: false, error: "Element not found on the page." };
        try { el.scrollIntoView({ behavior: "smooth", block: "center" }); } catch (e) {}
        setTimeout(function () {
          var r;
          try { r = el.getBoundingClientRect(); } catch (e) { return; }
          var ov = document.createElement("div");
          ov.style.cssText = "position:fixed;z-index:2147483647;pointer-events:none;border:3px solid #ef4444;background:rgba(239,68,68,0.08);border-radius:4px;transition:opacity .6s ease;";
          ov.style.left = r.left + "px";
          ov.style.top = r.top + "px";
          ov.style.width = r.width + "px";
          ov.style.height = r.height + "px";
          document.body.appendChild(ov);
          setTimeout(function () { ov.style.opacity = "0"; }, 2200);
          setTimeout(function () { if (ov.parentNode) { ov.parentNode.removeChild(ov); } }, 3000);
        }, 140);
        return { success: true };
      };
      if (!chrome.scripting || !chrome.scripting.executeScript) { if (cb) cb(null, "Could not locate the element."); return; }
      chrome.scripting.executeScript({ target: { tabId: tabId }, func: locateFn, args: [selector] }, function (results) {
        if (chrome.runtime.lastError) {
          deviceToolMsg({ action: "locateLink", selector: selector }, cb);
          return;
        }
        if (cb) cb(results && results[0] && results[0].result, null);
      });
    });
  }

  function deviceCopy(text, cb) {
    var ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.cssText = "position:fixed;top:0;left:-9999px;opacity:0;width:1px;height:1px;";
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    if (cb) cb(ok);
  }

  function runResponsiveAudit(userInitiated) {
    deviceAuditAutoRan = true;
    var scanBtn = document.getElementById("btnResponsiveScan");
    if (scanBtn && userInitiated) scanBtn.disabled = true;
    deviceAuditStatus("Scanning the live page at 1280 \u00B7 1024 \u00B7 768 \u00B7 390 px\u2026", "busy");
    deviceToolMsg({ action: "responsiveaudit" }, function (res, err) {
      if (scanBtn && userInitiated) scanBtn.disabled = false;
      if (err || !res || !res.success) {
        deviceAuditStatus((err || (res && res.error)) || "Could not scan \u2014 run a page analysis first.", "error");
        return;
      }
      lastDeviceAudit = (res && res.data) || null;
      deviceSource = "page";
      renderResponsiveAudit(lastDeviceAudit);
      var apply = document.getElementById("btnResponsiveFixApply");
      var restore = document.getElementById("btnResponsiveFixRestore");
      var hasFixes = !!(lastDeviceAudit && lastDeviceAudit.fixes && lastDeviceAudit.fixes.length);
      if (apply) apply.disabled = !hasFixes;
      if (restore) restore.disabled = false;
      deviceAuditStatus(hasFixes
        ? "Audit complete \u2014 suggested fixes are ready below (temporary until you restore or reload)."
        : "Audit complete \u2014 nothing provably broken at these widths.", hasFixes ? "" : "ok");
    });
  }

  function maybeAutoResponsiveAudit() {
    if (!dashData || deviceAuditAutoRan) return;
    runResponsiveAudit(false);
  }

  function runAutoInspect() {
    var btn = document.getElementById("btnAutoInspect");
    if (btn) btn.disabled = true;
    devmodStatus("autoInspectStatus", "Opening one clean Incognito-capable window (no cache, no user session, no other extensions) \u2014 auditing mobile \u00B7 tablet \u00B7 desktop\u2026", "busy");
    pickTarget(function (err, tabId) {
      if (err) {
        if (btn) btn.disabled = false;
        devmodStatus("autoInspectStatus", err, "error");
        return;
      }
      chrome.tabs.get(tabId, function (tab) {
        var url = (tab && tab.url) || "";
        if (!/^https?:\/\//i.test(url)) {
          if (btn) btn.disabled = false;
          devmodStatus("autoInspectStatus", "Open a webpage (http/https) first \u2014 internal Chrome pages cannot be audited.", "error");
          return;
        }
        var testUrl = null;
        try { testUrl = new URL(url); } catch (e) { testUrl = null; }
        if (!testUrl) {
          if (btn) btn.disabled = false;
          devmodStatus("autoInspectStatus", "Could not parse the current page URL.", "error");
          return;
        }
        // Always asks Chrome for a real Incognito window. When "Allow in
        // Incognito" is off the window still opens (isolated, as asked) but the
        // analyzer cannot run inside it, so we report that precisely instead of
        // silently auditing a normal window.
        chrome.runtime.sendMessage({ action: "deviceAutoAudit", url: url }, function (res) {
          if (btn) btn.disabled = false;
          if (chrome.runtime.lastError || !res || !res.success) {
            var wOpened = !!(res && res.windowOpened);
            devmodStatus("autoInspectStatus", (res && res.error) || "Could not run the clean audit.", wOpened ? "warn" : "error");
            return;
          }
          var incog = res.incognito !== false;
          lastDeviceAudit = (res && res.data) || null;
          deviceAuditAutoRan = true;
          deviceSource = incog ? "incognito" : "clean";
          deviceActiveBp = null;
          deviceView = "after";
          renderResponsiveAudit(lastDeviceAudit);
          var apply = document.getElementById("btnResponsiveFixApply");
          var restore = document.getElementById("btnResponsiveFixRestore");
          var hasFixes = !!(lastDeviceAudit && lastDeviceAudit.fixes && lastDeviceAudit.fixes.length);
          if (apply) apply.disabled = !hasFixes;
          if (restore) restore.disabled = false;
          deviceAuditStatus(hasFixes
            ? (incog ? "Clean Incognito" : "Clean fresh-window") + " audit complete \u2014 the exact suggested CSS is ready below (Apply is temporary \u2014 restore or reload reverts)."
            : (incog ? "Clean Incognito" : "Clean fresh-window") + " audit complete \u2014 nothing provably broken at these widths.", hasFixes ? "" : "ok");
          devmodStatus("autoInspectStatus", hasFixes
            ? "Clean audit done. Switch between \u201CSuggested Fix\u201D and \u201CCurrent CSS\u201D above to review, then Apply or Copy."
            : "Clean audit done \u2014 no broken items found in the isolated " + (incog ? "Incognito" : "fresh") + " window.", hasFixes ? "" : "ok");
        });
      });
    });
  }

  function renderResponsiveAudit(data) {
    var box = document.getElementById("responsiveBreakpoints");
    if (!box || !data) return;
    var bps = data.breakpoints || [];
    var fixes = data.fixes || [];
    var fixByKey = Object.create(null);
    fixes.forEach(function (f) { fixByKey[f.kind + "|" + f.sel] = f.css; });

    function esc(s) { return WD.escapeHtml(String(s == null ? "" : s)); }

    function beforeLines(before) {
      var lines = (before || "").split(";").map(function (s) { return s.trim(); }).filter(Boolean);
      return lines.length ? lines.map(function (s) { return "  " + s + ";"; }) : [];
    }

    if (!deviceActiveBp && bps.length) {
      var vw = data.currentWidth || 1280;
      var best = bps[0], bestGap = Infinity;
      bps.forEach(function (b) {
        var gap = Math.abs(b.width - vw);
        if (gap < bestGap) { bestGap = gap; best = b; }
      });
      deviceActiveBp = best.width;
    }
    var active = null;
    bps.forEach(function (b) { if (b.width === deviceActiveBp) active = b; });

    if (!bps.length) {
      box.innerHTML = '<div class="devmod-empty">Scan returned no data \u2014 try again.</div>';
      return;
    }

    var anyOff = false;
    bps.forEach(function (b) { b.checks.forEach(function (c) { if (c.offenders && c.offenders.length) anyOff = true; }); });

    var html = '<div class="devmod-summary"><span><b>' + bps.length + '</b> breakpoints scanned</span>'
      + (data.totalBroken
        ? '<span class="devmod-chip devmod-pill-bad">' + data.totalBroken + ' provably broken right now</span>'
        : '<span class="devmod-chip devmod-pill-ok">nothing provably broken</span>')
      + (deviceSource === "incognito"
        ? '<span class="devmod-chip devmod-pill-ok">clean Incognito environment</span>'
        : '')
      + '<span class="devmod-sum-note">Red = broken today \u00B7 amber = verify by eye \u00B7 fixes are suggestions, applied temporarily.</span></div>';

    if (anyOff) {
      html += '<div class="bp-view-toggle">'
        + '<button type="button" data-view="after" class="' + (deviceView === "after" ? "active" : "") + '">Suggested Fix</button>'
        + '<button type="button" data-view="before" class="' + (deviceView === "before" ? "active" : "") + '">Current CSS</button>'
        + '</div>';
    }

    html += '<div class="devmod-chips">';
    bps.forEach(function (b) {
      var bad = b.checks.reduce(function (a, c) { return a + (c.status === 2 ? 1 : 0); }, 0);
      var cat = b.width >= 1200 ? "desktop" : (b.width >= 960 ? "laptop" : (b.width >= 600 ? "tablet" : "phone"));
      html += '<button type="button" class="devmod-chips-chip' + (b.width === deviceActiveBp ? " active" : "") + '" data-w="' + b.width + '">'
        + b.width + 'px \u00B7 ' + cat
        + (bad ? ' <span class="devmod-chip devmod-pill-bad">' + bad + '</span>' : '') + '</button>';
    });
    html += '</div>';

    if (active) {
      active.checks.forEach(function (c) {
        var pill = c.status === 2
          ? '<span class="devmod-chip devmod-pill-bad">broken</span>'
          : (c.status === 1 ? '<span class="devmod-chip devmod-pill-warn">check</span>' : '<span class="devmod-chip devmod-pill-ok">ok</span>');
        html += '<div class="wspc-check">' + pill + ' <b>' + esc(c.label) + '</b> \u2014 ' + esc(c.message) + '</div>';
        (c.offenders || []).slice(0, 4).forEach(function (o) {
          if (!o || !o.sel) return;
          var css = fixByKey[c.id + "|" + o.sel] || "";
          var codeLines;
          if (deviceView === "after") {
            if (css) {
              codeLines = ['/* Suggested fix \u2014 ' + fixKindLabel(c.id) + ' */', o.sel + ' {', '  ' + css, '}'];
            } else {
              codeLines = ['/* No automatic fix for this one.', c.id === "overPadding"
                ? '  The fixed padding itself must shrink to a fluid value (site decision).'
                : '  Review this element by eye at this width.', '*/'];
            }
          } else {
            var lines = beforeLines(o.before);
            codeLines = ['/* Current computed CSS \u2014 before fix */', o.sel + ' {'];
            if (lines.length) codeLines = codeLines.concat(lines);
            else codeLines.push('  /* computed defaults */');
            codeLines.push('}');
          }
          html += '<div class="wspc-off">'
            + '<span class="wspc-off-head"><code class="devmod-code">' + esc(o.label) + '</code>'
            + (css ? '<span class="devmod-chip devmod-pill-bad">fix available</span>' : '<span class="devmod-chip devmod-pill-warn">human check</span>')
            + '</span>'
            + '<pre class="devmod-pre"><code>' + codeLines.map(esc).join("\n") + '</code></pre>'
            + '<div class="devmod-actions">'
            + '<button type="button" class="devmod-act" data-act="locate" data-sel="' + esc(o.sel) + '">Locate</button>'
            + (css
              ? '<button type="button" class="devmod-act" data-act="copy-fix" data-sel="' + esc(o.sel) + '" data-css="' + esc(css) + '">Copy fix CSS</button>'
                + '<button type="button" class="devmod-act" data-act="apply-fix" data-sel="' + esc(o.sel) + '" data-css="' + esc(css) + '">Apply to page</button>'
              : '')
            + '</div></div>';
        });
      });
    }
    box.innerHTML = html;

    box.querySelectorAll(".bp-view-toggle [data-view]").forEach(function (b) {
      b.addEventListener("click", function () {
        deviceView = b.getAttribute("data-view");
        renderResponsiveAudit(data);
      });
    });
    box.querySelectorAll(".devmod-chips-chip").forEach(function (chip) {
      chip.addEventListener("click", function () {
        deviceActiveBp = parseInt(chip.getAttribute("data-w"), 10);
        renderResponsiveAudit(data);
      });
    });
    box.querySelectorAll("[data-act='locate']").forEach(function (btn) {
      btn.addEventListener("click", function (ev) {
        ev.stopPropagation();
        locateOnTarget(btn.getAttribute("data-sel"), function (ok, err) {
          deviceAuditStatus(err
            ? err
            : (ok && ok.success ? "Located \u2014 highlighted on the page." : "Could not locate that element \u2014 the page may have changed."),
            err ? "error" : "");
        });
      });
    });
    box.querySelectorAll("[data-act='copy-fix']").forEach(function (btn) {
      btn.addEventListener("click", function (ev) {
        ev.stopPropagation();
        var sel = btn.getAttribute("data-sel");
        var css = btn.getAttribute("data-css");
        deviceCopy(sel + " { " + css + " }", function (ok) {
          btn.textContent = ok ? "Copied \u2713" : "Copy failed";
          setTimeout(function () { btn.textContent = "Copy fix CSS"; }, 1400);
        });
      });
    });
    box.querySelectorAll("[data-act='apply-fix']").forEach(function (btn) {
      btn.addEventListener("click", function (ev) {
        ev.stopPropagation();
        var sel = btn.getAttribute("data-sel");
        var css = btn.getAttribute("data-css");
        deviceToolMsg({ action: "csstoolsApply", css: sel + " { " + css + " }" }, function (res, err) {
          if (err || !res || !res.success) {
            deviceAuditStatus((err || (res && res.error)) || "Could not apply the fix.", "error");
            return;
          }
          var restore = document.getElementById("btnResponsiveFixRestore");
          if (restore) restore.disabled = false;
          deviceAuditStatus("Fix applied to the live page (temporary). Restore or reload reverts it.", "ok");
        });
      });
    });
  }

  function applySuggestedFixes() {
    if (!lastDeviceAudit || !lastDeviceAudit.fixes || !lastDeviceAudit.fixes.length) return;
    deviceToolMsg({ action: "csstoolsApply", css: deviceFixCssText(lastDeviceAudit.fixes) }, function (res, err) {
      if (err || !res || !res.success) {
        deviceAuditStatus((err || (res && res.error)) || "Could not apply the suggested fixes.", "error");
        return;
      }
      var restore = document.getElementById("btnResponsiveFixRestore");
      if (restore) restore.disabled = false;
      deviceAuditStatus("All suggested fixes applied to the live page \u2014 review them now. Restore or reload reverts.", "ok");
    });
  }

  function restoreSuggestedFixes() {
    deviceToolMsg({ action: "csstoolsClear" }, function (res) {
      if (!res || !res.success) { deviceAuditStatus("Could not restore.", "error"); return; }
      deviceAuditStatus("Restored \u2014 temporary styles removed.", "ok");
    });
  }

  function deviceAuditCard() {
    return '<div class="wd-detail-block"><h3 class="wd-detail-title">Responsive Breakpoint Audit</h3>'
      + '<p class="wd-detail-note">Scans the live page at four standard breakpoints (1280 &middot; 1024 &middot; 768 &middot; 390). <b>Advanced Auto-Inspect</b> re-runs the audit in one clean Incognito Chrome window &mdash; no cached styles, no user session, no other extensions. Toggle between the <b>Suggested Fix</b> code and the <b>Current CSS</b> to see exactly what changes. Items marked <b>broken</b> are provably broken at that width (fixed width wider than the viewport, real text truncation, an element off-screen, or padding wider than the viewport), so their CSS is a concrete fix, never a guess. Apply is a temporary stylesheet &mdash; restore or reload reverts.</p>'
      + '<div class="devmod-row"><button id="btnAutoInspect" class="btn-analyze" type="button">Advanced Auto-Inspect</button><span id="autoInspectStatus" class="devmod-status hidden"></span></div>'
      + '<div class="devmod-row"><button id="btnResponsiveScan" class="btn-analyze" type="button">Scan Live Page</button>'
      + '<button id="btnResponsiveFixApply" class="btn-apply" type="button" disabled>Apply suggested fixes</button>'
      + '<button id="btnResponsiveFixRestore" class="btn-ghost" type="button" disabled>Restore</button>'
      + '<span id="respAuditStatus" class="devmod-status hidden"></span></div>'
      + '<div id="responsiveBreakpoints" class="devmod-results"></div></div>';
  }

  function renderDeviceSection(secEl, s) {
    var issues = sectionIssues(s.cats);
    secEl.innerHTML = head("devices", catBlurb(s.cats))
      + statusRows(issues)
      + metricsFor("devices")
      + deviceAuditCard()
      + issueList(issues);
  }

  // ---- Deep-dive detail blocks ------------------------------------------

  // Full link inventory: every URL with its type, health status and text.
  function linkDetailTable(lk) {
    var list = (lk && lk.detail && lk.detail.length) ? lk.detail : [];
    if (!list.length) {
      return '<div class="wd-detail-block"><h3 class="wd-detail-title">' + esc("All links \u00B7 " + ((lk && lk.total) || 0)) + "</h3>"
        + '<p class="wd-detail-note">Individual URL detail appears after a fresh scan of the page.</p></div>';
    }
    var rows = list.map(function (l) {
      var kindCls = l.kind === "external" ? "wd-badge neutral" : (l.kind === "internal" ? "wd-badge ok" : "wd-badge warn");
      var statusCls = l.status === "ok" ? "wd-badge ok" : "wd-badge bad";
      var statusTxt = { "placeholder": "placeholder", "empty": "empty href", "javascript": "js url", "fragment-missing": "missing #target", "invalid": "invalid", "ok": "ok" }[l.status] || l.status;
      return '<div class="wd-row">'
        + '<div class="wd-row-main">'
        + '<span class="wd-url" title="' + esc(l.href) + '">' + esc(l.href) + "</span>"
        + (l.text ? '<span class="wd-sub">' + esc(l.text) + "</span>" : "")
        + (l.path ? '<span class="wd-sub mono">@ ' + esc(l.path) + "</span>" : "")
        + "</div>"
        + '<span class="wd-cell"><span class="' + kindCls + '">' + esc(l.kind) + '</span></span>'
        + '<span class="wd-cell"><span class="' + statusCls + '">' + esc(statusTxt) + "</span></span>"
        + "</div>";
    }).join("");
    return '<div class="wd-detail-block"><h3 class="wd-detail-title">' + esc("All links \u00B7 " + list.length + " URLs") + "</h3>"
      + '<div class="wd-list" role="table" aria-label="All detected links">'
      + '<div class="wd-head"><span class="wd-row-main">URL / text / location</span><span class="wd-cell">Type</span><span class="wd-cell">Status</span></div>'
      + rows + "</div></div>";
  }

  // Full image gallery: preview, alt status, real file size and dimensions.
  // --- image downloads --------------------------------------------
  var imgDownloadList = [];

  function fileNameFor(src, i) {
    var u = String(src || "");
    var noQ = u.split("#")[0].split("?")[0];
    var base = noQ.substring(noQ.lastIndexOf("/") + 1) || "";
    if (!base || base.indexOf(".") === -1) {
      var m = /^data:image\/([a-z0-9.+-]+)/i.exec(u);
      var ext = m ? m[1].replace(/^jpeg$/i, "jpg") : (/svg\+xml/i.test(u) ? "svg" : "png");
      base = "image-" + (i + 1) + "." + ext;
    }
    return base.replace(/[^\w.\-]+/g, "_").slice(0, 90) || ("image-" + (i + 1) + ".png");
  }

  function saveBlobUrl(obj, name) {
    var a = document.createElement("a");
    a.href = obj; a.download = name;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
  }

  function downloadUrl(url, name, cb) {
    url = String(url || "");
    if (/^data:image\//i.test(url)) {
      try {
        var comma = url.indexOf(",");
        var meta = url.slice(5, comma);
        var body = url.slice(comma + 1);
        var mime = (meta.split(";")[0]) || "image/png";
        var bytes;
        if (/;base64/i.test(meta)) {
          var bin = atob(body);
          bytes = new Uint8Array(bin.length);
          for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        } else {
          var txt = decodeURIComponent(body);
          bytes = new Uint8Array(txt.length);
          for (var j = 0; j < txt.length; j++) bytes[j] = txt.charCodeAt(j);
        }
        var obj = URL.createObjectURL(new Blob([bytes], { type: mime }));
        saveBlobUrl(obj, name);
        setTimeout(function () { URL.revokeObjectURL(obj); }, 1500);
        if (cb) cb(true);
        return;
      } catch (e) { if (cb) cb(false); return; }
    }
    try {
      if (window.chrome && chrome.downloads && chrome.downloads.download) {
        chrome.downloads.download({ url: url, filename: "webdoctor-images/" + name, conflictAction: "uniquify" }, function (id) {
          var err = chrome.runtime && chrome.runtime.lastError;
          if (cb) cb(!err && id !== undefined);
        });
        return;
      }
    } catch (e) {}
    var a = document.createElement("a");
    a.href = url; a.download = name; a.target = "_blank"; a.rel = "noopener";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    if (cb) cb(true);
  }

  function flashDlButton(btn, text, cls) {
    if (!btn) return;
    var orig = btn.getAttribute("data-label") || btn.textContent;
    btn.setAttribute("data-label", orig);
    btn.className = "wd-dl" + (cls ? " " + cls : "");
    btn.textContent = text;
    setTimeout(function () { btn.className = "wd-dl"; btn.textContent = orig; }, 1700);
  }

  function downloadImageAt(i) {
    var item = imgDownloadList[i];
    if (!item || !item.src) return;
    var btn = document.querySelector('[data-img-dl="' + i + '"]');
    if (btn) btn.disabled = true;
    downloadUrl(item.src, fileNameFor(item.src, i), function (ok) {
      if (btn) btn.disabled = false;
      if (ok) flashDlButton(btn, "\u2713 saved", "done");
      else flashDlButton(btn, "failed", "");
    });
  }

  function downloadAllImages(btn) {
    if (!imgDownloadList.length) return;
    var total = imgDownloadList.length, done = 0, ok = 0;
    if (btn) btn.disabled = true;
    function step() {
      if (done >= total) {
        if (btn) {
          btn.disabled = false;
          btn.textContent = "Downloaded " + ok + "/" + total;
          setTimeout(function () { btn.textContent = "Download all \u00B7 " + total; }, 2800);
        }
        return;
      }
      var i = done++;
      if (btn) btn.textContent = "Downloading " + done + "/" + total + "\u2026";
      downloadUrl(imgDownloadList[i].src, (i + 1) + "-" + fileNameFor(imgDownloadList[i].src, i), function (good) {
        if (good) ok++;
        setTimeout(step, 130);
      });
    }
    step();
  }

  function imageDetailGallery(im) {
    var list = (im && im.details && im.details.length) ? im.details : [];
    if (!list.length) {
      imgDownloadList = [];
      return '<div class="wd-detail-block"><h3 class="wd-detail-title">' + esc("All images \u00B7 " + ((im && im.total) || 0)) + "</h3>"
        + '<p class="wd-detail-note">Complete image detail appears after a fresh scan of the page.</p></div>';
    }
    var total = list.length;
    if (list.length > 400) list = list.slice(0, 400);
    imgDownloadList = list;
    var tiles = list.map(function (img, idx) {
      var altCls = img.broken ? "wd-badge bad" : img.missingAlt ? "wd-badge bad" : img.emptyAlt ? "wd-badge warn" : "wd-badge ok";
      var altTxt = img.broken ? "broken" : img.missingAlt ? "no alt" : img.emptyAlt ? 'empty alt ""' : "alt ok";
      var size = img.fileSize ? fmtBytes(img.fileSize) : "n/a";
      var dims = (img.naturalWidth && img.naturalHeight)
        ? img.naturalWidth + "\u00D7" + img.naturalHeight
        : (img.naturalWidth || img.naturalHeight ? (img.naturalWidth || "?") + "\u00D7" + (img.naturalHeight || "?") : "unknown");
      var flags = [];
      if (img.isSVG) flags.push('<span class="wd-tag">SVG</span>');
      if (img.lazy) flags.push('<span class="wd-tag">lazy</span>');
      if (img.noDimensions) flags.push('<span class="wd-tag warn">no w/h</span>');
      return '<div class="wd-img-tile">'
        + '<div class="wd-img-frame"><img class="wd-thumb" loading="lazy" src="' + esc(img.src) + '" alt="" title="' + esc(img.src) + '"></div>'
        + '<div class="wd-img-meta"><span class="' + altCls + '">' + altTxt + "</span>" + flags.join("") + "</div>"
        + '<span class="wd-img-src" title="' + esc(img.src) + '">' + esc(img.src) + "</span>"
        + '<span class="wd-img-sub">' + dims + " \u00B7 " + size + (img.path ? ' \u00B7 <span class="mono">' + esc(img.path) + "</span>" : "") + "</span>"
        + (img.alt ? '<span class="wd-img-alt">alt: ' + esc(img.alt) + "</span>" : "")
        + '<div class="wd-dl-wrap"><button class="wd-dl" type="button" data-img-dl="' + idx + '" title="Download ' + esc(fileNameFor(img.src, idx)) + '">\u2B07 ' + esc(fileNameFor(img.src, idx)) + "</button></div>"
        + "</div>";
    }).join("");
    var note = total > list.length
      ? '<p class="wd-detail-note">Showing the first ' + list.length + " of " + total + " detected images \u2014 download buttons export the shown set.</p>"
      : "";
    return '<div class="wd-detail-block"><h3 class="wd-detail-title">' + esc("All images \u00B7 " + list.length + (im && im.total !== list.length ? " of " + im.total : ""))
      + '<button class="wd-dl-all" type="button" data-img-dl-all>Download all \u00B7 ' + list.length + "</button></h3>"
      + note
      + '<div class="wd-img-grid">' + tiles + "</div></div>";
  }

  // ------------------------------------------------------------
  // Developer DOM analysis (deep-dive block for the DOM section)
  // ------------------------------------------------------------
  function domStat(v, label, cls) {
    if (v === null || v === undefined || v === "") return "";
    var disp = typeof v === "number" ? v.toLocaleString() : v;
    return '<div class="dom-stat"><b class="' + (cls || "") + '">' + esc(disp) + '</b><span>' + esc(label) + "</span></div>";
  }

  function domSelOf(h) {
    if (typeof h === "string") return h;
    return (h && (h.selector || h.sel || h.label || h.tag)) || "";
  }

  function domAuditBlock(dom) {
    if (!dom) return "";
    var dup = dom.duplicateIds || [];
    var hotspots = (dom.hotspots || []).slice(0, 12);
    var tree = dom.domTree || [];

    var stats = '<div class="dom-stat-row">'
      + domStat(dom.totalElements, "elements")
      + domStat(dom.totalNodes, "nodes")
      + domStat(dom.maxDepth, "max depth", dom.maxDepth >= 15 ? "yellow" : "")
      + domStat(dom.maxChildren, "widest parent")
      + domStat(dom.emptyElements, "empty elements", dom.emptyElements ? "yellow" : "")
      + domStat(dom.inlineStyleCount, "inline styles", dom.inlineStyleCount > 20 ? "yellow" : "")
      + domStat(dom.inlineStyleBytes ? fmtBytes(dom.inlineStyleBytes) : null, "inline style bytes")
      + domStat(dom.nestedContainerCount, "nested containers", dom.nestedContainerCount > 80 ? "yellow" : "")
      + domStat(dom.maxContainerNesting, "container depth", dom.maxContainerNesting >= 8 ? "yellow" : "")
      + domStat(dom.hiddenElements, "hidden elements")
      + domStat(dom.containerCount, "container elements")
      + domStat(dom.excessiveNestingCount, "excessive nesting", dom.excessiveNestingCount ? "red" : "green")
      + "</div>";

    var census = [
      ["div", dom.divCount], ["article", dom.articleCount], ["header", dom.headerCount],
      ["footer", dom.footerCount], ["main", dom.mainCount], ["nav", dom.navCount],
      ["form", dom.formCount], ["input", dom.inputCount], ["button", dom.buttonCount],
      ["a", dom.linkCount], ["img", dom.imageCount], ["iframe", dom.iframeCount],
      ["script", dom.scriptCount], ["style", dom.styleCount]
    ].filter(function (r) { return r[1]; });
    var censusHtml = census.map(function (r) {
      return '<span class="wd-tag">' + esc(r[0]) + " " + esc(r[1]) + "</span>";
    }).join("");

    var hotspotHtml;
    if (hotspots.length) {
      hotspotHtml = '<div class="dom-hotspot-list">' + hotspots.map(function (h) {
        var sel = domSelOf(h);
        var count = h && (h.count || h.matches || h.elements);
        var why = h && (h.reason || h.kind || h.type || h.note);
        var size = h && (h.bytes ? fmtBytes(h.bytes) : (h.nodes ? h.nodes + " nodes" : (h.size || "")));
        var meta = [count ? count + " matches" : "", size, why].filter(Boolean).join(" \u00B7 ");
        return '<div class="dom-hotspot"><div class="dom-hotspot-label"><b title="' + esc(sel) + '">' + esc(sel || "(unknown)") + "</b>"
          + (meta ? "<span>" + esc(meta) + "</span>" : "") + "</div>"
          + (sel ? '<button class="dom-locate-btn" type="button" data-dom-act="locate" data-sel="' + esc(sel) + '">locate</button>' : "")
          + "</div>";
      }).join("") + "</div>";
    } else {
      hotspotHtml = '<p class="wd-detail-note">No oversized or over-repeated subtrees were flagged in this scan.</p>';
    }

    var dupHtml;
    if (dup.length) {
      dupHtml = '<div class="dom-hotspot-list">' + dup.slice(0, 12).map(function (x) {
        var id = typeof x === "string" ? x : (x && (x.id || x.value)) || "";
        var n = (typeof x === "object" && x && x.count) || 0;
        return '<div class="dom-hotspot"><div class="dom-hotspot-label"><b>#' + esc(id) + "</b><span>duplicate id"
          + (n ? " \u00B7 " + n + "\u00D7" : "") + "</span></div>"
          + '<button class="dom-locate-btn" type="button" data-dom-act="locate" data-sel="#' + esc(id) + '">locate</button></div>';
      }).join("") + "</div>";
    } else {
      dupHtml = '<p class="wd-detail-note">Every id on the page is unique \u2014 clean CSS/JS targeting.</p>';
    }

    var treeHtml = "";
    if (tree.length) {
      var lines = tree.map(function (n) {
        var depth = typeof n.depth === "number" ? n.depth : 0;
        return new Array(depth + 1).join("  ") + "<" + (n.tag || "?") + ">"
          + (typeof n.children === "number" ? "  (" + n.children + " children)" : "");
      }).join("\n");
      treeHtml = '<details class="dom-details"><summary>DOM tree snapshot \u00B7 ' + tree.length + " nodes</summary>"
        + '<div class="body"><div class="dom-tree-box"><pre>' + esc(lines) + "</pre></div></div></details>";
    }

    var topHtml = "";
    var ts = dom.topSection;
    if (ts && (ts.label || ts.count)) {
      topHtml = '<div class="dom-sub-title">Heaviest subtree</div><div class="dom-stat-row">'
        + domStat(ts.label, "container")
        + domStat(ts.count, "elements")
        + domStat(typeof ts.share === "number" ? ts.share + "%" : null, "of page DOM")
        + domStat(ts.depth, "depth")
        + domStat(ts.nodes, "nodes")
        + "</div>";
    }

    var eleHtml = "";
    var el = dom.elementor;
    if (el && el.detected) {
      eleHtml = '<div class="dom-sub-title">Elementor deep-dive</div><div class="dom-stat-row">'
        + domStat(el.containers, "containers")
        + domStat(el.nestedContainers, "nested", el.nestedContainers ? "yellow" : "")
        + domStat(el.deepContainers, "deep (3+)", el.deepContainers ? "red" : "green")
        + domStat(el.maxNesting, "max nesting")
        + domStat(el.share ? el.share + "%" : null, "DOM share")
        + domStat(el.legacySections, "legacy sections")
        + domStat(el.flexContainers, "flex containers")
        + "</div>"
        + (el.excessive && el.excessive.message ? '<p class="wd-detail-note">' + esc(el.excessive.message) + "</p>" : "");
      if (el.heaviest && el.heaviest.length) {
        eleHtml += '<div class="dom-hotspot-list">' + el.heaviest.slice(0, 8).map(function (h) {
          var sel = domSelOf(h);
          return '<div class="dom-hotspot"><div class="dom-hotspot-label"><b>' + esc(sel || "(widget)") + "</b><span>"
            + esc(h.widget || h.type || "elementor widget") + "</span></div>"
            + (sel ? '<button class="dom-locate-btn" type="button" data-dom-act="locate" data-sel="' + esc(sel) + '">locate</button>' : "")
            + "</div>";
        }).join("") + "</div>";
      }
    }

    return '<div class="wd-detail-block"><h3 class="wd-detail-title">' + esc("Developer DOM analysis")
      + '<span class="dash-count">' + esc((dom.totalElements ? dom.totalElements.toLocaleString() : "?") + " elements") + "</span></h3>"
      + '<div class="dom-tools-row">'
      + '<button class="dom-tool-btn" type="button" data-dom-act="console">Log findings to page console</button>'
      + '<button class="dom-tool-btn" type="button" data-dom-act="elementor">Re-inspect Elementor live</button>'
      + '<span class="dom-tool-status" id="domToolStatus"></span></div>'
      + stats
      + (censusHtml ? '<div class="dom-sub-title">Tag census</div><div class="dom-chip-row">' + censusHtml + "</div>" : "")
      + topHtml
      + '<div class="dom-sub-title">DOM hotspots</div>' + hotspotHtml
      + '<div class="dom-sub-title">Duplicate ids</div>' + dupHtml
      + eleHtml
      + treeHtml
      + "</div>";
  }

  // Granular accessibility findings: full iframe inventory (src + title + location).
  function accessibilityDetailBlock(acc) {
    var iframes = (acc && acc.details && acc.details.iframes && acc.details.iframes.length) ? acc.details.iframes : [];
    if (!iframes.length) {
      if (acc && acc.iframesNoTitle === 0) return "";
      return '<div class="wd-detail-block"><h3 class="wd-detail-title">' + esc("Iframe inventory \u00B7 " + (acc && acc.iframesNoTitle ? acc.iframesNoTitle : 0)) + "</h3>"
        + '<p class="wd-detail-note">Individual iframe detail appears after a fresh scan of the page.</p></div>';
    }
    var rows = iframes.map(function (f) {
      return '<div class="wd-row">'
        + '<div class="wd-row-main">'
        + '<span class="wd-url" title="' + esc(f.src || "(inline)") + '">' + esc(f.src || "(inline frame)") + "</span>"
        + (f.path ? '<span class="wd-sub mono">@ ' + esc(f.path) + "</span>" : "")
        + "</div>"
        + '<span class="wd-cell"><span class="' + (f.hasTitle ? "wd-badge ok" : "wd-badge bad") + '">' + (f.hasTitle ? "has title" : "no title") + "</span></span>"
        + '<span class="wd-cell mono">' + esc(f.title) + "</span>"
        + "</div>";
    }).join("");
    return '<div class="wd-detail-block"><h3 class="wd-detail-title">' + esc("Iframes \u00B7 " + iframes.length) + "</h3>"
      + '<div class="wd-list" role="table" aria-label="All detected iframes">'
      + '<div class="wd-head"><span class="wd-row-main">Source / location</span><span class="wd-cell">Title</span><span class="wd-cell">Name</span></div>'
      + rows + "</div></div>";
  }

  function metricsFor(key) {
    return chips(metricRows(key));
  }

  function metricRows(key) {
    var d = dashData, rows = [];
    if (key === "dom") {
      rows.push(["DOM elements", d.dom && d.dom.totalElements ? d.dom.totalElements.toLocaleString() : null, "gray"]);
      rows.push(["Max depth", d.dom && d.dom.maxDepth, "gray"]);
      rows.push(["Duplicate IDs", d.dom && d.dom.duplicateIds.length, d.dom && d.dom.duplicateIds.length ? "red" : "green"]);
      rows.push(["Inline styles", d.dom && d.dom.inlineStyleCount, "gray"]);
      rows.push(["Empty elements", d.dom && d.dom.emptyElements, "gray"]);
      rows.push(["Nested containers", d.dom && d.dom.nestedContainerCount, "gray"]);
    }
    if (key === "seo") {
      rows.push(["SEO score", d.scores && typeof d.scores.seo === "number" ? d.scores.seo + "/100" : null, (d.scores && d.scores.seo >= 80) ? "green" : (d.scores && d.scores.seo >= 50) ? "yellow" : "red"]);
      rows.push(["Title", d.seo && d.seo.hasTitle ? d.seo.titleLength + " chars" : "missing", !d.seo || !d.seo.hasTitle ? "red" : (d.seo.titleOk ? "green" : "yellow")]);
      rows.push(["Description", d.seo && d.seo.hasDescription ? d.seo.descriptionLength + " chars" : "missing", !d.seo || !d.seo.hasDescription ? "red" : (d.seo.descriptionOk ? "green" : "yellow")]);
      rows.push(["Canonical", d.seo && d.seo.hasCanonical ? "set" : "missing", !d.seo || !d.seo.hasCanonical ? "yellow" : "green"]);
      rows.push(["H1", d.headings && d.headings.hasH1 ? d.headings.counts.h1 + " found" : "missing", !d.headings || !d.headings.hasH1 ? "red" : "green"]);
    }
    if (key === "accessibility") {
      rows.push(["Images missing alt", d.accessibility && d.accessibility.imagesMissingAlt, d.accessibility && d.accessibility.imagesMissingAlt ? "red" : "green"]);
      rows.push(["Inputs without labels", d.accessibility && d.accessibility.inputsNoLabel, d.accessibility && d.accessibility.inputsNoLabel ? "yellow" : "green"]);
      rows.push(["Buttons no name", d.accessibility && d.accessibility.buttonsNoName, d.accessibility && d.accessibility.buttonsNoName ? "yellow" : "green"]);
      rows.push(["Links no text", d.accessibility && d.accessibility.linksNoText, d.accessibility && d.accessibility.linksNoText ? "yellow" : "green"]);
      rows.push(["Iframes no title", d.accessibility && d.accessibility.iframesNoTitle, d.accessibility && d.accessibility.iframesNoTitle ? "yellow" : "green"]);
    }
    if (key === "devices") {
      rows.push(["Viewport meta", d.page && typeof d.page.viewport === "string" ? (d.page.viewport ? "declared" : "missing") : null, d.page && !d.page.viewport ? "yellow" : "green"]);
    }
    if (key === "javascript") {
      var p = d.performance || {};
      rows.push(["Script tags", p.scriptTagCount, "gray"]);
      rows.push(["External scripts", p.externalScriptCount, "gray"]);
      if (p.inlineScriptBytes) rows.push(["Inline JS bytes", fmtBytes(p.inlineScriptBytes), p.inlineScriptBytes > 40 * 1024 ? "yellow" : "green"]);
      if (p.jsBytes) rows.push(["JS payload", fmtBytes(p.jsBytes), p.jsBytes > 600 * 1024 ? "yellow" : "green"]);
    }
    if (key === "css") {
      var p2 = d.performance || {};
      if (p2.cssCount) rows.push(["Stylesheets", p2.cssCount, "gray"]);
      if (p2.cssBytes) rows.push(["CSS payload", fmtBytes(p2.cssBytes), p2.cssBytes > 300 * 1024 ? "yellow" : "green"]);
      if (d.dom && d.dom.inlineStyleCount) rows.push(["Inline style attrs", d.dom.inlineStyleCount, "gray"]);
    }
    if (key === "images") {
      var im = d.images || {};
      if (im.total) rows.push(["Images", im.total, "gray"]);
      if (im.withAlt) rows.push(["With alt", im.withAlt, "green"]);
      if (im.withoutAlt) rows.push(["Without alt", im.withoutAlt, im.withoutAlt ? "red" : "green"]);
    }
    if (key === "links") {
      var lk = d.links || {};
      if (lk.total) rows.push(["Links", lk.total, "gray"]);
      if (typeof lk.external === "number") rows.push(["External", lk.external, "gray"]);
      var brk = (d.brokenLinks && d.brokenLinks.counts && d.brokenLinks.counts.broken) || 0;
      rows.push(["Broken / JS targets", brk, brk ? "red" : "green"]);
    }
    if (key === "forms") {
      var a = d.accessibility || {};
      if (a.inputsNoLabel !== undefined) rows.push(["Inputs without labels", a.inputsNoLabel, a.inputsNoLabel ? "yellow" : "green"]);
    }
    return rows;
  }

  // ------------------------------------------------------------
  // Overview
  // ------------------------------------------------------------
  function renderOverview(secEl) {
    var d = dashData;
    var scores = d.scores || {};
    var overall = typeof scores.overall === "number" ? scores.overall : 0;
    var color = overall >= 80 ? "#059669" : overall >= 50 ? "#d97706" : "#dc2626";
    var verdict = overall >= 90 ? "Excellent" : overall >= 80 ? "Good" : overall >= 60 ? "Fair" : "Needs work";
    var C = 2 * Math.PI * 52;
    var stroke = (C * overall) / 100;

    var banner = "";
    if (d.scanNotice && d.scanNotice.partial) {
      banner = '<div class="scan-notice" role="status"><b>Partial scan:</b> ' + esc(d.scanNotice.message || "Some analyzers reported incomplete data.") + "</div>";
    }

    var s = sumIssues(dashIssues);
    var severity = "<div class='dash-metric-chips'>"
      + chip("Critical", s.critical, "red")
      + chip("Warnings", s.warning, "yellow")
      + chip("Info", s.info, "gray")
      + chip("Passing", s.good, "green")
      + "</div>";

    var bars = "";
    var maxBySec = {};
    SECTIONS.forEach(function (sec) {
      var n = sectionIssues(sec.cats).filter(function (i) { return i.level === "critical" || i.level === "warning"; }).length;
      if (sec.cats.length && n > 0) maxBySec[sec.key] = n;
    });
    var barMax = 1;
    Object.keys(maxBySec).forEach(function (k) { if (maxBySec[k] > barMax) barMax = maxBySec[k]; });
    var barsHtml = "";
    var barIdx = 0;
    SECTIONS.forEach(function (sec) {
      if (!sec.cats.length) return;
      var n = maxBySec[sec.key] || 0;
      var pct = Math.round((n / barMax) * 100);
      barsHtml += '<div class="overview-bar" style="--i:' + (barIdx++) + '"><span class="overview-bar-label">' + esc(sec.label) + "</span>"
        + '<span class="overview-bar-track"><span class="overview-bar-fill" style="width:' + pct + '%;background:' + (n ? color : "#2f3a5e") + '"></span></span>'
        + '<span class="overview-bar-count">' + n + "</span></div>";
    });

    var cwvTiles = WD.cwvOf(d.performance);
    var cwvHtml = '<div class="cwv-grid">' + cwvTiles.map(function (m) {
      return '<div class="cwv-tile ' + (m.ok ? m.key : "") + '">'
        + '<div class="cwv-label"><b>' + m.label + '</b><span title="' + esc(m.full) + '">' + esc(m.full) + '</span></div>'
        + '<div class="cwv-value ' + m.cls + '">' + (m.ok ? m.display : "\u2014") + (m.ok && m.unit ? "<small>" + m.unit + "</small>" : "") + "</div>"
        + '<div class="cwv-verdict' + (m.ok ? "" : " na-text") + '">' + esc(m.judgment) + "</div>"
        + "</div>";
    }).join("") + "</div>";
    cwvHtml += '<div class="cwv-note">Measured from the live page at scan time. ' + esc(WD.naNote(d.performance)) + "</div>";

    var timing = timingRow(d.performance);

    // Actionable first: criticals before warnings, and items you can locate
    // (per-element evidence) before count-only findings.
    var top = dashIssues.filter(function (i) { return i.level === "critical" || i.level === "warning"; })
      .sort(function (a, b) {
        var la = a.level === "critical" ? 0 : 1, lb = b.level === "critical" ? 0 : 1;
        if (la !== lb) return la - lb;
        var ea = (a.items && a.items.length) ? 0 : 1, eb = (b.items && b.items.length) ? 0 : 1;
        return ea - eb;
      }).slice(0, 6);
    var html = '<div class="dash-section-head"><h2>' + (WD.WD_CAT_ICONS.overview || WD.WD_CAT_ICONS.other) + esc(SECTIONS_BY_KEY.overview.label) + "</h2></div>";
    html += banner + severity;
    html += '<div class="overview-score-grid">'
      + '<div class="card overview-card"><h3 class="card-title">Overall health</h3>'
      + '<div class="score-ring-wrap"><svg class="score-ring" viewBox="0 0 124 124" aria-label="Overall score ' + overall + ' out of 100">'
      + '<circle class="score-ring-bg" cx="62" cy="62" r="52"/><circle class="score-ring-fg" cx="62" cy="62" r="52" style="stroke:' + color + ';stroke-dasharray:' + stroke + " " + C + '"/>'
      + '<text x="62" y="62" text-anchor="middle" dominant-baseline="central" class="score-ring-text" style="fill:' + color + '">' + Math.round(overall) + '</text>'
      + "</svg>"
      + '<div class="score-ring-verdict">' + esc(verdict) + '</div></div></div>'
      + '<div class="card"><h3 class="card-title">Issues by area</h3>' + barsHtml + "</div>"
      + "</div>";
    html += '<div class="card"><h3 class="card-title">Core Web Vitals</h3>' + cwvHtml + timing + "</div>";
    if (top.length) {
      html += '<div class="card"><h3 class="card-title">Top issues</h3>' + issueList(top) + "</div>";
    }
    secEl.innerHTML = html;
  }

  function timingRow(p) {
    if (!p) return "";
    var rows = [];
    function r(label, val, unit, cls) {
      if (val === null || val === undefined) return;
      var disp = unit === "s" ? (val / 1000).toFixed(2) + "s" : unit === "ms" ? val + "ms" : String(val);
      rows.push('<div class="stat-row"><span class="stat-row-label">' + esc(label) + '</span><span class="stat-row-value ' + (cls || "") + '">' + esc(disp) + "</span></div>");
    }
    r("Server response (TTFB)", p.ttfb, "ms", WD.getPerfStatus(p.ttfb, 800, 1800));
    r("First Paint", p.firstPaint, "s", WD.getPerfStatus(p.firstPaint, 1500, 2500));
    r("First Contentful Paint", p.firstContentfulPaint, "s", WD.getPerfStatus(p.firstContentfulPaint, 1800, 3000));
    r("DOMContentLoaded", p.domContentLoaded, "s", WD.getPerfStatus(p.domContentLoaded, 1500, 3000));
    r("Page load time", p.loadTime, "s", WD.getPerfStatus(p.loadTime, 1500, 3000));
    var out = "";
    rows.forEach(function (row) { out += row; });
    return out ? '<div class="dash-timing">' + out + "</div>" : "";
  }

  // ------------------------------------------------------------
  // Performance panel
  // ------------------------------------------------------------
  function renderPerformance(secEl) {
    var p = dashData.performance || {};
    var issues = sectionIssues(["performance", "cwv"]);
    var html = head("performance", WD.WD_TECH.performance) + sectionChips("performance", issues);

    var cwvTiles = WD.cwvOf(p);
    html += '<div class="card"><h3 class="card-title">Core Web Vitals</h3><div class="cwv-grid">'
      + cwvTiles.map(function (m) {
        return '<div class="cwv-tile ' + (m.ok ? m.key : "") + '">'
          + '<div class="cwv-label"><b>' + m.label + '</b><span title="' + esc(m.full) + '">' + esc(m.full) + '</span></div>'
          + '<div class="cwv-value ' + m.cls + '">' + (m.ok ? m.display : "\u2014") + (m.ok && m.unit ? "<small>" + m.unit + "</small>" : "") + "</div>"
          + '<div class="cwv-verdict' + (m.ok ? "" : " na-text") + '">' + esc(m.judgment) + "</div>"
          + "</div>";
      }).join("")
      + '</div><div class="cwv-note">Measured from the live page at scan time. ' + esc(WD.naNote(p)) + "</div></div>";

    html += '<div class="card"><h3 class="card-title">Timing</h3>' + (timingRow(p) || '<div class="empty-state">No timing values were reported.</div>') + "</div>";

    var net = "";
    net += perfStat("Requests", p.resourceCount, p.resourceCount > 100 ? "red" : p.resourceCount > 60 ? "yellow" : "green");
    net += statRow("Total transferred", p.totalTransferred ? fmtBytes(p.totalTransferred) : "n/a", "");
    net += statRow("Document (HTML)", p.documentBytes > 0 ? fmtBytes(p.documentBytes) : "n/a", "");
    net += statRow("All resources", p.resourceBytes > 0 ? fmtBytes(p.resourceBytes) : "n/a", "");
    net += perfStat("Third-party requests", p.thirdPartyCount, p.thirdPartyCount > 20 ? "yellow" : "green");
    html += '<div class="card dash-card-grid"><div><h3 class="card-title">Network</h3>' + net + "</div>";

    var res = "";
    res += resStat("JavaScript", p.jsCount, p.jsBytes, byteStatus(p.jsBytes, 600 * 1024, 1024 * 1024));
    res += resStat("CSS", p.cssCount, p.cssBytes, byteStatus(p.cssBytes, 300 * 1024, 600 * 1024));
    res += resStat("Images", p.imageCount, p.imageBytes, byteStatus(p.imageBytes, 2 * 1024 * 1024, 4 * 1024 * 1024));
    res += resStat("Fonts", p.fontCount, p.fontBytes, byteStatus(p.fontBytes, 400 * 1024, 800 * 1024));
    res += resStat("Media", p.mediaCount, p.mediaBytes, "");
    res += resStat("Iframes", p.iframeCount, null, "");
    res += resStat("XHR / Fetch", p.xhrCount, p.xhrBytes, "");
    res += resStat("Other", p.otherCount, p.otherBytes, "");
    html += "<div><h3 class='card-title'>Payload by type</h3>" + res + "</div></div>";

    if (p.largeResources && p.largeResources.length) {
      html += '<div class="card"><h3 class="card-title">Largest resources</h3><div class="perf-large-note">Resources over 200KB transferred.</div>'
        + p.largeResources.map(function (r) {
          return '<div class="lr-item"><span class="lr-name">' + esc(r.name) + '</span><span class="lr-meta">' + fmtBytes(r.bytes) + " transferred \u00B7 " + esc(r.type) + "</span></div>";
        }).join("") + "</div>";
    }

    html += issueList(issues);
    secEl.innerHTML = html;
  }

  function perfStat(label, val, cls) {
    if (val === null || val === undefined) return statRow(label, "Not available", "gray");
    return statRow(label, val.toLocaleString(), cls || "");
  }
  function resStat(label, count, bytes, cls) {
    var v = "0";
    if (count !== null && count !== undefined) v = count.toLocaleString();
    if (bytes) v += " \u00B7 " + fmtBytes(bytes);
    return statRow(label, v, cls || "");
  }
  function byteStatus(bytes, warn, bad) {
    if (!bytes) return "green";
    if (bad && bytes > bad) return "red";
    if (bytes > warn) return "yellow";
    return "green";
  }
  function statRow(label, value, cls) {
    return '<div class="stat-row"><span class="stat-row-label">' + esc(String(label)) + '</span><span class="stat-row-value ' + (cls || "") + '">' + esc(String(value)) + "</span></div>";
  }

  // ------------------------------------------------------------
  // Technology panel
  // ------------------------------------------------------------
  var PLATFORM_GUIDES = {
    wordpress: {
      label: "WordPress",
      focus: "Self-hosted CMS \u00B7 PHP \u00B7 plugin + theme stack",
      wins: [
        ["Plugin payload", "Every active plugin can enqueue CSS/JS on every page. Count script/style tags and retire plugins you do not use."],
        ["Page-builder output", "Elementor/Divi wrap content in deep containers \u2014 watch container nesting depth and inline style bytes."],
        ["Caching + CDN", "Serve cached HTML and static assets from a CDN; uncached TTFB is the usual LCP bottleneck."],
        ["Image sizing", "Regenerate thumbnails so 300px slots never download full-size originals."]
      ]
    },
    shopify: {
      label: "Shopify",
      focus: "Managed e-commerce \u00B7 Liquid themes \u00B7 app widgets",
      wins: [
        ["Theme + app JS", "Duplicate jQuery/theme bundles and app scripts dominate payload \u2014 defer non-critical scripts."],
        ["Product media", "Large hero/product images cause CLS; reserve width/height and serve responsive srcset."],
        ["Checkout handoff", "Cart/checkout links leave the theme \u2014 verify they are real links, not JS-only handlers."],
        ["App widgets", "Third-party widgets inject blocking CSS/JS \u2014 audit which apps load above the fold."]
      ]
    },
    wix: {
      label: "Wix",
      focus: "Website builder \u00B7 runtime-driven \u00B7 rich media",
      wins: [
        ["Wix runtime", "The builder ships a large runtime; keep above-the-fold content static where possible."],
        ["Hero media", "Compress and correctly size hero images/video \u2014 they drive LCP."],
        ["Embedded apps", "Embeds and third-party widgets shift layout; reserve space to protect CLS."],
        ["Layout shift", "Fixed-position and late-injected elements usually cause CLS \u2014 pin their dimensions."]
      ]
    },
    bigcommerce: {
      label: "BigCommerce",
      focus: "SaaS e-commerce \u00B7 Stencil themes \u00B7 app scripts",
      wins: [
        ["Stencil bundle", "Theme bundle size sets the JS floor \u2014 tree-shake and defer non-critical modules."],
        ["App scripts", "Marketplace apps inject scripts/CSS \u2014 audit which load on every page."],
        ["Product images", "Optimize product/category media and enable responsive images."],
        ["Search assets", "Search and faceted-nav widgets are heavy \u2014 lazy-load them below the fold."]
      ]
    }
  };

  function platformSignals(slug, d) {
    d = d || {};
    var p = d.performance || {}, dom = d.dom || {}, im = d.images || {};
    var rows = [];
    function add(label, val, cls) { if (val !== null && val !== undefined && val !== "") rows.push(domStat(val, label, cls)); }
    var jsBad = (p.jsBytes || 0) > 600 * 1024;
    var cssBad = (p.cssBytes || 0) > 300 * 1024;
    var imgBad = (p.imageBytes || 0) > 1500 * 1024;
    var domHeavy = (dom.totalElements || 0) > 2500 || (dom.maxDepth || 0) >= 15;
    var thirdBad = (p.thirdPartyCount || 0) > 15;
    add("Script tags", p.scriptTagCount, (p.scriptTagCount || 0) > 15 ? "yellow" : "green");
    add("JS payload", p.jsBytes ? fmtBytes(p.jsBytes) : null, jsBad ? "yellow" : "green");
    add("CSS payload", p.cssBytes ? fmtBytes(p.cssBytes) : null, cssBad ? "yellow" : "green");
    add("Image weight", p.imageBytes ? fmtBytes(p.imageBytes) : null, imgBad ? "yellow" : "green");
    add("Third-party requests", p.thirdPartyCount, thirdBad ? "yellow" : "green");
    add("DOM elements", dom.totalElements ? dom.totalElements.toLocaleString() : null, domHeavy ? "yellow" : "green");
    add("Max depth", dom.maxDepth, (dom.maxDepth || 0) >= 15 ? "yellow" : "green");
    add("Inline style bytes", dom.inlineStyleBytes ? fmtBytes(dom.inlineStyleBytes) : null, (dom.inlineStyleBytes || 0) > 40 * 1024 ? "yellow" : "green");
    add("Images missing alt", im.missingAlt, im.missingAlt ? "yellow" : "green");
    return rows.join("");
  }

  function renderTechnology(secEl) {
    var tech = dashData.technology || {};
    var platform = WD.platformOf(tech);

    var html = head("technology", WD.WD_TECH.technology) + sectionChips("technology", sectionIssues(["technology", "elementor", "security"]));
    var techNames = [];
    (tech.groups || {}).cms && tech.groups.cms.forEach(function (t) { techNames.push(t.name || t); });
    var allNames = [];
    Object.keys(tech.groups || {}).forEach(function (k) {
      (tech.groups[k] || []).forEach(function (t) {
        if (t && t.name) allNames.push({ group: k, name: t.name, note: t.note || "" });
      });
    });

    if (platform.known) {
      html += '<div class="card"><h3 class="card-title">Platform blueprint \u2014 ' + esc(platform.label) + "</h3>"
        + '<p class="card-hint">' + esc(platform.hint) + "</p>"
        + '<div class="dom-stat-row">' + platformSignals(platform.slug, dashData) + "</div>"
        + '<div class="dom-chip-row" style="margin-top:10px">' + (platform.checks || []).map(function (c) {
            return '<span class="wd-tag">' + esc(c) + "</span>";
          }).join("") + "</div></div>";
    }

    var guideKeys = ["wordpress", "shopify", "wix", "bigcommerce"];
    html += '<div class="card"><h3 class="card-title">Platform playbooks \u2014 WordPress \u00B7 Shopify \u00B7 Wix \u00B7 BigCommerce</h3>'
      + '<p class="card-hint">Targeted developer checks for the four most common platforms, ranked against the signals this scan already measured.</p>'
      + '<div class="platform-plan">' + guideKeys.map(function (k) {
        var g = PLATFORM_GUIDES[k];
        if (!g) return "";
        var isMe = platform.known && (platform.slug === k
          || (k === "wordpress" && platform.slug === "elementor")
          || (k === "wix" && (platform.slug === "wixsite" || platform.slug === "wix")));
        return '<div class="pp-card">'
          + (isMe ? '<span class="pp-badge">Detected on this page</span>' : "")
          + "<h4>" + esc(g.label) + "</h4>"
          + '<div class="pp-stack">' + esc(g.focus) + "</div>"
          + "<ul>" + g.wins.map(function (w) {
            return "<li><b>" + esc(w[0]) + "</b> \u2014 " + esc(w[1]) + "</li>";
          }).join("") + "</ul></div>";
      }).join("") + "</div></div>";

    if (allNames.length) {
      html += '<div class="card"><h3 class="card-title">Detected technologies</h3>'
        + allNames.map(function (t) {
          return '<div class="lr-item"><span class="lr-name">' + esc(t.name) + '</span><span class="lr-meta">' + esc(t.group) + (t.note ? " \u00B7 " + esc(t.note) : "") + "</span></div>";
        }).join("") + "</div>";
    } else {
      html += '<div class="card"><h3 class="card-title">Detected technologies</h3><div class="empty-state">No well-known technology signatures were detected on this page.</div></div>';
    }

    html += issueList(sectionIssues(["technology", "elementor", "security"]));
    secEl.innerHTML = html;
  }


  // ============================================================
  // AUDIT FILE + SITE CRAWLER
  // Moved here from the popup's Audit tab, which has been removed.
  // Rebound onto the dashboard's data and helpers: dashData replaces
  // currentData, and WD.escapeHtml / WD.formatBytes / WD.collectIssues
  // replace the popup-local copies. The popup's downloadBlob is renamed
  // downloadReportBlob because the dashboard already has one of its own.
  // ============================================================
﻿  // ============================================
  // AUDIT FILE TAB
  // ============================================
  var auditBlobUrl = null;
  var auditDoc = null;
  var auditData = null;
  var auditDocsDoc = null;

  function buildAuditReport(data, word) {
    word = !!word;
    var issues = WD.collectIssues(data);
    var critical = issues.filter(function (i) { return i.level === "critical"; });
    var warning = issues.filter(function (i) { return i.level === "warning"; });
    var good = issues.filter(function (i) { return i.level === "good"; });
    var info = issues.filter(function (i) { return i.level === "info"; });
    var scores = (data && data.scores) || {};
    var page = (data && data.page) || {};
    var dom = (data && data.dom) || {};
    var perf = (data && data.performance) || {};
    var seo = (data && data.seo) || {};
    var a11y = (data && data.accessibility) || {};
    var formsData = (data && data.forms) || {};
    var imagesData = (data && data.images) || {};
    var linksData = (data && data.links) || {};
    var brokenLinksData = (data && data.brokenLinks) || {};
    var responsive = (data && data.responsive) || {};
    var techData = (data && data.technology) || {};
    var hintCount = (responsive.layoutHints && responsive.layoutHints.length) || 0;
    var techTotal = 0;
    var techGroups = techData.groups || {};
    Object.keys(techGroups).forEach(function (k) { techTotal += (techGroups[k] || []).length; });
    var now = new Date();
    var dateStr = now.toDateString() + " \u00B7 " + now.toLocaleTimeString();

    function esc(s) { return WD.escapeHtml(String(s === undefined || s === null ? "" : s)); }
    function num(v) { return (v === undefined || v === null) ? "n/a" : Number(v).toLocaleString(); }
    function row(label, value) {
      if (word) return '<tr><td style="width:38%;padding:3pt 6pt;border-bottom:1px solid #d9d9d9;vertical-align:top;font-size:9pt;font-weight:bold;color:#444;">' + esc(label) + '</td><td style="padding:3pt 6pt;border-bottom:1px solid #d9d9d9;vertical-align:top;font-size:9pt;">' + esc(value) + '</td></tr>';
      return "<tr><td>" + esc(label) + "</td><td>" + esc(value) + "</td></tr>";
    }

    // Snapshot rows for the categories the scan actually measured
    // (per-category scores are covered by the dedicated Scores section above).
    var rows = [
      row("Analyzed URL", page.url || "n/a"),
      row("Host", page.host || "n/a"),
      row("Page title", page.title || "n/a"),
      row("Total elements", num(dom.totalElements)),
      row("Total nodes", num(dom.totalNodes)),
      row("Max nesting depth", num(dom.maxDepth)),
      row("Duplicate IDs", dom.duplicateIds ? dom.duplicateIds.length : "n/a"),
      row("Empty elements", num(dom.emptyElements)),
      row("Load time", (perf.loadTime !== null && perf.loadTime !== undefined) ? (perf.loadTime / 1000).toFixed(1) + "s" : "n/a"),
      row("First Contentful Paint", (perf.firstContentfulPaint !== null && perf.firstContentfulPaint !== undefined) ? (perf.firstContentfulPaint / 1000).toFixed(1) + "s" : "n/a"),
      row("Resources", num(perf.resourceCount)),
      row("Third-party resources", num(perf.thirdPartyCount)),
      row("Images missing alt", num(a11y.imagesMissingAlt)),
      row("Inputs without labels", num(a11y.inputsNoLabel)),
      row("Title length", seo.titleLength !== undefined && seo.titleLength !== null ? seo.titleLength + " chars" : "n/a"),
      row("Meta description length", seo.descriptionLength !== undefined && seo.descriptionLength !== null ? seo.descriptionLength + " chars" : "n/a"),
      row("Forms", num(formsData.formCount) + (formsData.inputCount != null ? " \u00B7 " + formsData.inputCount + " inputs" : "")),
      row("Form fields without labels", num(formsData.missingLabels)),
      row("Images", num(imagesData.total) + (imagesData.svgCount ? " \u00B7 " + imagesData.svgCount + " SVG" : "")),
      row("Images missing alt", num(imagesData.missingAlt) + (imagesData.lazyLoaded != null ? " \u00B7 " + imagesData.lazyLoaded + " lazy" : "")),
      row("Alt coverage", (imagesData.total > 0 && imagesData.withAlt != null) ? Math.round((imagesData.withAlt / imagesData.total) * 100) + "%" : (imagesData.total ? "n/a" : "no images")),
      row("Inline styles", num(dom.inlineStyleCount) + (dom.inlineStyleBytes ? " \u00B7 " + WD.formatBytes(dom.inlineStyleBytes) : "")),
      row("Scripts", num(perf.jsCount) + " external \u00B7 " + num(perf.inlineScriptCount) + " inline" + (perf.jsBytes ? " \u00B7 " + WD.formatBytes(perf.jsBytes) : "")),
      row("Working links", num(linksData.total) + (linksData.external != null ? " \u00B7 " + linksData.external + " external" : "")),
      row("Broken links", brokenLinksData && brokenLinksData.counts ? num(brokenLinksData.counts.broken) : "n/a"),
      row("Missing accessible names", num((a11y.buttonsNoName || 0) + (a11y.linksNoText || 0) + (a11y.inputsNoLabel || 0) + (a11y.iframesNoTitle || 0) + (a11y.navsNoName || 0))),
      row("Responsive issues", num(hintCount)),
      row("Elementor structures", (dom.elementor && dom.elementor.detected) ? num(dom.elementor.containers) + (dom.elementor.maxNesting ? " \u00B7 max nesting " + num(dom.elementor.maxNesting) : "") : "not detected"),
      row("Technologies detected", num(techTotal))
    ];

    // One plain two-column "score sheet": every measured category shares the
    // same simple label/value row as the rest of the document.
    var scorePairs = [
      ["Overall score", scores.overall],
      ["DOM", scores.dom],
      ["Performance", scores.performance],
      ["SEO", scores.seo],
      ["Accessibility", scores.accessibility],
      ["Structure", scores.structure]
    ];
    ["technology", "forms", "links", "images", "responsive"].forEach(function (k) {
      if (scores[k] !== undefined && scores[k] !== null && scorePairs.length < 14) {
        scorePairs.push([k.charAt(0).toUpperCase() + k.slice(1), scores[k]]);
      }
    });
    var scoreHtml = scorePairs.map(function (p) {
      var v = (p[1] === undefined || p[1] === null) ? "n/a" : p[1] + "/100";
      return row(p[0], v);
    }).join("\n");

    function sec(label, bodyHtml) {
      if (word) return '<p style="margin:12pt 0 4pt;font-size:10.5pt;font-weight:bold;color:#111;border-bottom:1px solid #999;padding-bottom:2pt;">' + esc(label).toUpperCase() + '</p>\n' + bodyHtml + "\n";
      return '<h2>' + esc(label) + '</h2>\n' + bodyHtml + "\n";
    }

    function wIssueTable(rowsHtml) {
      return '<table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse;">' + rowsHtml + "</table>";
    }

    function issueRows(list, cls, chip) {
      if (!list.length) {
        if (word) return '<p style="margin:4pt 0;font-size:9pt;color:#777;font-style:italic;">Nothing found in this category \u2014 result is clean.</p>';
        return '<p class="empty">Nothing found in this category \u2014 result is clean.</p>';
      }
      if (word) {
        var wColor = cls === "critical" ? "#b91c1c" : cls === "warning" ? "#b45309" : cls === "info" ? "#2563eb" : "#15803d";
        var wBg = cls === "critical" ? "#fdf8f8" : cls === "warning" ? "#fbf7f0" : cls === "info" ? "#f0f4ff" : "#f6fbf8";
        return wIssueTable(list.map(function (i) {
          return '<tr><td style="border-left:3pt solid ' + wColor + ';background:' + wBg + ';padding:5pt 8pt;font-size:9pt;">'
            + '<b>' + esc(chip) + '</b> \u2014 <b>' + WD.escapeHtml(i.title) + '</b>'
            + '<div style="margin-top:2pt;color:#333;">' + WD.escapeHtml(i.desc) + '</div>'
            + (i.rec ? '<div style="margin-top:3pt;color:#555;font-style:italic;"><b>Recommendation:</b> ' + WD.escapeHtml(i.rec) + '</div>' : '')
            + '</td></tr>';
        }).join(""));
      }
      return list.map(function (i) {
        return '<div class="issue ' + cls + '"><span class="tag">' + esc(chip) + '</span>'
          + '<b>' + WD.escapeHtml(i.title) + '</b>'
          + '<p>' + WD.escapeHtml(i.desc) + '</p>'
          + (i.rec ? '<p class="rec"><b>Recommendation:</b> ' + WD.escapeHtml(i.rec) + '</p>' : '')
          + '</div>';
      }).join("\n");
    }

    // Every responsive hint carries a concrete fix for its signal kind, so
    // the audit file reads as remediation steps, not just observations.
    var HINT_FIX = {
      viewport: 'Add <meta name="viewport" content="width=device-width, initial-scale=1"> inside <head>.',
      overflow: "Give the overflowing element max-width:100% (or put overflow-x:hidden on a fluid wrapper).",
      "fixed-width": "Replace hard-coded pixel widths with max-width:100% (plus box-sizing:border-box) so boxes can shrink.",
      image: "Apply width:100%;height:auto to the large media so images scale down with the layout.",
      "text-overflow": "Let the text wrap (white-space:normal) or, inside flex/grid, give the child min-width:0 so it can shrink.",
      offscreen: "Remove fixed min-widths, replace them with max-width percentages, and let content wrap instead of pushing the page wide.",
      breakpoints: "Prefer mobile-first max-width breakpoints so small screens get a dedicated narrow layout."
    };
    function hintFix(h) {
      return HINT_FIX[h.kind] || "Inspect the flagged element at a 390px viewport and constrain whatever pushes past the right edge.";
    }
    function hintRows() {
      var list = responsive.layoutHints || [];
      if (!list.length) {
        if (word) return '<p style="margin:4pt 0;font-size:9pt;color:#777;font-style:italic;">No responsiveness problems detected at the current viewport width.</p>';
        return '<p class="empty">No responsiveness problems detected at the current viewport width.</p>';
      }
      var sums = {
        critical: 0, high: 0, medium: 0, low: 0
      };
      list.forEach(function (h) { if (sums[h.priority] !== undefined) sums[h.priority]++; });
      if (word) {
        var priColor = { critical: "#b91c1c", high: "#b45309", medium: "#b45309", low: "#15803d" };
        var priBg = { critical: "#fdf8f8", high: "#fbf7f0", medium: "#fbf7f0", low: "#f6fbf8" };
        return wIssueTable(list.slice(0, 40).map(function (h) {
          var p = h.priority || "low";
          var color = priColor[p] || "#666";
          var chip = p === "critical" ? "Critical" : (p === "high" ? "Warning" : "Cue");
          return '<tr><td style="border-left:3pt solid ' + color + ';background:' + (priBg[p] || "#fafafa") + ';padding:5pt 8pt;font-size:9pt;">'
            + '<b>' + esc(chip) + '</b> \u2014 <b>' + WD.escapeHtml(h.title) + '</b>'
            + '<div style="margin-top:2pt;color:#333;">' + WD.escapeHtml(h.message || "") + '</div>'
            + '<div style="margin-top:3pt;color:#555;font-style:italic;"><b>Recommendation:</b> ' + WD.escapeHtml(hintFix(h)) + '</div>'
            + '</td></tr>';
        }).join(""));
      }
      return list.slice(0, 40).map(function (h) {
        var cls = h.priority === "critical" ? "critical" : (h.priority === "high" ? "warning" : "good");
        var chip = h.priority === "critical" ? "Critical" : (h.priority === "high" ? "Warning" : "Cue");
        return '<div class="issue ' + cls + '"><span class="tag">' + chip + '</span>'
          + '<b>' + WD.escapeHtml(h.title) + '</b>'
          + '<p>' + WD.escapeHtml(h.message || "") + '</p>'
          + '<p class="rec"><b>Recommendation:</b> ' + WD.escapeHtml(hintFix(h)) + '</p>'
          + '</div>';
      }).join("\n");
    }

    function techRows() {
      var order = ["cms", "ecommerce", "pageBuilders", "builders", "editors", "frameworks", "cssFrameworks", "libraries", "fonts", "analytics", "marketing", "forms", "performance", "seo", "privacy", "security", "cdns", "platforms"];
      var names = { cms: "CMS", ecommerce: "E-commerce", pageBuilders: "Page builder", builders: "Site builder", editors: "Editor", frameworks: "JavaScript framework", cssFrameworks: "CSS framework", libraries: "Libraries", fonts: "Fonts", analytics: "Analytics", marketing: "Marketing", forms: "Form", performance: "Performance", seo: "SEO", privacy: "Privacy", security: "Security", cdns: "CDN", platforms: "Platform" };
      var out = [];
      order.forEach(function (k) {
        var arr = techGroups[k] || [];
        if (!arr.length) return;
        var label = names[k] || k;
        var items = arr.slice(0, 12).map(function (t) {
          return t.name + (t.confidence ? " (" + t.confidence + ")" : "");
        }).join(", ");
        out.push(row(label, items));
      });
      if (!out.length) out.push(row("Technology", "No recognized technology stack detected on this page."));
      return out.join("\n");
    }

    var techHtml = techRows();
    var tableWrap = function (inner, emptyText) {
      if (word) return inner ? '<table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse;">' + inner + "\n</table>" : '<p class="empty">' + emptyText + '</p>';
      return inner ? '<table>\n' + inner + "\n</table>" : '<p class="empty">' + emptyText + '</p>';
    };
    var issuesWrap = function (inner) { return word ? inner : '<div class="issues">' + inner + '</div>'; };
    var respSumm = hintCount
      ? (word
          ? '<p style="margin:4pt 0 6pt;font-size:9pt;color:#333;">' + hintCount + ' responsiveness cue' + (hintCount === 1 ? "" : "s") + " detected at the current viewport: " + esc(num(responsive.breakPoints)) + " breakpoints, " + esc(num(responsive.fixedWidthCount)) + " fixed-width element" + ((responsive.fixedWidthCount || 0) === 1 ? "" : "s") + ", " + esc(num(responsive.overflowNow)) + " overflow, " + esc(num(responsive.textOverflowCount)) + " clipped, " + esc(num(responsive.offscreenCount)) + " off-screen.</p>\n"
          : '<p class="summ">' + hintCount + ' responsiveness cue' + (hintCount === 1 ? "" : "s") + " detected at the current viewport: " + esc(num(responsive.breakPoints)) + " breakpoints, " + esc(num(responsive.fixedWidthCount)) + " fixed-width element" + ((responsive.fixedWidthCount || 0) === 1 ? "" : "s") + ", " + esc(num(responsive.overflowNow)) + " overflow, " + esc(num(responsive.textOverflowCount)) + " clipped, " + esc(num(responsive.offscreenCount)) + " off-screen.</p>\n")
      : "";
    var critCount = critical.length;
    var warnCount = warning.length;
    var passCount = good.length;
    var verdictLevel = (critCount === 0 && warnCount === 0) ? "good"
      : critCount === 0 ? "fair"
      : critCount <= 3 ? "warn" : "critical";
    var verdictLabel = (critCount === 0 && warnCount === 0) ? "Excellent \u2014 no issues found"
      : critCount === 0 ? "Good \u2014 " + warnCount + " warning" + (warnCount === 1 ? "" : "s") + " to address"
      : critCount + " critical fix" + (critCount === 1 ? "" : "es") + " required";

    // "Health at a Glance": the three audit categories as direct statistics â€”
    // passing checks, warnings to address, and critical fixes required.
    function glanceBlock() {
      if (word) {
        var gBg = verdictLevel === "good" ? "#f0fdf4" : verdictLevel === "fair" ? "#f7f8fb" : verdictLevel === "warn" ? "#fff7ed" : "#fef2f2";
        return '<table width="100%" cellspacing="0" cellpadding="0" style="border-collapse:collapse;margin-bottom:10pt;">'
          + '<tr><td colspan="3" style="padding:6pt 8pt;background:' + gBg + ';border-bottom:1pt solid #d1d5db;font-size:10.5pt;color:#111;"><b>' + esc(verdictLabel) + '</b></td></tr>'
          + '<tr>'
          + '<td style="width:33%;padding:6pt 8pt;text-align:center;border-right:1pt solid #e5e7eb;"><div style="font-size:15pt;font-weight:bold;color:#b91c1c;">' + critCount + '</div><div style="font-size:8pt;color:#555;text-transform:uppercase;letter-spacing:0.5pt;">Critical fixes required</div></td>'
          + '<td style="width:34%;padding:6pt 8pt;text-align:center;border-right:1pt solid #e5e7eb;"><div style="font-size:15pt;font-weight:bold;color:#b45309;">' + warnCount + '</div><div style="font-size:8pt;color:#555;text-transform:uppercase;letter-spacing:0.5pt;">Warnings to address</div></td>'
          + '<td style="width:33%;padding:6pt 8pt;text-align:center;"><div style="font-size:15pt;font-weight:bold;color:#15803d;">' + passCount + '</div><div style="font-size:8pt;color:#555;text-transform:uppercase;letter-spacing:0.5pt;">Passing checks</div></td>'
          + '</tr>'
          + '</table>';
      }
      return '<div class="glance">'
        + '<div class="glance-verdict ' + verdictLevel + '">' + esc(verdictLabel) + '</div>'
        + '<div class="glance-row">'
        + '<div class="glance-stat critical"><b>' + critCount + '</b><span>Critical fixes required</span></div>'
        + '<div class="glance-stat warning"><b>' + warnCount + '</b><span>Warnings to address</span></div>'
        + '<div class="glance-stat good"><b>' + passCount + '</b><span>Passing checks</span></div>'
        + '</div></div>';
    }

    function summaryLine() {
      var total = issues.length;
      var text = critCount + " critical \u00B7 " + warnCount + " warning" + (warnCount === 1 ? "" : "s") + " \u00B7 " + info.length + " informational \u00B7 " + passCount + " passing \u00B7 " + total + " finding(s) total.";
      if (word) return '<p style="margin:4pt 0 8pt;font-size:9pt;color:#444;">' + esc(text) + '</p>';
      return '<p class="summ">' + esc(text) + '</p>';
    }

    // Priority order inside the file: criticals before warnings, and within a
    // level the directly actionable items first (per-element evidence, then a
    // concrete recommendation). The "Priority fixes" section below reads off
    // the same order.
    function priScore(i) {
      var s = i.level === "critical" ? 0 : 100;
      if (i.items && i.items.length) s -= 10;
      if (i.rec) s -= 5;
      return s;
    }
    critical.sort(function (a, b) { return priScore(a) - priScore(b); });
    warning.sort(function (a, b) { return priScore(a) - priScore(b); });
    var priorityFixes = critical.concat(warning).slice(0, 5);
    function priorityBlock() {
      if (!priorityFixes.length) {
        if (word) return '<p style="margin:4pt 0;font-size:9pt;color:#777;font-style:italic;">Nothing to fix \u2014 every check passes.</p>';
        return '<p class="empty">Nothing to fix \u2014 every check passes.</p>';
      }
      return priorityFixes.map(function (i, n) {
        var tag = i.level === "critical" ? "Critical" : "Warning";
        if (word) {
          var wColor = i.level === "critical" ? "#b91c1c" : "#b45309";
          return '<p style="margin:5pt 0;font-size:9pt;"><b style="color:' + wColor + ';">' + (n + 1) + ". [" + tag + "] " + WD.escapeHtml(i.title) + "</b><br/>"
            + '<span style="color:#333;">' + WD.escapeHtml(i.rec || i.desc) + "</span></p>";
        }
        return '<div class="issue ' + i.level + '"><span class="tag">' + tag + "</span><b>" + (n + 1) + ". " + WD.escapeHtml(i.title) + "</b>"
          + "<p>" + WD.escapeHtml(i.rec || i.desc) + "</p></div>";
      }).join(word ? "\n" : "\n");
    }

    var body = sec("Health at a Glance", glanceBlock() + summaryLine())
      + sec("Priority fixes \u2014 start here", issuesWrap(priorityBlock()))
      + sec("Scores", tableWrap(scoreHtml, ""))
      + sec("1. Page snapshot", tableWrap(rows.join("\n"), ""))
      + sec("2. Critical issues", issuesWrap(issueRows(critical, "critical", "Critical")))
      + sec("3. Warnings", issuesWrap(issueRows(warning, "warning", "Warning")))
      + sec("4. Informational", issuesWrap(issueRows(info, "info", "Info")))
      + sec("5. Good results", issuesWrap(issueRows(good, "good", "Pass")))
      + sec("6. Technology stack", tableWrap(techHtml, "Nothing to list."))
      + sec("7. Responsive signals", respSumm + issuesWrap(hintRows()));

    if (word) {
      return "<html xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns=\"http://www.w3.org/TR/REC-html40\">\n"
        + "<head>\n<meta charset=\"utf-8\">\n"
        + "<!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:Zoom>100</w:Zoom></w:WordDocument></xml><![endif]-->\n"
        + "<style>@page WordSection1{size:8.5in 11.0in;margin:0.9in 0.8in;}div.WordSection1{page:WordSection1;}</style>\n"
        + "</head>\n<body>\n<div class=\"WordSection1\">\n"
        + '<p style="font-size:8pt;letter-spacing:2pt;color:#666;">Web Doctor \u00B7 QA Report</p>\n'
        + '<p style="font-size:16pt;font-weight:bold;margin:8pt 0 2pt;">Website Audit</p>\n'
        + '<p style="font-size:9pt;color:#333;margin:2pt 0 6pt;">'
        + "<b>Page:</b> " + esc(page.title || "Untitled page") + '<br/>'
        + "<b>URL:</b> " + esc(page.url || "n/a") + '<br/>'
        + "<b>Generated:</b> " + esc(dateStr) + "</p>\n"
        + body
        + '<p style="margin-top:18pt;font-size:8pt;color:#888;">Prepared by the Web Doctor extension \u2014 Page 1 of 1</p>\n'
        + "</div>\n</body>\n</html>";
    }

    return "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
      + '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
      + '<title>Website Audit \u2014 ' + esc(page.title || "") + '</title>\n'
      + "<style>\n"
      + "@page { size: Letter; margin: 0.9in 0.8in; }\n"
      + "* { box-sizing: border-box; }\n"
      + "html { background: #fff; }\n"
      + "body { font-family: Georgia, 'Times New Roman', serif; color: #1b1b1b; margin: 0; line-height: 1.6; }\n"
      + ".doc { max-width: 720px; margin: 0 auto; padding: 44px 28px 70px; }\n"
      + ".doc-brand { font-size: 10.5px; letter-spacing: 3px; text-transform: uppercase; color: #71717a; border-bottom: 2px solid #111; padding-bottom: 10px; }\n"
      + ".doc-brand b { color: #111; }\n"
      + "h1 { font-size: 26px; font-weight: 700; margin: 24px 0 4px; letter-spacing: .2px; }\n"
      + ".doc-meta { font-size: 11.5px; color: #555; margin: 10px 0 0; }\n"
      + ".doc-meta div { margin: 2px 0; overflow-wrap: anywhere; }\n"
      + ".doc-meta b { color: #222; font-weight: 600; }\n"
      + "hr.doc-rule { border: 0; border-top: 1px solid #d6d6d6; margin: 26px 0 6px; }\n"
      + "h2 { font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 12.5px; text-transform: uppercase; letter-spacing: 1.5px; color: #111; border-bottom: 1px solid #cfcfcf; padding-bottom: 6px; margin: 28px 0 14px; }\n"
      + "table { width: 100%; border-collapse: collapse; font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 12.5px; }\n"
      + "td { padding: 6px 10px; border-bottom: 1px solid #ececec; vertical-align: top; font-size: 12.5px; }\n"
      + "td:first-child { width: 38%; color: #555; font-weight: 500; }\n"
      + ".issues .issue { font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 12.5px; padding: 8px 12px; margin: 0 0 9px; border-left: 3px solid #d4d4d4; background: #fafafa; }\n"
      + ".issues .issue.critical { border-left-color: #b91c1c; background: #fdf8f8; }\n"
      + ".issues .issue.warning { border-left-color: #b45309; background: #fbf7f0; }\n"
      + ".issues .issue.good { border-left-color: #15803d; background: #f6fbf8; }\n"
      + ".issues .issue.info { border-left-color: #2563eb; background: #f0f4ff; }\n"
      + ".issues .tag { display: inline-block; font-size: 9px; letter-spacing: 1px; font-weight: 700; text-transform: uppercase; padding: 1px 6px; border: 1px solid currentColor; border-radius: 2px; margin: 0 8px 0 0; vertical-align: 1px; font-family: Georgia, serif; }\n"
      + ".issues .critical .tag { color: #b91c1c; }\n"
      + ".issues .warning .tag { color: #b45309; }\n"
      + ".issues .good .tag { color: #15803d; }\n"
      + ".issues .info .tag { color: #2563eb; }\n"
      + ".issues b { font-size: 12.5px; }\n"
      + ".issues p { margin: 3px 0 0; color: #333; font-size: 12.5px; }\n"
      + ".issues .rec { margin-top: 6px; color: #555; font-size: 12px; font-style: italic; }\n"
      + ".empty { color: #888; font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 12.5px; font-style: italic; }\n"
      + ".summ { font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 12.5px; color: #333; margin: 0 0 10px; }\n"
      + ".foot { margin-top: 36px; padding-top: 10px; border-top: 1px solid #d6d6d6; font-size: 10.5px; color: #999; display: flex; justify-content: space-between; flex-wrap: wrap; gap: 6px; font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }\n"
      + ".glance { margin-bottom: 20px; font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }\n"
      + ".glance-verdict { padding: 10px 14px; font-size: 13px; font-weight: 600; border-radius: 6px; margin-bottom: 12px; }\n"
      + ".glance-verdict.good { background: #f0fdf4; color: #15803d; }\n"
      + ".glance-verdict.fair { background: #f7f8fb; color: #555; }\n"
      + ".glance-verdict.warn { background: #fff7ed; color: #b45309; }\n"
      + ".glance-verdict.critical { background: #fef2f2; color: #b91c1c; }\n"
      + ".glance-row { display: flex; gap: 12px; }\n"
      + ".glance-stat { flex: 1; text-align: center; padding: 10px 6px; border-radius: 6px; border: 1px solid #e5e7eb; }\n"
      + ".glance-stat b { display: block; font-size: 22px; margin-bottom: 2px; }\n"
      + ".glance-stat span { display: block; font-size: 11px; color: #555; text-transform: uppercase; letter-spacing: 0.5px; }\n"
      + ".glance-stat.critical b { color: #b91c1c; }\n"
      + ".glance-stat.warning b { color: #b45309; }\n"
      + ".glance-stat.good b { color: #15803d; }\n"
      + "</style>\n</head>\n<body>\n<div class=\"doc\">\n"
      + '<div class="doc-brand">Web Doctor <b>\u00B7 QA Report</b></div>\n'
      + '<h1>Website Audit</h1>\n'
      + '<div class="doc-meta">\n'
      + '<div><b>Page:</b> ' + esc(page.title || "Untitled page") + '</div>\n'
      + '<div><b>URL:</b> ' + esc(page.url || "n/a") + '</div>\n'
      + '<div><b>Generated:</b> ' + esc(dateStr) + '</div>\n'
      + '</div>\n'
      + '<hr class="doc-rule">\n'
      + body
      + '<div class="foot"><span>Prepared by the Web Doctor extension</span><span>Page 1 of 1</span></div>\n'
      + "</div>\n</body>\n</html>";
  }

  function makeAuditFile() {
    var btn = document.getElementById("btnCreateReport");
    var status = document.getElementById("auditStatus");
    var preview = document.getElementById("auditPreview");
    var frame = document.getElementById("auditPreviewFrame");
    var label = document.getElementById("auditPreviewLabel");
    var hint = document.getElementById("auditDownloadHint");
    var btnDocs = document.getElementById("btnConvertDocs");
    var btnDlDocs = document.getElementById("btnDownloadDocs");
    var btnDl = document.getElementById("btnDownloadReport");
    var btnView = document.getElementById("btnViewAuditFile");
    if (btn) btn.disabled = true;
    if (btnView) btnView.disabled = true;
    if (preview) preview.classList.add("hidden");
    if (frame) frame.removeAttribute("srcdoc");
    if (status) { status.className = "audit-status visible"; status.textContent = "Building the report\u2026"; }
    var finish = function (doc) {
      auditDoc = doc;
      auditData = dashData;
      auditDocsDoc = null;
      if (auditBlobUrl) {
        try { URL.revokeObjectURL(auditBlobUrl); } catch (e) {}
        auditBlobUrl = null;
      }
      // The file preview stays dormant until the user presses View File.
      if (preview) preview.classList.add("hidden");
      if (frame) frame.removeAttribute("srcdoc");
      if (btnView) btnView.disabled = false;
      if (label) label.textContent = "The audit file is ready. Click View File to preview it, convert it, or download it.";
      if (btnDocs) btnDocs.disabled = false;
      if (btnDlDocs) btnDlDocs.disabled = false;
      if (btnDl) btnDl.disabled = false;
      if (hint) hint.textContent = "";
      if (status) status.textContent = "Audit report built \u2014 press View File to see it inline.";
    };
    var fail = function (msg) {
      if (status) { status.className = "audit-status visible"; status.textContent = msg; }
      if (preview) preview.classList.add("hidden");
      if (btnDocs) btnDocs.disabled = true;
      if (btnDlDocs) btnDlDocs.disabled = true;
      if (btnDl) btnDl.disabled = true;
      if (btnView) btnView.disabled = true;
    };
    var afterScan = function () {
      try {
        if (!dashData) throw new Error("no scan data");
        finish(buildAuditReport(dashData));
      } catch (err) {
        var msg = "No scan data yet \u2014 run an analysis first, then Audit Report.";
        if (err && err.message !== "no scan data") msg = "Could not build the report: " + err.message;
        fail(msg);
      } finally {
        if (btn) btn.disabled = false;
      }
    };
    if (dashData) {
      afterScan();
      return;
    }
    // Audit is self-sufficient: with no scan data on hand, run a fresh scan of
    // the active tab first, then build the report from that result.
    if (status) { status.className = "audit-status visible"; status.textContent = "Analyzing the page first \u2014 the report needs a fresh scan\u2026"; }
    chrome.runtime.sendMessage({ action: "analyzeTab" }, function (response) {
      if (!response || !response.success) {
        fail(response ? ("Could not analyze the page: " + response.error) : "No response from extension. Try reloading the popup.");
        if (btn) btn.disabled = false;
        return;
      }
      enterData(response.data);
      afterScan();
    });
  }

  function viewAuditFile() {
    var status = document.getElementById("auditStatus");
    var preview = document.getElementById("auditPreview");
    var frame = document.getElementById("auditPreviewFrame");
    var label = document.getElementById("auditPreviewLabel");
    var btn = document.getElementById("btnViewAuditFile");
    if (!auditDoc) {
      var create = document.getElementById("btnCreateReport");
      if (create) { create.click(); return; }
      if (status) status.textContent = "Create the audit report first, then view it.";
      return;
    }
    if (frame) frame.srcdoc = auditDoc;
    if (preview) preview.classList.remove("hidden");
    if (label) label.textContent = "Previewing the audit file \u2014 open it in a new tab, or convert / download it.";
    if (btn) { btn.disabled = true; btn.textContent = "File shown"; }
    if (status) status.textContent = "Audit file is shown inline below.";
    if (!auditBlobUrl) {
      hostBlob("audit-report.html", auditDoc, "text/html", function (url) {
        auditBlobUrl = url;
      });
    }
  }

  function openAuditReportTab() {
    if (!auditBlobUrl) {
      var btn = document.getElementById("btnCreateReport");
      if (btn) btn.click();
      return;
    }
    chrome.tabs.create({ url: auditBlobUrl }, function () {
      var status = document.getElementById("auditStatus");
      if (chrome.runtime.lastError) {
        if (status) status.textContent = "Could not open the report tab: " + chrome.runtime.lastError.message;
        return;
      }
      if (status) status.textContent = "Report opened in a new tab.";
    });
  }

  // Domain-derived file name so exports are easy to tell apart.
  function auditExportName(ext) {
    var host = (auditData && auditData.page && auditData.page.host) || "";
    var base = String(host).replace(/[^a-zA-Z0-9.-]/g, "-").replace(/^-+|-+$/g, "") || "web-doctor";
    return base + "-audit-report." + ext;
  }

  // Clean HTML-to-BLOB export: wrap the content in a Blob with the requested
  // MIME type, hand it to a temporary anchor, click it, and revoke the object
  // URL right away so no Blob URL leaks accumulate in the document.
  function downloadReportBlob(name, content, mime, status, doneMsg) {
    var statusBase = status && status.className.indexOf("devmod-status") !== -1 ? "devmod-status" : "audit-status";
    var url;
    try {
      url = URL.createObjectURL(new Blob([content], { type: mime }));
    } catch (err) {
      if (status) { status.className = statusBase + " visible"; status.textContent = "Could not build the download: " + err.message; }
      return;
    }
    var a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.rel = "noopener";
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    if (a.parentNode) a.parentNode.removeChild(a);
    try { URL.revokeObjectURL(url); } catch (e) {}
    if (status) { status.className = statusBase + " visible"; status.textContent = "Download " + doneMsg + " (" + name + ")."; }
  }

  // Reports opened in a new tab must outlive this popup, so hand the HTML to
  // the service worker and open its URL (a popup-created Blob URL dies the
  // moment the popup closes). Falls back to a local Blob URL if the host
  // cannot be reached.
  function hostBlob(name, content, mime, cb) {
    if (chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({ action: "hostBlob", name: name, html: content, mime: mime || "text/html" }, function (res) {
        if (chrome.runtime.lastError || !res || !res.success) {
          var fallback = null;
          try { fallback = URL.createObjectURL(new Blob([content], { type: mime || "text/html" })); } catch (e) { fallback = null; }
          if (cb) cb(fallback);
          return;
        }
        if (cb) cb(res.url);
      });
      return;
    }
    if (cb) cb(null);
  }

  function downloadAuditFile() {
    var status = document.getElementById("auditStatus");
    if (!auditDoc) {
      if (status) status.textContent = "Create the audit report first, then download it.";
      return;
    }
    downloadReportBlob(auditExportName("html"), auditDoc, "text/html", status, "of the report started");
  }

  function downloadAuditDocsFile() {
    var status = document.getElementById("auditStatus");
    if (!auditDocsDoc && auditData) {
      try { auditDocsDoc = buildAuditReport(auditData, true); } catch (err) { auditDocsDoc = null; }
    }
    if (!auditDocsDoc) {
      if (status) status.textContent = "Convert the report to a Docs file first, then download it.";
      return;
    }
    downloadReportBlob(auditExportName("doc"), auditDocsDoc, "application/msword", status, "of the Docs file started");
  }

  // True only when manifest.json carries a real Google Cloud OAuth client id
  // for this extension (see the setup hint shown when it is missing).
  function gaDocsConfigured() {
    try {
      var mf = chrome.runtime.getManifest ? chrome.runtime.getManifest() : {};
      var cfg = (mf && mf.oauth2 && mf.oauth2.client_id) ? String(mf.oauth2.client_id).trim() : "";
      return cfg.length > 0 && cfg.indexOf("YOUR_") !== 0 && /\.apps\.googleusercontent\.com$/.test(cfg);
    } catch (e) { return false; }
  }

  function convertToDocsFile() {
    var status = document.getElementById("auditStatus");
    var btnDocs = document.getElementById("btnConvertDocs");
    var btnDlDocs = document.getElementById("btnDownloadDocs");
    var hint = document.getElementById("auditDownloadHint");
    if (!auditDoc || !auditData) {
      if (status) status.textContent = !auditDoc ? "Create the report first, then convert it." : "Report data is no longer available \u2014 run Audit Report again.";
      return;
    }
    if (btnDocs) btnDocs.disabled = true;
    if (status) status.textContent = "Converting to a Google Docs file\u2026";
    try {
      auditDocsDoc = buildAuditReport(auditData, true);
    } catch (err) {
      if (status) { status.className = "audit-status visible"; status.textContent = "Could not convert: " + err.message; }
      if (btnDocs) btnDocs.disabled = false;
      if (btnDlDocs) btnDlDocs.disabled = false;
      return;
    }
    if (btnDlDocs) btnDlDocs.disabled = false;
    if (!gaDocsConfigured()) {
      if (status) { status.className = "audit-status visible"; status.textContent = "Google Docs upload is not configured yet. Set manifest.json oauth2.client_id and reload the extension (or use Download Docs File for a local copy)."; }
      if (btnDocs) btnDocs.disabled = false;
      if (hint) hint.textContent = "Setup: Google Cloud Console \u2192 APIs & Services \u2192 Credentials \u2192 Create OAuth client ID \u2192 Chrome extension. Copy the client id into manifest.json \u2192 oauth2.client_id, then reload the extension.";
      return;
    }
    chrome.runtime.sendMessage({ action: "gaOpenDocs", name: auditExportName("doc"), html: auditDocsDoc }, function (res) {
      if (!res || !res.success) {
        var why = (res && res.error) ? res.error : "No response from the background worker.";
        if (status) { status.className = "audit-status visible"; status.textContent = "Could not open Google Docs: " + why; }
        if (btnDocs) btnDocs.disabled = false;
        if (hint) hint.textContent = "The Docs file is still available \u2014 use Download Docs File to save it and drag it into Google Docs.";
        return;
      }
      chrome.tabs.create({ url: res.url }, function () {
        if (chrome.runtime.lastError) {
          if (status) status.textContent = "Document created in your Drive, but the tab would not open (" + chrome.runtime.lastError.message + "). Open: " + res.url;
          return;
        }
        if (status) status.textContent = "Opened the audit as a new document in Google Docs.";
        if (hint) hint.textContent = "The document was created in your Google Drive and opened in the Docs editor. Download Docs File saves a local copy too.";
      });
    });
  }

  // ============================================
  // SITE CRAWLER (Audit tab)
  // ============================================
  // Crawls child pages through the background worker, shows live progress,
  // renders a per-site summary, and builds ONE self-contained site report file
  // (HTML) containing every finding across all visited pages.
  var crawlState = { active: false, data: null, blobUrl: null, doc: null };
  var crawlToken = 0;

  function crawlStatus(text, kind) {
    var st = document.getElementById("crawlStatus");
    if (!st) return;
    st.className = "audit-status" + (kind ? " visible" : " hidden");
    st.textContent = text;
  }

  function crawlProgressLabel() {
    var label = document.getElementById("auditPreviewLabel");
    if (label && crawlState.data) label.textContent = "Site crawl of " + (crawlState.data.meta ? crawlState.data.meta.root : "") + " \u2014 " + crawlState.data.pages.length + " page(s) scanned.";
  }

  function startCrawl() {
    if (crawlState.active) return;
    var btnStart = document.getElementById("btnStartCrawl");
    var btnStop = document.getElementById("btnStopCrawl");
    var btnView = document.getElementById("btnViewCrawlReport");
    var btnDl = document.getElementById("btnDownloadCrawlReport");
    var maxInput = document.getElementById("crawlMaxPages");
    var maxPages = Math.max(1, Math.min(parseInt(maxInput && maxInput.value, 10) || 8, 25));
    if (!dashData || !dashData.page || !dashData.page.url) {
      crawlStatus("Run an analysis first so the crawler knows which site to scan.");
      return;
    }
    var siteUrl = dashData.page.url;
    var testUrl = null;
    try { testUrl = new URL(siteUrl); } catch (e) { testUrl = null; }
    if (!testUrl || !/^https?:$/.test(testUrl.protocol)) {
      crawlStatus("Only http(s) sites can be crawled.");
      return;
    }
    // Each run gets a fresh token so a stale response (e.g. from a run this
    // UI already replaced) can never overwrite newer crawl results. Previous
    // docs/blob URLs are cleared too, so a second run never reopens the old
    // report after a stop.
    var token = ++crawlToken;
    crawlState.data = null;
    crawlState.doc = null;
    crawlState.blobUrl = null;
    crawlState.active = true;
    // Run token echoed by the background worker in every progress message
    // and the final response, so stale runs can never overwrite this one.
    // (Responses without a token — e.g. older workers — are still honored.)
    crawlState.runToken = token;
    if (btnStart) btnStart.disabled = true;
    if (btnStop) btnStop.disabled = false;
    if (btnView) btnView.disabled = true;
    if (btnDl) btnDl.disabled = true;
    crawlStatus("Scanning \u2014 requesting site access and loading the first page\u2026", "visible");
    var runCrawl = function () {
      chrome.runtime.sendMessage({ action: "crawlSite", url: siteUrl, maxPages: maxPages, runToken: token }, function (response) {
        var isCurrent = crawlToken === token;
        crawlState.active = false;
        if (btnStop) btnStop.disabled = true;
        if (btnStart) btnStart.disabled = false;
        if (!isCurrent) return;
        if (response && response.runToken !== undefined && response.runToken !== token) return;
        if (chrome.runtime.lastError || !response || !response.success) {
          crawlStatus((chrome.runtime.lastError ? chrome.runtime.lastError.message + " " : "") + ((response && response.error) || "Could not scan the site."));
          return;
        }
        crawlState.data = response;
        renderCrawlSummary(response);
      });
    };
    if (chrome.permissions && chrome.permissions.contains) {
      // Ask for host access from this page, because the request has to happen
      // inside the user gesture that pressed the button; the background worker
      // can no longer collect this permission reliably.
      var originPattern = testUrl.origin + "/*";
      chrome.permissions.contains({ origins: [originPattern] }, function (hasSite) {
        if (hasSite) { runCrawl(); return; }
        if (!chrome.permissions.request) { runCrawl(); return; }
        chrome.permissions.request({ origins: [originPattern] }, function (granted) {
          if (granted) { runCrawl(); return; }
          crawlState.active = false;
          if (btnStop) btnStop.disabled = true;
          if (btnStart) btnStart.disabled = false;
          crawlStatus("Site access not granted for " + testUrl.host + " \u2014 the crawler needs it to load child pages. Grant access to this site and try again.");
        });
      });
    } else {
      runCrawl();
    }
  }

  function stopCrawl() {
    if (!crawlState.active) return;
    chrome.runtime.sendMessage({ action: "crawlStop" }, function () {});
    crawlStatus("Stopping after the current page\u2026");
  }

  // Normalized full-page findings for one crawled page: runs the same
  // detector set as a direct scan over the page's full analysis payload.
  // Pages without one (legacy responses, errors, skipped) yield [].
  function crawlPageIssues(p) {
    try {
      var full = p && p.data && p.data.full;
      if (!full || typeof WD.collectIssues !== "function") return [];
      return WD.collectIssues(full) || [];
    } catch (e) { return []; }
  }

  function renderCrawlSummary(resp) {
    var host = document.getElementById("crawlSummary");
    var hintEl = document.getElementById("crawlHint");
    var btnView = document.getElementById("btnViewCrawlReport");
    var btnDl = document.getElementById("btnDownloadCrawlReport");
    if (!resp || !resp.pages) return;
    var pages = resp.pages;
    var totals = { errors: 0, warnings: 0, infos: 0 };
    var normTotals = { critical: 0, warning: 0 };
    var fullPages = 0;
    var skipped = 0;
    var perPage = [];
    var topIssues = [];
    var normTop = [];
    var sevRank = { critical: 0, warning: 1 };
    pages.forEach(function (p) {
      if (p && p.stopped) { skipped++; perPage.push(null); return; }
      var data = p.data;
      var stats = (data && data.stats) || {};
      var pageStats = { errors: 0, warnings: 0, infos: 0 };
      Object.keys(stats).forEach(function (k) {
        pageStats.errors += stats[k].errors || 0;
        pageStats.warnings += stats[k].warnings || 0;
        pageStats.infos += stats[k].infos || 0;
      });
      totals.errors += pageStats.errors;
      totals.warnings += pageStats.warnings;
      totals.infos += pageStats.infos;
      perPage.push(pageStats);
      if (data && data.categories) {
        Object.keys(data.categories).forEach(function (cat) {
          (data.categories[cat] || []).forEach(function (f) {
            if ((f.severity === "error" || f.severity === "warning") && topIssues.length < 12) {
              topIssues.push({ severity: f.severity, title: f.title, loc: f.loc || "", page: p.title || p.url, fix: f.fix });
            }
          });
        });
      }
      // Full-analysis findings for this page (structure, SEO, performance
      // incl. Core Web Vitals, accessibility) — the depth a direct scan has.
      var norm = crawlPageIssues(p);
      if (data && data.full) fullPages++;
      norm.forEach(function (iss) {
        if (iss.level === "critical") normTotals.critical++;
        else if (iss.level === "warning") normTotals.warning++;
        else return;
        normTop.push({ level: iss.level, title: iss.title, desc: iss.desc, rec: iss.rec, page: p.title || p.url });
      });
    });
    normTop.sort(function (a, b) { return (sevRank[a.level] || 2) - (sevRank[b.level] || 2); });
    normTop = normTop.slice(0, 6);
    var meta = resp.meta || {};
    var stopped = !!(meta.stopped || skipped);
    var chips = '<span class="crawl-chip c-error"><b>' + totals.errors + "</b> critical</span>"
      + '<span class="crawl-chip c-warning"><b>' + totals.warnings + "</b> warnings</span>"
      + '<span class="crawl-chip c-info"><b>' + totals.infos + "</b> cues</span>"
      + '<span class="crawl-chip"><b>' + pages.length + "</b> pages scanned</span>"
      + '<span class="crawl-chip"><b>' + (meta.failed || 0) + "</b> unreachable</span>"
      + (fullPages ? '<span class="crawl-chip"><b>' + fullPages + "</b> full-analysis</span>" : "")
      + (skipped ? '<span class="crawl-chip"><b>' + skipped + "</b> skipped</span>" : "");
    var list = topIssues.map(function (t) {
      return '<div class="crawl-item ' + (t.severity === "error" ? "c-error" : "c-warning") + '"><b>' + WD.escapeHtml(t.title) + "</b>"
        + (t.loc ? '<span class="crawl-loc"> \u00B7 ' + WD.escapeHtml(t.loc) + "</span>" : "")
        + (t.fix ? '<span class="crawl-fix">Fix: ' + WD.escapeHtml(t.fix) + "</span>" : "")
        + '<span class="crawl-page">' + WD.escapeHtml(t.page) + "</span></div>";
    }).join("");
    var normList = normTop.map(function (t) {
      return '<div class="crawl-item ' + (t.level === "critical" ? "c-error" : "c-warning") + '"><b>' + WD.escapeHtml(t.title) + "</b>"
        + (t.desc ? '<span class="crawl-loc"> \u00B7 ' + WD.escapeHtml(t.desc) + "</span>" : "")
        + (t.rec ? '<span class="crawl-fix">Fix: ' + WD.escapeHtml(t.rec) + "</span>" : "")
        + '<span class="crawl-page">' + WD.escapeHtml(t.page) + "</span></div>";
    }).join("");
    host.classList.remove("hidden");
    host.innerHTML = '<div class="crawl-head">' + (stopped ? "Site scan stopped \u2014 partial results" : "Site scan complete") + "</div>"
      + '<div class="crawl-meta">Found ' + totals.errors + " critical issue" + (totals.errors === 1 ? "" : "s") + " and "
      + totals.warnings + " warning" + (totals.warnings === 1 ? "" : "s") + " across " + pages.length + " page"
      + (pages.length === 1 ? "" : "s") + '. The full findings are in the site report below.</div>'
      + '<div class="crawl-chips">' + chips + "</div>"
      + (topIssues.length ? '<div class="crawl-list">' + list + "</div>" : "")
      + ((normTotals.critical + normTotals.warning) ? '<div class="crawl-head crawl-subhead">Top full-analysis findings \u2014 ' + normTotals.critical + " critical \u00B7 " + normTotals.warning + " warnings</div>"
        + '<div class="crawl-list">' + normList + "</div>" : "");
    if (btnView) btnView.disabled = false;
    if (btnDl) btnDl.disabled = false;
    if (hintEl) hintEl.textContent = "View or download the single site report file with every page's findings (layout, responsive, icons, CTAs, design, broken URLs, missing images, structural tags, full-page analysis).";
  }

  // ---- Site report generator: ONE self-contained HTML file ----
  function buildCrawlReport(resp) {
    var pages = (resp && resp.pages) || [];
    var meta = (resp && resp.meta) || {};
    var probes = (resp && resp.probes) || {};
    var now = new Date();
    var dateStr = now.toDateString() + " \u00B7 " + now.toLocaleTimeString();
    var host = "";
    try { host = new URL(meta.root || "https://x.invalid").host; } catch (e) { host = ""; }

    function esc(s) { return WD.escapeHtml(String(s === undefined || s === null ? "" : s)); }
    function num(v) { return (v === undefined || v === null) ? "n/a" : Number(v).toLocaleString(); }

    var totals = { errors: 0, warnings: 0, infos: 0, findings: 0 };
    var categoryTotals = {
      layout: 0, responsive: 0, icons: 0, cta: 0, design: 0, structure: 0, urls: 0, images: 0
    };
    var CATEGORY_NAMES = {
      layout: "Layout breakages", responsive: "Responsive / viewport", icons: "Icon issues",
      cta: "CTA buttons", design: "Design", structure: "Structural tags", urls: "Broken URLs", images: "Missing images"
    };
    var allFindings = [];
    pages.forEach(function (p) {
      var data = p.data;
      if (!data || !data.categories) return;
      Object.keys(data.categories).forEach(function (cat) {
        (data.categories[cat] || []).forEach(function (f) {
          allFindings.push({ page: p.title || p.url, url: p.url, cat: cat, severity: f.severity || "info", title: f.title || "", fix: f.fix || "", loc: f.loc || "", section: f.section || "" });
          categoryTotals[cat] = (categoryTotals[cat] || 0) + 1;
        });
      });
    });
    allFindings.forEach(function (f) {
      if (f.severity === "error") totals.errors++;
      else if (f.severity === "warning") totals.warnings++;
      else totals.infos++;
      totals.findings++;
    });

    // Normalized full-page findings + core metrics per page. Pages scanned
    // with the complete analyzer contribute real structure/SEO/performance
    // data; legacy, failed, or skipped pages render n/a cells instead.
    var normTotals = { critical: 0, warning: 0, infos: 0 };
    var fullPages = 0;
    var skippedPages = 0;
    var pageMetrics = pages.map(function (p) {
      if (p && p.stopped) { skippedPages++; return { p: p, stopped: true }; }
      var full = p && p.data && p.data.full;
      if (!full) return { p: p, stopped: false };
      fullPages++;
      var norm = [];
      try { norm = (typeof WD.collectIssues === "function") ? WD.collectIssues(full) : []; } catch (e) { norm = []; }
      var c = 0, w = 0;
      norm.forEach(function (i) {
        if (i.level === "critical") { c++; normTotals.critical++; }
        else if (i.level === "warning") { w++; normTotals.warning++; }
        else { normTotals.infos++; }
      });
      var perf = full.performance || {};
      var dom = full.dom || {};
      return {
        p: p, stopped: false, norm: norm, crit: c, warn: w,
        lcp: perf.largestContentfulPaint, cls: perf.cumulativeLayoutShift,
        inp: perf.interactionToNextPaint, load: perf.loadTime,
        domNodes: dom.totalElements
      };
    });
    var stopped = !!(meta.stopped || skippedPages);

    function row(label, value) {
      return "<td>" + esc(label) + "</td><td>" + esc(value) + "</td>";
    }
    function ms(v) { return (v === undefined || v === null) ? "n/a" : (Number(v) / 1000).toFixed(1) + "s"; }
    function cls3(v) { return (v === undefined || v === null) ? "n/a" : (Math.round(Number(v) * 1000) / 1000).toString(); }

    // Per-page summary table
    var pageRows = pages.map(function (p) {
      var stats = (p.data && p.data.stats) || {};
      var e = 0, w = 0, i = 0;
      Object.keys(stats).forEach(function (k) { e += stats[k].errors || 0; w += stats[k].warnings || 0; i += stats[k].infos || 0; });
      var cell = p.stopped ? "Skipped \u2014 crawl stopped"
        : (p.error ? p.error : e + " critical \u00B7 " + w + " warnings \u00B7 " + i + " cues");
      return "<tr>" + row(p.title || p.url, cell) + "</tr>";
    }).join("\n");

    // Core metrics per page (real measured values where the full analyzer ran)
    var metricRows = pageMetrics.map(function (m) {
      var cells = m.stopped
        ? "<td>Skipped</td><td>Skipped</td><td>Skipped</td><td>Skipped</td><td>Skipped</td><td>Skipped</td>"
        : "<td>" + esc(ms(m.lcp)) + "</td><td>" + esc(cls3(m.cls)) + "</td><td>" + esc(ms(m.inp)) + "</td>"
        + "<td>" + esc(ms(m.load)) + "</td><td>" + esc(m.domNodes === undefined || m.domNodes === null ? "n/a" : Number(m.domNodes).toLocaleString()) + "</td>"
        + "<td>" + esc((m.crit || 0) + " crit \u00B7 " + (m.warn || 0) + " warn") + "</td>";
      return "<tr><td>" + esc(m.p.title || m.p.url) + "</td>" + cells + "</tr>";
    }).join("\n");

    // Full-page findings per page, severity ordered, capped with overflow note
    var sevRank2 = { critical: 0, warning: 1, info: 2, good: 3 };
    var normSecs = pageMetrics.map(function (m) {
      if (m.stopped || !m.norm) return "";
      var items = m.norm.filter(function (i) { return i.level === "critical" || i.level === "warning"; })
        .sort(function (a, b) { return (sevRank2[a.level] || 3) - (sevRank2[b.level] || 3); });
      if (!items.length) return "";
      var shown = items.slice(0, 10);
      var more = items.length > shown.length ? '<p class="empty">+ ' + (items.length - shown.length) + " more on this page \u2014 see the Dashboard.</p>" : "";
      return "<h3>" + esc(m.p.title || m.p.url) + "</h3>\n" + shown.map(function (i) {
        var cls = i.level === "critical" ? "critical" : "warning";
        var chip = i.level === "critical" ? "Critical" : "Warning";
        return '<div class="issue ' + cls + '"><span class="tag">' + chip + "</span><b>" + esc(i.title) + "</b>"
          + "<p>" + esc(i.desc) + "</p>"
          + (i.rec ? "<p><b>Recommendation:</b> " + esc(i.rec) + "</p>" : "")
          + "</div>";
      }).join("\n") + "\n" + more;
    }).join("\n");

    // Category table (critical/warning only for the headline, all counts listed)
    var catRows = Object.keys(categoryTotals).map(function (k) {
      var n = categoryTotals[k];
      return "<tr>" + row(CATEGORY_NAMES[k] || k, n) + "</tr>";
    }).join("\n");

    // Network section
    function urlTable(list, emptyMsg) {
      if (!list.length) return '<p class="empty">' + esc(emptyMsg) + "</p>";
      return list.map(function (b) {
        return '<div class="issue critical"><span class="tag">Critical</span><b>' + esc(b.reason) + "</b>"
          + '<p>' + esc(b.url) + (b.foundOn ? '<span class="small">Found on: ' + esc(b.foundOn) + "</span>" : "") + "</p>"
          + (b.reason ? '</div>' : '</div>');
      }).join("\n");
    }

    // Findings grouped per category, severity-sorted, capped per category
    var GROUP_ORDER = ["layout", "responsive", "icons", "cta", "design", "structure", "urls", "images"];
    var sevRank = { error: 0, warning: 1, info: 2 };
    function findingBlocks(cat) {
      var items = allFindings.filter(function (f) { return f.cat === cat; })
        .sort(function (a, b) { return (sevRank[a.severity] || 3) - (sevRank[b.severity] || 3); });
      if (!items.length) return '<p class="empty">Nothing found in this category \u2014 clean.</p>';
      var shown = items.slice(0, 40);
      return shown.map(function (f) {
        var cls = f.severity === "error" ? "critical" : f.severity === "warning" ? "warning" : "good";
        var chip = f.severity === "error" ? "Critical" : f.severity === "warning" ? "Warning" : "Cue";
        return '<div class="issue ' + cls + '"><span class="tag">' + chip + "</span><b>" + esc(f.title) + "</b>"
          + (f.loc ? '<span class="small">' + esc(f.loc) + (f.section ? " \u2014 " + esc(f.section) : "") + "</span>" : "")
          + '<p>' + esc(f.fix) + "</p>"
          + '<span class="small page-ref">' + esc(f.page) + "</span></div>";
      }).join("\n");
    }

    var catSecs = GROUP_ORDER.map(function (cat) {
      return '<h2>' + esc(CATEGORY_NAMES[cat] || cat) + "</h2>\n" + findingBlocks(cat);
    }).join("\n");

    var allCrit = totals.errors + normTotals.critical;
    var allWarn = totals.warnings + normTotals.warning;
    var verdict = (allCrit === 0 && allWarn === 0) ? "Excellent \u2014 no issues found across the site"
      : allCrit === 0 ? "Good \u2014 " + allWarn + " warning" + (allWarn === 1 ? "" : "s") + " to address"
      : allCrit + " critical fix" + (allCrit === 1 ? "" : "es") + " required";
    if (stopped) verdict += " \u2014 partial results, the crawl was stopped early";

    var html = "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
      + '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
      + "<title>Website Frontend Audit \u2014 " + esc(host) + "</title>\n"
      + "<style>\n"
      + "@page { size: Letter; margin: 0.9in 0.8in; }\n"
      + "* { box-sizing: border-box; }\n"
      + "html { background: #fff; }\n"
      + "body { font-family: Georgia, 'Times New Roman', serif; color: #1b1b1b; margin: 0; line-height: 1.6; }\n"
      + ".doc { max-width: 760px; margin: 0 auto; padding: 44px 28px 70px; }\n"
      + ".doc-brand { font-size: 10.5px; letter-spacing: 3px; text-transform: uppercase; color: #71717a; border-bottom: 2px solid #111; padding-bottom: 10px; }\n"
      + ".doc-brand b { color: #111; }\n"
      + "h1 { font-size: 26px; font-weight: 700; margin: 24px 0 4px; letter-spacing: .2px; }\n"
      + ".doc-meta { font-size: 11.5px; color: #555; margin: 10px 0 0; }\n"
      + ".doc-meta div { margin: 2px 0; overflow-wrap: anywhere; }\n"
      + ".doc-meta b { color: #222; font-weight: 600; }\n"
      + "hr.doc-rule { border: 0; border-top: 1px solid #d6d6d6; margin: 26px 0 6px; }\n"
      + "h2 { font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 12.5px; text-transform: uppercase; letter-spacing: 1.5px; color: #111; border-bottom: 1px solid #cfcfcf; padding-bottom: 6px; margin: 28px 0 14px; }\n"
      + "table { width: 100%; border-collapse: collapse; font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 12.5px; margin-bottom: 8px; }\n"
      + "td { padding: 6px 10px; border-bottom: 1px solid #ececec; vertical-align: top; font-size: 12.5px; }\n"
      + "td:first-child { width: 42%; color: #555; font-weight: 500; }\n"
      + ".issues .issue { font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 12.5px; padding: 8px 12px; margin: 0 0 9px; border-left: 3px solid #d4d4d4; background: #fafafa; }\n"
      + ".issues .issue.critical { border-left-color: #b91c1c; background: #fdf8f8; }\n"
      + ".issues .issue.warning { border-left-color: #b45309; background: #fbf7f0; }\n"
      + ".issues .issue.good { border-left-color: #15803d; background: #f6fbf8; }\n"
      + ".issues .issue.info { border-left-color: #2563eb; background: #f0f4ff; }\n"
      + ".issues .tag { display: inline-block; font-size: 9px; letter-spacing: 1px; font-weight: 700; text-transform: uppercase; padding: 1px 6px; border: 1px solid currentColor; border-radius: 2px; margin: 0 8px 0 0; vertical-align: 1px; font-family: Georgia, serif; }\n"
      + ".issues .critical .tag { color: #b91c1c; } .issues .warning .tag { color: #b45309; } .issues .good .tag { color: #15803d; }\n"
      + ".issues b { font-size: 12.5px; }\n"
      + ".issues p { margin: 3px 0 0; color: #333; font-size: 12.5px; }\n"
      + ".issues .small { display: block; margin-top: 3px; color: #777; font-size: 11px; }\n"
      + ".issues .small.page-ref { font-style: italic; color: #999; }\n"
      + ".empty { color: #888; font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; font-size: 12.5px; font-style: italic; }\n"
      + ".glance { margin: 18px 0; font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }\n"
      + ".glance-row { display: flex; gap: 12px; }\n"
      + ".glance-stat { flex: 1; text-align: center; padding: 10px 6px; border-radius: 6px; border: 1px solid #e5e7eb; }\n"
      + ".glance-stat b { display: block; font-size: 22px; margin-bottom: 2px; }\n"
      + ".glance-stat span { display: block; font-size: 11px; color: #555; text-transform: uppercase; letter-spacing: 0.5px; }\n"
      + ".glance-stat.critical b { color: #b91c1c; } .glance-stat.warning b { color: #b45309; } .glance-stat.good b { color: #15803d; }\n"
      + ".foot { margin-top: 36px; padding-top: 10px; border-top: 1px solid #d6d6d6; font-size: 10.5px; color: #999; font-family: -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; }\n"
      + "</style>\n</head>\n<body>\n<div class=\"doc\">\n"
      + '<div class="doc-brand">Web Doctor <b>\u00B7 QA Report</b></div>\n'
      + "<h1>Website Frontend Audit</h1>\n"
      + '<div class="doc-meta">\n'
      + "<div><b>Site:</b> " + esc(meta.root || "") + "</div>\n"
      + (host ? "<div><b>Host:</b> " + esc(host) + "</div>\n" : "")
      + "<div><b>Pages scanned:</b> " + num(pages.length) + (meta.failed ? " (" + meta.failed + " unreachable)" : "") + "</div>\n"
      + "<div><b>Generated:</b> " + esc(dateStr) + "</div>\n"
      + "</div>\n"
      + '<hr class="doc-rule">\n'
      + "<h2>Health at a Glance</h2>\n"
      + '<div class="glance"><div class="glance-row">'
      + '<div class="glance-stat critical"><b>' + totals.errors + "</b><span>Critical fixes required</span></div>"
      + '<div class="glance-stat warning"><b>' + totals.warnings + "</b><span>Warnings to address</span></div>"
      + '<div class="glance-stat good"><b>' + totals.infos + "</b><span>Improvement cues</span></div>"
      + "</div></div>\n"
      + '<div class="doc-meta"><div><b>Verdict:</b> ' + esc(verdict) + "</div></div>\n"
      + "<h2>Pages Scanned</h2>\n<table>\n" + pageRows + "\n</table>\n"
      + "<h2>Core Metrics per Page</h2>\n"
      + '<table>\n<tr style="font-weight:bold;"><td>Page</td><td>LCP</td><td>CLS</td><td>INP</td><td>Load</td><td>DOM nodes</td><td>Issues</td></tr>\n' + metricRows + "\n</table>\n"
      + '<div class="doc-meta"><div>Pages with full analysis: <b>' + num(fullPages) + "</b> of " + num(pages.length)
      + (normTotals.critical + normTotals.warning ? " \u2014 " + num(normTotals.critical) + " critical \u00B7 " + num(normTotals.warning) + " warnings normalized" : " \u2014 no full-analysis findings")
      + (stopped ? " \u00B7 <b>partial results, the crawl was stopped early</b>" : "") + ".</div></div>\n"
      + "<h2>Findings by Category</h2>\n<table>\n" + catRows + "\n</table>\n"
      + "<h2>Broken URLs</h2>\n<div class=\"issues\">\n" + urlTable(probes.brokenLinks || [], "No broken child-page URLs found \u2014 every collected link is reachable.") + "\n</div>\n"
      + "<h2>Missing Images</h2>\n<div class=\"issues\">\n" + urlTable(probes.brokenImages || [], "No missing image URLs found \u2014 every collected media file loads.") + "\n</div>\n"
      + (normSecs.indexOf('<div class="issue') !== -1 ? "<h2>Full-Page Findings</h2>\n<div class=\"issues\">\n" + normSecs + "\n</div>\n" : "")
      + "<h2>Detailed Findings</h2>\n"
      + catSecs
      + '<div class="foot"><span>Prepared by the Web Doctor extension</span><span>' + num(pages.length) + " page(s) \u00B7 " + totals.findings + " finding" + (totals.findings === 1 ? "" : "s") + "</span></div>\n"
      + "</div>\n</body>\n</html>";
    return html;
  }

  function crawlExportName() {
    var host = "web-doctor";
    try {
      if (crawlState.data && crawlState.data.meta && crawlState.data.meta.root) {
        host = String(new URL(crawlState.data.meta.root).host).replace(/[^a-zA-Z0-9.-]/g, "-").replace(/^-+|-+$/g, "") || "web-doctor";
      }
    } catch (e) {}
    return host + "-site-report.html";
  }

  function viewCrawlReport() {
    if (!crawlState.data) return;
    if (!crawlState.doc) crawlState.doc = buildCrawlReport(crawlState.data);
    hostBlob("site-report.html", crawlState.doc, "text/html", function (url) {
      if (!url) {
        var st0 = document.getElementById("crawlStatus");
        if (st0) st0.textContent = "Could not open the report tab.";
        return;
      }
      crawlState.blobUrl = url;
      chrome.tabs.create({ url: url }, function () {
        var st = document.getElementById("crawlStatus");
        if (chrome.runtime.lastError && st) st.textContent = "Could not open the report tab: " + chrome.runtime.lastError.message;
      });
    });
  }

  function downloadCrawlReport() {
    var st = document.getElementById("crawlStatus");
    if (!crawlState.data) {
      if (st) st.textContent = "Scan the site first, then download the report.";
      return;
    }
    if (!crawlState.doc) crawlState.doc = buildCrawlReport(crawlState.data);
    downloadReportBlob(crawlExportName(), crawlState.doc, "text/html", st, "of the site report started");
  }

  // ------------------------------------------------------------
  // Reports
  // ------------------------------------------------------------
  function renderReports(secEl) {
    var html = head("reports", "Build and export a report file, or scan the whole site \u2014 plus the raw issue-list exports.");
    html += "<div class='report-row'>"
      + cws("Export issues (CSV)", "Issue list with severity, category, evidence and fix \u2014 opens in any spreadsheet.", "report-csv")
      + cws("Export full scan (JSON)", "Complete raw scan object exactly as captured from the page \u2014 for scripts and tooling.", "report-json")
      + "</div>";
    html += '<div class="card"><h3 class="card-title">What is exported</h3>'
      + '<ul class="dash-steps"><li>All ' + dashIssues.length + " normalized issues (severity, category, description, recommendation).</li>"
      + "<li>Per-element evidence: selectors, URLs and snippets the analyzers captured.</li>"
      + "<li>Core Web Vitals and timing values as the browser reported them.</li>"
      + "<li>No data ever leaves your machine \u2014 every export is generated locally.</li></ul></div>";
    html += auditCardHtml();
    html += crawlCardHtml();
    secEl.innerHTML = html;
    wireReportCards();
  }

  // Markup for the two cards migrated out of the popup's Audit tab.
  function auditCardHtml() {
    return '<div class="card">'
      + '<h3 class="card-title">Audit File</h3>'
      + '<p class="card-hint">Generate a complete report of everything this scan found &mdash; critical issues, warnings, what is working well, the technology stack and responsive signals. The file content is not shown automatically: press <strong>View File</strong> to render the preview. <strong>Convert to Docs File</strong> uploads the report to your Google Drive and opens it straight as a new, editable Google Docs document (one-time Google sign-in and an OAuth client id in manifest.json required; the Download buttons work without any of that).</p>'
      + '<div class="devmod-row">'
        + '<button id="btnCreateReport" class="btn-apply" type="button">Audit Report</button>'
        + '<button id="btnViewAuditFile" class="btn-ghost btn-download" type="button" disabled>View File</button>'
        + '<button id="btnConvertDocs" class="btn-apply btn-download" type="button" disabled>Convert to Docs File</button>'
      + '</div>'
      + '<div id="auditStatus" class="audit-status hidden" aria-live="polite"></div>'
      + '<div id="auditPreview" class="audit-preview hidden">'
        + '<div class="audit-preview-bar">'
          + '<span id="auditPreviewLabel" class="audit-preview-label"></span>'
          + '<button id="btnOpenReportTab" class="btn-ghost btn-download" type="button">Open in new tab</button>'
          + '<button id="btnDownloadReport" class="btn-ghost btn-download" type="button" disabled>Download Report (.html)</button>'
          + '<button id="btnDownloadDocs" class="btn-apply btn-download" type="button" disabled>Download Docs File (.doc)</button>'
        + '</div>'
        + '<iframe id="auditPreviewFrame" class="audit-preview-frame" title="Audit report preview"></iframe>'
      + '</div>'
      + '<p class="card-hint" id="auditDownloadHint"></p>'
      + '</div>';
  }

  function crawlCardHtml() {
    return '<div class="card" id="crawlCard">'
      + '<h3 class="card-title">Site Crawler</h3>'
      + '<p class="card-hint">Scan this site\u2019s child pages for frontend structure and responsive-layout breakages &mdash; layout overflow, viewport problems, icon and CTA issues, design flaws, broken URLs, missing images, and missing structural tags. Pages load one at a time in a silent background tab (a one-time site-access grant is requested, like the Broken Links scanner), then every collected URL is verified and all findings merge into a single site report file.</p>'
      + '<div class="devmod-row">'
        + '<label class="devmod-field">Max pages'
          + '<input id="crawlMaxPages" class="devmod-input devmod-input-sm" type="number" min="1" max="25" value="8">'
        + '</label>'
        + '<button id="btnStartCrawl" class="btn-apply" type="button">Scan Child Pages</button>'
        + '<button id="btnStopCrawl" class="btn-apply btn-stop" type="button" disabled>Stop</button>'
      + '</div>'
      + '<div id="crawlStatus" class="audit-status hidden" aria-live="polite"></div>'
      + '<div id="crawlSummary" class="crawl-summary hidden"></div>'
      + '<div class="devmod-row">'
        + '<button id="btnViewCrawlReport" class="btn-ghost btn-download" type="button" disabled>View Site Report</button>'
        + '<button id="btnDownloadCrawlReport" class="btn-ghost btn-download" type="button" disabled>Download Site Report (.html)</button>'
      + '</div>'
      + '<p class="card-hint" id="crawlHint"></p>'
      + '</div>';
  }

  // Binds the two migrated cards. Reports re-renders whenever scan data
  // changes, which replaces these nodes, so each button is stamped with
  // data-wired to keep a re-render from stacking duplicate listeners.
  function wireReportCards() {
    var btnStartCrawl = document.getElementById("btnStartCrawl");
    if (btnStartCrawl && !btnStartCrawl.getAttribute("data-wired")) {
      btnStartCrawl.setAttribute("data-wired", "1");
      btnStartCrawl.addEventListener("click", startCrawl);
    }
    var btnStopCrawl = document.getElementById("btnStopCrawl");
    if (btnStopCrawl && !btnStopCrawl.getAttribute("data-wired")) {
      btnStopCrawl.setAttribute("data-wired", "1");
      btnStopCrawl.addEventListener("click", stopCrawl);
    }
    var btnViewCrawlReport = document.getElementById("btnViewCrawlReport");
    if (btnViewCrawlReport && !btnViewCrawlReport.getAttribute("data-wired")) {
      btnViewCrawlReport.setAttribute("data-wired", "1");
      btnViewCrawlReport.addEventListener("click", viewCrawlReport);
    }
    var btnDownloadCrawlReport = document.getElementById("btnDownloadCrawlReport");
    if (btnDownloadCrawlReport && !btnDownloadCrawlReport.getAttribute("data-wired")) {
      btnDownloadCrawlReport.setAttribute("data-wired", "1");
      btnDownloadCrawlReport.addEventListener("click", downloadCrawlReport);
    }
    var btnCreateReport = document.getElementById("btnCreateReport");
    if (btnCreateReport && !btnCreateReport.getAttribute("data-wired")) {
      btnCreateReport.setAttribute("data-wired", "1");
      btnCreateReport.addEventListener("click", makeAuditFile);
    }
    var btnViewAuditFile = document.getElementById("btnViewAuditFile");
    if (btnViewAuditFile && !btnViewAuditFile.getAttribute("data-wired")) {
      btnViewAuditFile.setAttribute("data-wired", "1");
      btnViewAuditFile.addEventListener("click", viewAuditFile);
    }
    var btnConvertDocs = document.getElementById("btnConvertDocs");
    if (btnConvertDocs && !btnConvertDocs.getAttribute("data-wired")) {
      btnConvertDocs.setAttribute("data-wired", "1");
      btnConvertDocs.addEventListener("click", convertToDocsFile);
    }
    var btnOpenReportTab = document.getElementById("btnOpenReportTab");
    if (btnOpenReportTab && !btnOpenReportTab.getAttribute("data-wired")) {
      btnOpenReportTab.setAttribute("data-wired", "1");
      btnOpenReportTab.addEventListener("click", openAuditReportTab);
    }
    var btnDownloadDocs = document.getElementById("btnDownloadDocs");
    if (btnDownloadDocs && !btnDownloadDocs.getAttribute("data-wired")) {
      btnDownloadDocs.setAttribute("data-wired", "1");
      btnDownloadDocs.addEventListener("click", downloadAuditDocsFile);
    }
    var btnDownloadReport = document.getElementById("btnDownloadReport");
    if (btnDownloadReport && !btnDownloadReport.getAttribute("data-wired")) {
      btnDownloadReport.setAttribute("data-wired", "1");
      btnDownloadReport.addEventListener("click", downloadAuditFile);
    }
  }

  function cws(title, desc, kind) {
    return '<div class="report-card"><h3>' + esc(title) + '</h3><p>' + esc(desc) + '</p>'
      + '<div class="report-actions"><button class="dash-btn" data-report="' + kind + '" type="button">' + esc(title) + "</button></div></div>";
  }

  function downloadBlob(name, text, type) {
    try {
      var blob = new Blob([text], { type: type || "text/plain;charset=utf-8" });
      var url = URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
    } catch (e) {}
  }

  function csvEscape(v) {
    var s = String(v === undefined || v === null ? "" : v);
    if (/[",\n]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  function exportCsv() {
    var lines = ["level,category,title,evidence,fix"];
    dashIssues.forEach(function (i) {
      var d = WD.wdIssueDetail(i);
      lines.push([i.level, i.category, i.title, d.evidence, d.fix].map(csvEscape).join(","));
    });
    var meta = "Web Doctor audit \u2014 " + (dashUrl || "") + " \u2014 " + formatTs(dashTs);
    downloadBlob(hostOf(dashUrl) + "-issues.csv", meta + "\n" + lines.join("\n"), "text/csv;charset=utf-8");
  }

  function exportJson() {
    var payload = {
      meta: { exportedAt: new Date().toISOString(), scannedAt: new Date(dashTs).toISOString(), url: dashUrl },
      summary: {
        score: dashData.scores || {},
        issues: dashIssues,
        coreWebVitals: WD.cwvOf(dashData.performance),
        platform: WD.platformOf(dashData.technology)
      },
      raw: dashData
    };
    downloadBlob(hostOf(dashUrl) + "-audit.json", JSON.stringify(payload, null, 2), "application/json;charset=utf-8");
  }

  // ------------------------------------------------------------
  // AI — multi-provider chat + provider management.
  // Optional layer: everything on the dashboard works without it.
  // ------------------------------------------------------------
  var AI_SYSTEM = [
    "You are Web Doctor's AI assistant for web audits.",
    "RULES:",
    "1. Only the scan context provided below contains real measurements. Treat any other number as unverified.",
    "2. Ground each factual statement in the scan and prefix it with the word \"Detected\" (e.g. **Detected**: 12 images missing alt).",
    "3. Label hypotheses or reasoning with \"Possible cause\" (e.g. **Possible cause**: ...).",
    "4. If the context does not contain the answer, say \"Not in the scan data - I cannot verify that\" instead of guessing.",
    "5. Never invent a score, count, byte size, selector, or metric. No fake numbers.",
    "6. Give actionable fixes. When you suggest code, put it in a fenced ```html / ```css / ```js block.",
    "7. When the user asks you to debug a specific issue, end your answer with a short section starting with **AI Suggested Fix:**.",
    "Keep answers concise and specific to THIS scan."
  ].join("\n");

  var AI_TASKS = [
    { k: "question", l: "Free-form question" },
    { k: "general", l: "Whole scan overview" },
    { k: "performance", l: "Performance & Core Web Vitals" },
    { k: "css", l: "CSS / styling" },
    { k: "js", l: "JavaScript" },
    { k: "dom", l: "DOM & structure" },
    { k: "seo", l: "SEO" },
    { k: "accessibility", l: "Accessibility" },
    { k: "responsive", l: "Responsive / layout" },
    { k: "images", l: "Images" },
    { k: "links", l: "Links" },
    { k: "network", l: "Network / requests" }
  ];

  var AI_TASK_CAT = {
    css: "css", typography: "css", javascript: "js", dom: "dom", hidden: "dom",
    structure: "dom", seo: "seo", accessibility: "accessibility", responsive: "responsive",
    images: "images", links: "links", forms: "general", performance: "performance",
    cwv: "performance", technology: "general", elementor: "general", security: "general"
  };

  var aiCfg = null;
  var aiBusy = false;
  var aiRunCtrl = null;
  var aiStreamText = "";
  var beforeCmp = null;
  var afterCmp = null;

  function aiEnsure(cb) {
    if (aiCfg) { cb(); return; }
    AICore.load(function (o) {
      aiCfg = o || { wdAiProviders: [], wdAiMode: "auto", wdAiModeId: null };
      aiCfg.wdAiProviders = aiCfg.wdAiProviders || [];
      aiCfg.wdAiMode = aiCfg.wdAiMode || "auto";
      seedMissingModels();
      if (o && o.wdAiSession && AICore.restoreSession) AICore.restoreSession(o.wdAiSession);
      cb();
    });
  }

  // Providers saved before model discovery ran (or by older builds) get their
  // maintained model list seeded so selects + auto-model work immediately.
  function seedMissingModels() {
    var changed = false;
    (aiCfg.wdAiProviders || []).forEach(function (p) {
      if (!p || !p.apiKey || !p.provider) return;
      if (p.models && p.models.length) return;
      var reg = AICore.PROVIDERS[p.provider];
      if (!reg || !reg.curated) return;
      p.models = seedModels(reg);
      changed = true;
    });
    if (changed) persistAi();
  }

  function seedModels(reg) {
    var free = AICore.curatedFree && AICore.curatedFree[reg.id] || [];
    return (reg.curated || []).map(function (m) {
      var tags = AICore.tagsOf(m);
      return {
        id: m.id, contextLength: m.ctx || 0,
        vision: tags.vision, tools: tags.tools, coding: tags.coding,
        fast: tags.fast, reason: tags.reason,
        free: free.indexOf(m.id) !== -1
      };
    });
  }

  function persistAi() {
    AICore.save({ wdAiProviders: aiCfg.wdAiProviders, wdAiMode: aiCfg.wdAiMode, wdAiModeId: aiCfg.wdAiModeId });
  }

  function providerBy(id) {
    var out = null;
    (aiCfg.wdAiProviders || []).forEach(function (p) { if (p && p.id === id) out = p; });
    return out;
  }

  function hasKey(p) { return !!(p && p.apiKey); }

  function modelsFor(cfg) {
    if (cfg && cfg.models && cfg.models.length) return cfg.models;
    var cur = (cfg && AICore.PROVIDERS[cfg.provider] && AICore.PROVIDERS[cfg.provider].curated) || [];
    return cur.map(function (m) { return { id: m.id, contextLength: m.ctx || 0, free: false }; });
  }

  // --- rendering -------------------------------------------------
  function renderAi(secEl) {
    secEl.innerHTML = '<div class="dash-section-head"><h2>' + "\uD83D\uDCA4" + "AI Chat</h2>"
      + "<p>Ask questions about this real scan, or press <b>Debug with AI</b> on any issue card. Everything is optional \u2014 the scanner and dashboard work with no provider configured. AI answers are advisory: scan facts are labeled <b>Detected</b>, reasoning is labeled <b>Possible cause</b>.</p></div>"
      + welcomeMarkup()
      + '<div id="aiLayout" class="ai-layout" hidden>'
      + '<div class="ai-chat">'
      + '<div id="aiMsgs" class="ai-msgs"></div>'
      + '<div id="aiStatus" class="ai-status" hidden></div>'
      + '<button class="ai-stick" type="button" data-ai="stick" hidden>\u2193 Latest</button>'
      + '<div class="ai-toolbar">'
      + '<textarea id="aiInput" rows="2" placeholder="Ask about this scan\u2026 e.g. Why is DOM depth high?"></textarea>'
      + '<button class="ai-btn send" type="button" data-ai="send">Send</button>'
      + '<button class="ai-btn danger" type="button" data-ai="stop" disabled>Stop</button>'
      + "</div></div>"
      + '<div class="ai-side">'
      + '<div class="card"><label for="aiMode">AI mode</label>'
      + "<select id=\"aiMode\" data-ai-change=\"mode\"><option value=\"auto\">Auto \u2014 smart routing</option><option value=\"free\">Free AI Mode \u2014 free models only</option><option value=\"manual\">Manual \u2014 my chosen provider</option></select>"
      + '<div id="aiHint" class="hint"></div></div>'
      + '<div class="card"><label for="aiProvider">Provider</label><select id="aiProvider" data-ai-change="provider"></select>'
      + '<label for="aiModel">Model</label><select id="aiModel" data-ai-change="model"></select>'
      + '<div class="hint">Models come from your provider list or are discovered from the provider API.</div></div>'
      + '<div class="card"><label>Providers &amp; keys</label>' + providerPanelMarkup() + "</div>"
      + '<div class="card"><label for="aiTask">Context target</label><select id="aiTask" data-ai-change="task">'
      + AI_TASKS.map(function (t) { return '<option value="' + t.k + '">' + esc(t.l) + "</option>"; }).join("")
      + "</select><div class=\"hint\">Pins what gets sent to the provider (sanitized).</div></div>"
      + '<details class="ai-disclosure"><summary>What will be sent to the AI provider?</summary>'
      + '<div class="body" id="aiCtxPreview"></div></details>'
      + '<div class="card"><label>Conversation</label><div class="ap-actions">'
      + '<button class="ai-btn" type="button" data-ai="regen">Regenerate</button>'
      + '<button class="ai-btn" type="button" data-ai="retry">Retry</button>'
      + '<button class="ai-btn" type="button" data-ai="copy">Copy</button>'
      + '<button class="ai-btn danger" type="button" data-ai="clear">Clear</button></div></div>'
      + '<div class="card"><label>Before / After compare</label><div id="aiCmpSlot"></div></div>'
      + "</div></div>";
    aiEnsure(function () {
      wireOnboard();
      refreshAiOnboarding();
      populateAiControls();
      toggleBaseUrlRow("openai-compatible");
      fillApList();
      bindAiScroll();
      renderChat(true);
      aiCtxPreview();
      renderCmpCard();
    });
  }

  function welcomeMarkup() {
    return '<div id="aiWelcome" class="ai-welcome" hidden>'
      + '<div class="ai-welcome-card">'
      + '<div class="ai-welcome-icon">' + "\uD83D\uDD11" + "</div>"
      + "<h3>Connect an AI assistant</h3>"
      + '<p class="ai-welcome-sub">Paste an API key from any AI provider and start chatting in about 30 seconds. '
      + "Everything else in Web Doctor works without one.</p>"
      + '<ol class="ai-welcome-steps">'
      + "<li><b>Get a key</b> \u2014 free-trial credit on OpenRouter, Groq, Google Gemini, or any provider you already use.</li>"
      + "<li><b>Paste it here</b> \u2014 the provider is detected automatically.</li>"
      + "<li><b>Ask anything</b> about this scan, or press <b>Debug with AI</b> on any issue.</li></ol>"
      + '<div class="ap-field"><span>Your API key</span><input type="password" id="owKey" autocomplete="off" spellcheck="false" placeholder="sk-&#8230;, sk-or-&#8230;, AIza&#8230;, gsk_&#8230;"></div>'
      + '<div class="ap-field"><span>Provider</span><select id="owProvider">'
      + providerOptions()
      + "</select></div>"
      + '<div class="ap-field" id="owBaseRow" hidden><span>Base URL</span><input type="text" id="owBase" placeholder="https://api.example.com/v1"></div>'
      + '<div class="ap-actions">'
      + '<button class="ai-btn send" type="button" data-ai="ow-save">Enable AI</button>'
      + "</div>"
      + '<p class="ai-welcome-note">Your key is stored only in this extension and never sent to any page. '
      + "Once enabled you can add more providers, test connections, and refresh models under "
      + "<b>Providers &amp; keys</b> in the chat sidebar. "
      + "Answers are advisory \u2014 scan facts are labeled <b>Detected</b>, reasoning <b>Possible cause</b>.</p>"
      + "</div></div>";
  }

  function providerOptions() {
    return Object.keys(AICore.PROVIDERS).map(function (id) {
      return '<option value="' + id + '">' + esc(AICore.PROVIDERS[id].label) + "</option>";
    }).join("");
  }

  function wireOnboard() {
    var ow = $("owKey"), op = $("owProvider");
    if (ow && op) {
      ow.addEventListener("input", function () {
        var det = AICore.detectProviderByKey(ow.value);
        if (det && !op.dataset.manual && op.value !== "openai-compatible") op.value = det;
        toggleOwBase();
      });
      op.addEventListener("change", function () { op.dataset.manual = "1"; toggleOwBase(); });
    }
    toggleOwBase();
  }

  function toggleOwBase() {
    var op = $("owProvider"), row = $("owBaseRow");
    if (op && row) row.hidden = op.value !== "openai-compatible";
  }

  // Show the welcome card until at least one provider has a key; then show chat.
  function refreshAiOnboarding() {
    var has = (aiCfg.wdAiProviders || []).some(function (p) { return p && p.apiKey; });
    var w = $("aiWelcome"), l = $("aiLayout");
    if (w) w.hidden = has;
    if (l) l.hidden = !has;
  }

  function handleQuickKey() {
    var ow = $("owKey");
    var key = AICore.stripKey((ow && ow.value) || "");
    var kind = ($("owProvider") && $("owProvider").value) || "openai";
    var reg = AICore.PROVIDERS[kind];
    var check = AICore.validateProviderKey(kind, key);
    if (!check.ok) { aiStatus(check.message, "err"); return; }
    var base = ($("owBase") && $("owBase").value.trim()) || (reg && reg.baseUrl) || "";
    if (kind === "openai-compatible" && !base) { aiStatus("A base URL is required for OpenAI-compatible endpoints.", "err"); return; }
    if (kind === "openai-compatible" && !/^https:\/\//i.test(base)) { aiStatus("The base URL must start with https://", "err"); return; }
    var cfg = {
      id: AICore.makeId(), provider: kind, label: (reg && reg.label) || kind,
      baseUrl: base, apiKey: key, models: seedModels(reg),
      activeModel: null, lastTest: null
    };
    (aiCfg.wdAiProviders || (aiCfg.wdAiProviders = [])).push(cfg);
    aiCfg.wdAiModeId = cfg.id;
    aiCfg.wdAiMode = aiCfg.wdAiMode || "auto";
    persistAi();
    if (ow) ow.value = "";
    refreshAiOnboarding();
    populateAiControls();
    fillApList();
    renderChat();
    renderCmpCard();
    aiStatus(check.warning || "Key added as " + ((reg && reg.label) || kind) + " \u2014 testing connection\u2026", check.warning ? "err" : "");
    apTest(cfg, null);
  }

  var aiStickMode = true;

  function aiNearBottom(el) {
    if (!el) return true;
    return (el.scrollHeight - el.scrollTop - el.clientHeight) < 80;
  }

  function aiStickBtn() { return document.querySelector('[data-ai="stick"]'); }

  function aiStick(force) {
    var el = $("aiMsgs");
    if (!el) return;
    if (force) aiStickMode = true;
    if (aiStickMode) el.scrollTop = el.scrollHeight;
    var b = aiStickBtn();
    if (b) b.hidden = true;
  }

  function onAiScroll() {
    var el = $("aiMsgs");
    aiStickMode = aiNearBottom(el);
    var b = aiStickBtn();
    if (b) b.hidden = aiStickMode;
  }

  function bindAiScroll() {
    var el = $("aiMsgs");
    if (el && !el.__wdAiScroll) {
      el.__wdAiScroll = true;
      el.addEventListener("scroll", onAiScroll, { passive: true });
    }
  }

  function renderChat(forceStick) {
    var c = $("aiMsgs");
    if (!c) return;
    var h = AICore.getSession().history;
    c.innerHTML = (h && h.length) ? h.map(msgHtml).join("") : emptyChat();
    if (forceStick) aiStick(true); else aiStick();
  }

  function emptyChat() {
    return '<div class="ai-empty"><b>Ask Web Doctor AI</b>'
      + "<br>Ask about this scan, or open any issue card and press <b>Debug with AI</b>. "
      + "Answers stay advisory \u2014 facts are labeled <b>Detected</b>, reasoning is labeled <b>Possible cause</b>.</div>";
  }

  function msgHtml(m) {
    var isUser = m.role === "user";
    var meta = m.meta || {};
    var bubble = '<div class="bubble' + (meta.kind === "error" ? " ai-err" : "") + '">' + markdownLite(m.content) + "</div>";
    var metaLine = "";
    if (!isUser) {
      var bits = [];
      if (meta.kind === "error") bits.push('<span style="color:var(--danger)">error</span>');
      if (meta.provider) bits.push('<span class="provider-chip">' + esc(meta.provider) + "</span>");
      if (meta.model) bits.push(esc(meta.model));
      if (meta.break) bits.push("interrupted");
      bits.push(esc(timeOf(m.at)));
      metaLine = '<div class="meta">' + bits.join(" ") + "</div>";
    }
    return '<div class="ai-msg ' + (isUser ? "user" : "assistant") + '">' + bubble + metaLine + "</div>";
  }

  function timeOf(ts) {
    try { return new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }); } catch (e) { return ""; }
  }

  function markdownLite(text) {
    var parts = String(text || "").split(/```/);
    var out = "";
    for (var i = 0; i < parts.length; i++) {
      var seg = parts[i];
      if (i % 2 === 1) {
        seg = seg.replace(/^[a-z0-9_+.\-]*\r?\n/i, "");
        out += '<pre class="ai-code">' + esc(seg) + "</pre>";
      } else {
        var e = esc(seg);
        e = e.replace(/\*\*(Detected|Possible cause|AI Suggested Fix)\*\*/g, function (m, t) {
          if (t === "Detected") return '<span class="ai-span-detected">Detected</span>';
          if (t === "Possible cause") return '<span class="ai-span-possible">Possible cause</span>';
          return '<span class="ai-suggest-label">AI Suggested Fix</span>';
        });
        e = e.replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>");
        out += e;
      }
    }
    return out;
  }

  function aiCtxPreview() {
    var el = $("aiCtxPreview");
    if (!el) return;
    var task = ($("aiTask") && $("aiTask").value) || "question";
    var ctx = AICore.buildContext(dashData, { task: task, issue: null });
    el.textContent = ctx.length > 1400 ? ctx.slice(0, 1400) + "\n\u2026 (truncated in preview \u2014 full sanitized context is sent)" : ctx;
  }

  // --- chat flow --------------------------------------------------
  function aiStatus(text, cls) {
    var el = $("aiStatus");
    if (!el) return;
    el.hidden = !text;
    el.className = "ai-status" + (cls ? " " + cls : "");
    el.textContent = text || "";
  }

  function setAiBusy(v) {
    aiBusy = v;
    ["send", "regen", "retry"].forEach(function (k) {
      var b = document.querySelector("[data-ai=\"" + k + "\"]");
      if (b) b.disabled = v;
    });
    var stop = document.querySelector("[data-ai=\"stop\"]");
    if (stop) stop.disabled = !v;
  }

  function sendAi(text, task, issue, noPush) {
    if (aiBusy) return;
    text = String(text || "").trim();
    if (!text) return;
    if (!task) {
      task = ($("aiTask") && $("aiTask").value) || "question";
      if (issue && issue.category && AI_TASK_CAT[issue.category]) task = AI_TASK_CAT[issue.category];
    }
    var ctx = AICore.buildContext(dashData, { task: task, issue: issue || null });
    var hist = AICore.getSession().history.slice(-10);
    var msgs = [{ role: "system", content: AI_SYSTEM }];
    hist.forEach(function (h) {
      if (h.role !== "system") msgs.push({ role: h.role === "user" ? "user" : "assistant", content: h.content });
    });
    msgs.push({ role: "user", content: "REAL SCAN CONTEXT (the only source of real numbers you may use):\n" + ctx + "\n\n" + text });
    if (!noPush) AICore.pushMessage("user", text, { kind: "ask" });
    if (issue) AICore.setSessionIssue(issue);
    renderChat(true);
    setAiBusy(true);
    aiStreamText = "";
    var chosen = null;
    if (aiCfg.wdAiMode === "manual") {
      var msel = $("aiModel");
      chosen = msel && msel.value ? msel.value : null;
    }
    var config = { wdAiProviders: aiCfg.wdAiProviders, wdAiMode: aiCfg.wdAiMode, wdAiModeId: aiCfg.wdAiModeId };
    var ctl = AICore.chat({ messages: msgs, task: task, stream: true, model: chosen, temperature: 0.25 }, config, aiEvents);
    aiRunCtrl = ctl;
    ctl.run();
  }

  function aiEvents(type, data) {
    data = data || {};
    if (type === "route") {
      finalizeStream(true);
      aiStreamText = "";
      ensureStream();
      aiStatus((data.free ? "Free " : "") + "AI via " + data.provider + " \u00B7 " + data.model + " (step " + data.step + "/" + data.total + ")");
    } else if (type === "http") {
      if (data.status) aiStatus("Connected \u00B7 HTTP " + data.status);
    } else if (type === "delta") {
      aiStreamText += data.text || "";
      paintStream();
    } else if (type === "retry") {
      aiStatus((data.kind === "rate_limit" ? "Rate-limited" : "Retrying") + " \u2014 " + data.wait + "s via " + data.provider);
    } else if (type === "failed") {
      aiStatus(data.provider + " failed: " + data.reason);
      finalizeStream(true);
    } else if (type === "fallback") {
      aiStatus("Falling back from " + data.from + " to " + data.to + "\u2026");
    } else if (type === "done") {
      finalizeStream(false, data.provider, data.model);
      aiStatus("Responded via " + data.provider + (data.model ? " \u00B7 " + data.model : ""));
      setAiBusy(false);
    } else if (type === "stopped") {
      aiStatus("Stopped.");
      finalizeStream(true);
      setAiBusy(false);
    } else if (type === "error") {
      aiStatus(data.message || "No AI provider is configured.", "err");
      finalizeStream(true);
      pushAiError(data.message || "No AI provider is connected yet. Open the AI Chat tab and press Enable AI to paste a key.");
      setAiBusy(false);
    }
  }

  function ensureStream() {
    if ($("aiStreamBubble")) return;
    var msgs = $("aiMsgs");
    if (!msgs) return;
    var wrap = document.createElement("div");
    wrap.className = "ai-msg assistant";
    wrap.innerHTML = '<div class="bubble" id="aiStreamBubble"></div><div class="meta">typing\u2026</div>';
    msgs.appendChild(wrap);
    aiStick();
  }

  function paintStream() {
    var b = $("aiStreamBubble");
    if (!b) return;
    b.innerHTML = markdownLite(aiStreamText);
    aiStick();
  }

  function finalizeStream(cut, provider, model) {
    var b = $("aiStreamBubble");
    if (!b) return;
    var content = aiStreamText || "";
    if (cut && !content) { b.remove(); aiStreamText = ""; renderChat(); return; }
    if (!cut && !content) content = "(the provider returned no text)";
    var meta = { kind: "ai" };
    if (cut) meta.break = true;
    if (provider) meta.provider = provider;
    if (model) meta.model = model;
    AICore.pushMessage("assistant", content, meta);
    if (!cut) AICore.truncateHistory();
    renderChat();
    aiStreamText = "";
  }

  function pushAiError(msg) {
    AICore.pushMessage("assistant", msg, { kind: "error" });
    renderChat();
  }

  function stopAi() { if (aiRunCtrl) aiRunCtrl.stop(); aiRunCtrl = null; }

  function resendLast() {
    if (aiBusy) return;
    var h = AICore.getSession().history;
    var last = null;
    for (var i = h.length - 1; i >= 0; i--) {
      if (h[i].role === "user") { last = h[i]; break; }
    }
    if (!last) return;
    AICore.setSessionIssue(null);
    sendAi(last.content, last.meta && last.meta.task);
  }

  function clearChat() {
    stopAi();
    AICore.clearSession();
    AICore.persistSession();
    setAiBusy(false);
    renderChat();
    aiStatus("");
  }

  function copyLast() {
    var h = AICore.getSession().history;
    var last = null;
    for (var i = h.length - 1; i >= 0; i--) {
      if (h[i].role === "assistant" && h[i].content) { last = h[i].content; break; }
    }
    if (!last) return;
    try {
      navigator.clipboard.writeText(last);
      aiStatus("Copied to clipboard.");
    } catch (e) { aiStatus("Could not copy.", "err"); }
  }

  // --- provider management ----------------------------------------
  // Provider management now lives inside the AI Chat tab (all AI features in
  // one section). This builds the "Providers & keys" card markup.
  function providerPanelMarkup() {
    return '<div class="ap-grid" style="grid-template-columns:1fr 1fr 1fr;align-items:end">'
      + '<div class="ap-field"><span>Provider</span><select id="apKind" data-ai-change="apkind">'
      + AICore.providerList().map(function (p) { return '<option value="' + p.id + '">' + esc(p.label) + "</option>"; }).join("")
      + "</select></div>"
      + '<div class="ap-field"><span>Label</span><input type="text" id="apLabel" placeholder="My API"></div>'
      + '<div class="ap-field"><span>API key</span><input type="password" id="apKey" placeholder="sk-&#8230;" autocomplete="off"></div>'
      + "</div>"
      + '<div class="ap-field" id="apBaseUrlRow" style="margin-top:8px" hidden><span>Base URL</span><input type="text" id="apBaseUrl" placeholder="https://api.example.com/v1"></div>'
      + '<div class="ap-actions" style="margin-top:12px"><span class="ap-note">Keys never leave this extension and never appear in exports.</span><span class="spacer"></span>'
      + '<button class="ai-btn send" type="button" data-ai="ap-save">Save provider</button></div>'
      + '<div id="apList" class="ap-list" style="margin-top:12px"></div>';
  }

  function toggleBaseUrlRow(kind) {
    var row = $("apBaseUrlRow");
    if (row) row.hidden = kind !== "openai-compatible";
  }

  function fillApList() {
    var list = $("apList");
    if (!list) return;
    var provs = (aiCfg.wdAiProviders || []).filter(hasKey);
    if (!provs.length) {
      list.innerHTML = '<div class="ap-empty"><b>No AI provider configured yet</b>Add your own key above, or press "Debug with AI" on any issue to learn what is still needed. Everything else works without one.</div>';
      return;
    }
    list.innerHTML = provs.map(apCardHtml).join("");
  }

  function apCardHtml(cfg) {
    var reg = AICore.PROVIDERS[cfg.provider];
    var models = modelsFor(cfg);
    var am = models.length ? AICore.autoModel(cfg) : null;
    var sel = cfg.activeModel || (am && am.id) || models[0] && models[0].id || "";
    var opts = models.map(function (m) {
      return '<option value="' + esc(m.id) + '"' + (m.id === sel ? " selected" : "") + ">"
        + esc(m.id) + (m.free ? " (free)" : "") + (m.contextLength ? " \u00B7 " + Math.round(m.contextLength / 1000) + "k" : "") + "</option>";
    }).join("");
    var badge = cfg.lastTest && cfg.lastTest.ok
      ? '<span class="ap-badge ok">connected \u00B7 ' + (cfg.lastTest.models || "?") + " models</span>"
      : '<span class="ap-badge">' + (cfg.lastTest && cfg.lastTest.ok === false ? "not reachable" : "untested") + "</span>";
    var chips = models.slice(0, 14).map(function (m, i) {
      return '<span class="ap-model-chip' + (m.id === sel ? " active" : "") + '" data-mpick="' + cfg.id + ":" + i + '" title="' + esc(m.id) + '">'
        + esc(smartModelLabel(m.id)) + (m.free ? '<span class="free">\u00A0FREE</span>' : "") + "</span>";
    }).join("");
    return '<div class="ap-card"><div class="ap-head">'
      + "<b>" + esc(cfg.label || (reg && reg.label) || cfg.provider) + "</b>"
      + '<span class="mono ap-field" style="color:var(--muted);font-size:11px">' + esc((reg && reg.label) || cfg.provider) + "</span>"
      + badge + '<span class="spacer" style="flex:1"></span>'
      + '<span class="ap-note mono">' + esc(AICore.maskKey(cfg.apiKey)) + "</span></div>"
      + '<div class="ap-field"><span>Active model</span><select data-apmodel="' + esc(cfg.id) + '">' + opts + "</select></div>"
      + '<div class="ap-model-list">' + chips + "</div>"
      + '<div class="ap-actions">'
      + '<button class="ai-btn" type="button" data-act="test" data-pid="' + esc(cfg.id) + '">Test connection</button>'
      + '<button class="ai-btn" type="button" data-act="models" data-pid="' + esc(cfg.id) + '">Refresh models</button>'
      + '<span class="spacer"></span>'
      + '<button class="ai-btn danger" type="button" data-act="delete" data-pid="' + esc(cfg.id) + '">Delete</button>'
      + "</div></div>";
  }

  function smartModelLabel(id) {
    var s = String(id || "").split(":")[0];
    var i = s.lastIndexOf("/");
    return i === -1 ? s : s.slice(i + 1);
  }

  function saveProviderFromForm() {
    var kind = $("apKind").value;
    var reg = AICore.PROVIDERS[kind];
    var key = AICore.stripKey($("apKey").value);
    var check = AICore.validateProviderKey(kind, key);
    if (!check.ok) { aiStatus(check.message, "err"); return; }
    var base = ($("apBaseUrl") && $("apBaseUrl").value.trim()) || (reg && reg.baseUrl) || "";
    if (kind === "openai-compatible" && !base) { aiStatus("A base URL is required for OpenAI-compatible endpoints.", "err"); return; }
    if (kind === "openai-compatible" && !/^https:\/\//i.test(base)) { aiStatus("The base URL must start with https://", "err"); return; }
    var label = ($("apLabel") && $("apLabel").value.trim()) || (reg && reg.label) || kind;
    var cfg = { id: AICore.makeId(), provider: kind, label: label, baseUrl: base, apiKey: key, models: seedModels(reg), activeModel: null, lastTest: null };
    aiCfg.wdAiProviders.push(cfg);
    aiCfg.wdAiModeId = cfg.id;
    persistAi();
    if ($("apKey")) $("apKey").value = "";
    fillApList();
    populateAiControls();
    refreshAiOnboarding();
    aiStatus(check.warning || "Provider saved \u2014 testing connection\u2026", check.warning ? "err" : "");
    apTest(cfg, null);
  }

  function apTest(cfg, btn) {
    if (btn) { btn.disabled = true; btn.textContent = "Testing\u2026"; }
    AICore.testConnection(cfg, function (r) { finishTest(cfg, btn, r); });
  }

  // Applies a connection-test result: seeds discovered models, auto-selects the
  // fast-tier default model, persists, refreshes every view, reports status.
  function finishTest(cfg, btn, r) {
    cfg.lastTest = r;
    if (r && r.ok) {
      if (r.picker && r.picker.length) cfg.models = r.picker;
      var am = AICore.autoModel(cfg);
      if (am) cfg.activeModel = am.id;
    }
    persistAi();
    fillApList();
    fillModelSelect();
    if (btn) { btn.disabled = false; btn.textContent = "Test connection"; }
    if (r && r.ok) {
      aiStatus((cfg.label || cfg.provider) + " ready \u00B7 " + r.models + " models"
        + (r.warning ? " \u2014 " + r.warning : "") + " \u2014 ask anything in the chat.");
    } else {
      aiStatus((cfg.label || cfg.provider) + " not reachable: " + ((r && r.error) || "no response")
        + ". The key stays saved and will be retried in chat.", "err");
    }
  }

  function apDiscover(cfg, btn) {
    if (btn) { btn.disabled = true; btn.textContent = "Refreshing\u2026"; }
    AICore.discoverModels(cfg, function (r) {
      if (r && r.ok) {
        if (r.picker && r.picker.length) {
          cfg.models = r.picker;
          var am = AICore.autoModel(cfg);
          if (am) cfg.activeModel = am.id;
        }
        persistAi();
        fillApList();
        fillModelSelect();
        aiStatus((r.fallback ? "Using maintained model list (" : "Discovered ") + r.models.length + " models" + (r.warning ? " \u2014 " + r.warning : "") + (r.fallback ? ")" : "") + ".");
      } else {
        if (btn) { btn.disabled = false; btn.textContent = "Refresh models"; }
        aiStatus("Could not refresh models.", "err");
      }
    });
  }

  function apDelete(cfg) {
    if (!window.confirm("Remove this provider from Web Doctor?")) return;
    aiCfg.wdAiProviders = aiCfg.wdAiProviders.filter(function (p) { return p.id !== cfg.id; });
    if (aiCfg.wdAiModeId === cfg.id) aiCfg.wdAiModeId = null;
    persistAi();
    fillApList();
    populateAiControls();
    refreshAiOnboarding();
  }

  function setActiveModelFromChip(spec) {
    var idx = spec.indexOf(":");
    if (idx === -1) return;
    var pid = spec.slice(0, idx);
    var mi = parseInt(spec.slice(idx + 1), 10);
    var cfg = providerBy(pid);
    if (!cfg) return;
    var models = modelsFor(cfg);
    if (!models[mi]) return;
    cfg.activeModel = models[mi].id;
    persistAi();
    fillApList();
    if (aiCfg.wdAiMode === "manual" && aiCfg.wdAiModeId === cfg.id) fillModelSelect();
  }

  function handleAp(btn) {
    var act = btn.getAttribute("data-act");
    var cfg = providerBy(btn.getAttribute("data-pid"));
    if (!cfg) return;
    if (act === "test") apTest(cfg, btn);
    else if (act === "models") apDiscover(cfg, btn);
    else if (act === "delete") apDelete(cfg);
  }

  // --- chat controls ----------------------------------------------
  function populateAiControls() {
    var provSel = $("aiProvider"), modSel = $("aiModel"), modeSel = $("aiMode");
    if (!provSel) return;
    var mode = aiCfg.wdAiMode || "auto";
    modeSel.value = mode;
    var provs = (aiCfg.wdAiProviders || []).filter(hasKey);
    provSel.innerHTML = provs.length
      ? provs.map(function (p) { return '<option value="' + esc(p.id) + '">' + esc(p.label || p.provider) + "</option>"; }).join("")
      : '<option value="">No provider configured</option>';
    var isManual = mode === "manual";
    if (isManual) {
      if (aiCfg.wdAiModeId && providerBy(aiCfg.wdAiModeId)) provSel.value = aiCfg.wdAiModeId;
      else if (provs.length) { aiCfg.wdAiModeId = provs[0].id; provSel.value = provs[0].id; persistAi(); }
    }
    fillModelSelect();
    aiHint();
  }

  function fillModelSelect() {
    var modSel = $("aiModel"), provSel = $("aiProvider");
    if (!modSel || !provSel) return;
    var cfg = providerBy(provSel.value);
    var models = cfg ? modelsFor(cfg) : [];
    var am = models.length ? AICore.autoModel(cfg) : null;
    var sel = cfg && cfg.activeModel ? cfg.activeModel : (am && am.id) || (models[0] && models[0].id) || "";
    modSel.innerHTML = models.length
      ? models.map(function (m) {
        return '<option value="' + esc(m.id) + '"' + (m.id === sel ? " selected" : "") + ">"
          + esc(m.id) + (m.free ? " (free)" : "") + (m.contextLength ? " \u00B7 " + Math.round(m.contextLength / 1000) + "k" : "") + "</option>";
      }).join("")
      : '<option value="">No models</option>';
  }

  function aiHint() {
    var el = $("aiHint");
    if (!el) return;
    var mode = aiCfg.wdAiMode || "auto";
    var n = AICore.buildChain({ wdAiProviders: aiCfg.wdAiProviders, wdAiMode: mode, wdAiModeId: aiCfg.wdAiModeId }, mode).length;
    var txt = mode === "manual"
      ? "Manual mode uses only the selected provider."
      : mode === "free"
        ? "Free AI Mode asks for free-tier models only and refuses paid providers silently."
        : "Auto prefers free models when eligible and falls back across providers.";
    if (n === 0) txt += " No provider with a key is configured yet.";
    else txt += " Route ready: " + n + " provider(s) with keys.";
    el.textContent = txt;
  }

  // --- Before / After compare --------------------------------------
  function cmpSnapshot(d) {
    var p = (d && d.performance) || {}, s = (d && d.scores) || {}, j = (d && d.javascript) || {};
    var iss = WD.collectIssues(d || {});
    var sum = { critical: 0, warning: 0, good: 0 };
    iss.forEach(function (i) {
      if (i.level === "critical") sum.critical++;
      else if (i.level === "warning") sum.warning++;
      else if (i.level === "good") sum.good++;
    });
    return {
      score: typeof s.overall === "number" ? s.overall : null,
      lcp: p.largestContentfulPaint, cls: p.cumulativeLayoutShift, inp: p.interactionToNextPaint,
      ttfb: p.ttfb, load: p.loadTime,
      dom: d && d.dom && d.dom.totalElements, dups: d && d.dom && d.dom.duplicateIds ? d.dom.duplicateIds.length : 0,
      jerr: j.consoleErrors, cri: sum.critical, warn: sum.warning, good: sum.good
    };
  }

  function fmtV(v, type) {
    if (v === null || v === undefined) return "n/a";
    if (type === "ms") return v + "ms";
    if (type === "num") return v.toLocaleString();
    if (type === "score") return Math.round(v) + "/100";
    if (type === "cls") return (Math.round(v * 1000) / 1000).toFixed(3);
    return String(v);
  }

  function cmpBetter(row) {
    var a = row[1], b = row[2], pol = row[3];
    var out = { clsA: "", clsB: "" };
    if (a === null || a === undefined || b === null || b === undefined) return out;
    if (pol === "downGood") {
      if (b < a) out.clsB = "good";
      else if (b > a) out.clsB = "bad";
      if (a > b) out.clsA = "bad";
    } else {
      if (b > a) out.clsB = "good";
      else if (b < a) out.clsB = "bad";
    }
    return out;
  }

  function renderCmpTable() {
    var slot = $("aiCmpTable");
    if (!slot) return;
    if (!beforeCmp) { slot.innerHTML = ""; return; }
    var R = [];
    R.push(["Health score", "score", "upGood"]);
    R.push(["LCP", "ms", "downGood"]);
    R.push(["INP", "ms", "downGood"]);
    R.push(["CLS", "cls", "downGood"]);
    R.push(["TTFB", "ms", "downGood"]);
    R.push(["Page load", "ms", "downGood"]);
    R.push(["DOM elements", "num", "downGood"]);
    R.push(["Duplicate IDs", "num", "downGood"]);
    R.push(["JS console errors", "num", "downGood"]);
    R.push(["Critical issues", "num", "downGood"]);
    R.push(["Warnings", "num", "downGood"]);
    R.push(["Passing checks", "num", "upGood"]);
    var html = '<table class="cmp-table"><thead><tr><th>Metric</th><th>Before</th><th>After</th></tr></thead><tbody>';
    R.forEach(function (r) {
      var key = r[0], type = r[1];
      var a = beforeCmp[key], b = afterCmp ? afterCmp[key] : null;
      var cls = cmpBetter([key, a, b, r[2]]);
      html += "<tr><td class=\"metric\">" + key + '</td><td class="before">' + fmtV(a, type) + "</td>"
        + '<td class="after ' + cls.clsB + (b === null ? "" : "") + '">' + (afterCmp ? fmtV(b, type) : "\u2014") + "</td></tr>";
    });
    html += "</tbody></table>";
    slot.innerHTML = html;
  }

  function renderCmpCard() {
    var slot = $("aiCmpSlot");
    if (!slot) return;
    slot.innerHTML = '<div class="hint">Capture the current scan as "before", apply a fix on the live site, rescan, and compare real measured values.</div>'
      + '<div class="ap-actions" style="margin-top:6px">'
      + '<button class="ai-btn" type="button" data-ai="cmp-before">' + (beforeCmp ? "Before: recapture" : "Before: capture current") + "</button>"
      + (beforeCmp ? '<button class="ai-btn" type="button" data-ai="cmp-after">After: rescan &amp; compare</button>' : "")
      + "</div><div id=\"aiCmpTable\"></div>";
    renderCmpTable();
  }

  function cmpBefore() {
    beforeCmp = cmpSnapshot(dashData);
    afterCmp = null;
    aiStatus("Before snapshot captured from the current scan.");
    renderCmpCard();
  }

  function cmpAfter() {
    overlay("Scanning\u2026", "Re-running the analyzer for the After snapshot.");
    pickTarget(function (err, tabId) {
      if (err) { overlayErr(err); return; }
      runScanWith(tabId, function () {
        afterCmp = cmpSnapshot(dashData);
        renderCmpCard();
        aiStatus("After snapshot captured \u2014 compare table updated.");
      });
    });
  }

  // ------------------------------------------------------------
  // Render all + nav
  // ------------------------------------------------------------
  function buildNav(activeKey) {
    var nav = $("dashNav");
    var html = "";
    SECTIONS.forEach(function (s) {
      var list = s.cats.length ? sectionIssues(s.cats) : [];
      var w = list.filter(function (i) { return i.level === "warning"; }).length;
      var c = list.filter(function (i) { return i.level === "critical"; }).length;
      var n = c + w;
      var tot = navTotalFor(s.key);
      html += '<button class="dash-nav-item' + (s.key === activeKey ? " active" : "") + '" data-sec="' + s.key + '" type="button">'
        + sectIcon(s.key)
        + "<span>" + esc(s.label) + "</span>"
        + (tot > 0 ? '<span class="dash-nav-total" title="' + tot + ' items detected">' + (tot > 999 ? (tot / 1000).toFixed(1) + "k" : tot) + "</span>" : "")
        + (n > 0 ? '<span class="dash-nav-count' + (c > 0 ? " red" : "") + '" title="' + n + ' issue(s)">' + n + "</span>" : "")
        + "</button>";
    });
    html += '<button class="dash-nav-item' + (activeKey === "update" ? " active" : "") + '" data-sec="update" type="button">'
      + '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v10"/><path d="m7 10 5 5 5-5"/><path d="M4 19h16"/></svg>'
      + "<span>Update</span>"
      + (window.WDUpdate && window.WDUpdate.hasUpdate() ? '<span class="dash-nav-count red">1</span>' : "")
      + "</button>";
    nav.innerHTML = html;
  }

  function navTotalFor(key) {
    var d = dashData || {};
    var m = {
      dom: d.dom && d.dom.totalElements,
      links: d.links && d.links.total,
      images: d.images && d.images.total,
      forms: d.forms && d.forms.formCount,
      javascript: d.performance && d.performance.scriptTagCount,
      css: d.performance && d.performance.cssCount
    };
    return m[key] || 0;
  }

  function renderAll() {
    buildNav("overview");
    var p = dashData.page || {};
    $("dashSiteLine").innerHTML = (p.title ? "<b>" + esc(p.title) + "</b> \u00B7 " : "")
      + esc(dashUrl || p.url || "") + " \u00B7 scanned " + esc(formatTs(dashTs));
    renderOverview($("section-overview"));
    renderPerformance($("section-performance"));
    renderSectionWithExtra($("section-dom"), SECTIONS_BY_KEY.dom, domAuditBlock(dashData.dom));
    renderSection($("section-seo"), SECTIONS_BY_KEY.seo);
    renderSectionWithExtra($("section-accessibility"), SECTIONS_BY_KEY.accessibility, accessibilityDetailBlock(dashData.accessibility));
    renderDeviceSection($("section-devices"), SECTIONS_BY_KEY.devices);
    renderSection($("section-javascript"), SECTIONS_BY_KEY.javascript);
    renderSection($("section-css"), SECTIONS_BY_KEY.css);
    renderSectionWithExtra($("section-images"), SECTIONS_BY_KEY.images, imageDetailGallery(dashData.images));
    renderSectionWithExtra($("section-links"), SECTIONS_BY_KEY.links, linkDetailTable(dashData.links));
    renderSection($("section-forms"), SECTIONS_BY_KEY.forms);
    renderTechnology($("section-technology"));
    renderAi($("section-ai"));
    renderReports($("section-reports"));

    SECTIONS.forEach(function (s) {
      var el = $("section-" + s.key);
      if (el) el.classList.remove("active");
    });
    $("section-overview").classList.add("active");
  }

  function activate(key) {
    if (!SECTIONS_BY_KEY[key] && key !== "update") key = "overview";
    buildNav(key);
    var up = $("section-update");
    var panels = $("dashPanels");
    var app = $("dashApp");
    if (key === "update") {
      SECTIONS.forEach(function (s) {
        var el = $("section-" + s.key);
        if (el) el.classList.remove("active");
      });
      ["dashStateLoading", "dashStateNoScan", "dashStateError"].forEach(function (id) {
        var el = $(id); if (el) el.hidden = true;
      });
      if (panels) panels.hidden = true;
      if (up) { up.hidden = false; up.classList.add("active"); }
      if (window.WDUpdate) window.WDUpdate.check(false);
      return;
    }
    SECTIONS.forEach(function (s) {
      var el = $("section-" + s.key);
      if (el) el.classList.toggle("active", s.key === key);
    });
    if (up) { up.hidden = true; up.classList.remove("active"); }
    var stn = app ? app.getAttribute("data-state") : "data";
    if (!dashData || stn === "noscan" || stn === "loading" || stn === "error") {
      if (panels) panels.hidden = true;
      $("dashStateLoading").hidden = stn !== "loading";
      $("dashStateNoScan").hidden = stn !== "noscan";
      $("dashStateError").hidden = stn !== "error";
    } else {
      if (panels) panels.hidden = false;
      ["dashStateLoading", "dashStateNoScan", "dashStateError"].forEach(function (id) {
        var el = $(id); if (el) el.hidden = true;
      });
    }
    if (key === "devices") maybeAutoResponsiveAudit();
  }

  // ------------------------------------------------------------
  // Events
  // ------------------------------------------------------------
  function bind() {
    $("dashNav").addEventListener("click", function (e) {
      var btn = e.target && e.target.closest ? e.target.closest(".dash-nav-item") : null;
      if (btn) activate(btn.getAttribute("data-sec"));
    });
    $("dashRescan").addEventListener("click", function () {
      if (!dashData) {
        overlay("Scanning\u2026", "Injecting the analyzer into the active tab.");
        runScanNoData();
      } else {
        runScan();
      }
    });
    $("dashOpenWeb").addEventListener("click", function () { runScanNoData(); });
    $("dashRetry").addEventListener("click", loadLatest);

    $("dashPanels").addEventListener("click", function (e) {
      var headEl = e.target && e.target.closest ? e.target.closest(".dash-issue-head") : null;
      if (!headEl) {
        var rep = e.target && e.target.closest ? e.target.closest("[data-report]") : null;
        if (rep) {
          var kind = rep.getAttribute("data-report");
          if (kind === "report-csv") exportCsv();
          else if (kind === "report-json") exportJson();
        }
        return;
      }
      var bodyEl = headEl.parentElement.querySelector(".dash-issue-body");
      var isOpen = headEl.getAttribute("aria-expanded") === "true";
      headEl.setAttribute("aria-expanded", isOpen ? "false" : "true");
      if (bodyEl) bodyEl.hidden = isOpen;
    });

    // Keyboard activation for expandable issue heads.
    $("dashPanels").addEventListener("keydown", function (e) {
      if (e.key !== "Enter" && e.key !== " ") return;
      var headEl = e.target && e.target.closest ? e.target.closest(".dash-issue-head") : null;
      if (headEl) { e.preventDefault(); headEl.click(); }
    });

    // Image gallery downloads (tiles are re-created on every section render,
    // so the wiring is delegated on the panels container).
    $("dashPanels").addEventListener("click", function (e) {
      var t = e.target;
      if (!t || !t.closest) return;
      var all = t.closest("[data-img-dl-all]");
      if (all) { e.preventDefault(); downloadAllImages(all); return; }
      var one = t.closest("[data-img-dl]");
      if (one) { e.preventDefault(); downloadImageAt(parseInt(one.getAttribute("data-img-dl"), 10) || 0); return; }
    });

    // DOM section: developer live tools (locate / console report / Elementor).
    $("section-dom").addEventListener("click", function (e) {
      var btn = e.target && e.target.closest ? e.target.closest("[data-dom-act]") : null;
      if (!btn) return;
      var act = btn.getAttribute("data-dom-act");
      var st = document.getElementById("domToolStatus");
      var say = function (msg, cls) {
        if (!st) return;
        st.className = "dom-tool-status" + (cls ? " " + cls : "");
        st.textContent = msg || "";
      };
      if (act === "locate") {
        say("Locating\u2026");
        locateOnTarget(btn.getAttribute("data-sel"), function (ok, err) {
          if (ok && ok.success) say("Highlighted on the page.", "ok");
          else say((ok && ok.error) || err || "Could not locate that element.", "err");
        });
        return;
      }
      if (act === "console") {
        say("Sending findings to the page console\u2026");
        deviceToolMsg({ action: "consoleReport" }, function (res, err) {
          if (err || !res || !res.success) say(err || "Cannot reach this page \u2014 run a scan first.", "err");
          else say("Logged \u2014 open the page DevTools console.", "ok");
        });
        return;
      }
      if (act === "elementor") {
        say("Re-inspecting Elementor on the live page\u2026");
        deviceToolMsg({ action: "analyzeelementor" }, function (res, err) {
          if (err || !res || !res.success) say(err || "Elementor inspection needs a reachable page.", "err");
          else say("Live Elementor report ready \u2014 open the Elementor tool in the popup.", "ok");
        });
      }
    });

    // Devices: Responsive Breakpoint Audit buttons (the audit card is
    // re-created on every section render, so the wiring is delegated on the
    // section container rather than attached per-render).
    $("section-devices").addEventListener("click", function (e) {
      var t = e.target && e.target.closest ? e.target.closest("[id]") : (e.target || null);
      if (!t || !t.id) return;
      if (t.id === "btnResponsiveScan") { runResponsiveAudit(true); return; }
      if (t.id === "btnAutoInspect") { runAutoInspect(); return; }
      if (t.id === "btnResponsiveFixApply") { applySuggestedFixes(); return; }
      if (t.id === "btnResponsiveFixRestore") { restoreSuggestedFixes(); return; }
    });

    // Delegated AI actions (chat, provider management, debug buttons).
    $("dashPanels").addEventListener("click", aiDelegateClick);

    // Enter to send in the AI input (Shift+Enter inserts a newline).
    $("dashPanels").addEventListener("keydown", function (e) {
      if (e.key !== "Enter" || e.shiftKey || !e.target || e.target.id !== "aiInput") return;
      e.preventDefault();
      handleAi("send");
    });

    // AI select controls.
    $("dashPanels").addEventListener("change", aiDelegateChange);

    // Broken image thumbnails — swap in a placeholder when a preview fails to
    // load (error events do not bubble, so this listens on the capture phase).
    $("dashPanels").addEventListener("error", function (e) {
      var t = e.target;
      if (t && t.tagName === "IMG" && t.classList.contains("wd-thumb")) {
        var fb = document.createElement("span");
        fb.className = "wd-thumb-fallback";
        fb.textContent = "\u26A0 broken";
        t.parentNode.replaceChild(fb, t);
      }
    }, true);
  }

  function aiDelegateClick(e) {
    var t = e.target;
    if (!t || !t.closest) return;
    var ai = t.closest("[data-ai]");
    if (ai) { e.preventDefault(); handleAi(ai.getAttribute("data-ai")); return; }
    var mp = t.closest("[data-mpick]");
    if (mp) { e.preventDefault(); setActiveModelFromChip(mp.getAttribute("data-mpick")); return; }
    var ap = t.closest("[data-act]");
    if (ap) { e.preventDefault(); handleAp(ap); }
  }

  function aiDelegateChange(e) {
    var t = e.target;
    if (!t || !t.getAttribute) return;
    var act = t.getAttribute("data-ai-change");
    if (act === "mode") {
      if (!aiCfg) return;
      aiCfg.wdAiMode = t.value;
      if (t.value === "manual" && $("aiProvider") && $("aiProvider").value && !providerBy($("aiProvider").value)) {
        var provs = (aiCfg.wdAiProviders || []).filter(hasKey);
        if (provs.length) { aiCfg.wdAiModeId = provs[0].id; $("aiProvider").value = provs[0].id; }
      }
      persistAi();
      fillModelSelect();
      aiHint();
      aiStatus("");
    } else if (act === "provider") {
      if (!aiCfg) return;
      aiCfg.wdAiModeId = t.value;
      persistAi();
      fillModelSelect();
      aiStatus("");
    } else if (act === "model") {
      if (!aiCfg) return;
      var pc = providerBy($("aiProvider") && $("aiProvider").value);
      if (pc) { pc.activeModel = t.value; persistAi(); }
    } else if (act === "task") {
      aiCtxPreview();
    } else if (act === "apkind") {
      toggleBaseUrlRow(t.value);
    }
    var sel = t.getAttribute("data-apmodel");
    if (sel) {
      var c2 = providerBy(sel);
      if (c2) { c2.activeModel = t.value; persistAi(); }
    }
  }

  function handleAi(act) {
    if (act === "send") {
      var inp = $("aiInput");
      if (!inp) return;
      var v = String(inp.value || "").trim();
      if (!v) return;
      inp.value = "";
      sendAi(v);
    } else if (act === "stop") {
      stopAi();
    } else if (act === "regen" || act === "retry") {
      resendLast();
    } else if (act === "copy") {
      copyLast();
    } else if (act === "clear") {
      clearChat();
    } else if (act === "stick") {
      aiStick(true);
    } else if (act === "ap-save") {
      saveProviderFromForm();
    } else if (act === "ow-save") {
      handleQuickKey();
    } else if (act === "cmp-before") {
      cmpBefore();
    } else if (act === "cmp-after") {
      cmpAfter();
    }
  }

  function runScanNoData() {
    overlay("Scanning current tab\u2026", "Web Doctor will analyze the active website now.");
    var self = chrome.runtime.getURL("dashboard.html");
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
      var tab = tabs && tabs[0];
      if (!tab || !tab.url || tab.url.indexOf(self) === 0 || !/^https?:/i.test(tab.url || "")) {
        pickActive(function (err, tabId) {
          if (err) { overlayErr(err); return; }
          runScanWith(tabId);
        });
        return;
      }
      runScanWith(tab.id);
    });
  }

  function runScanWith(tabId, done) {
    chrome.runtime.sendMessage({ action: "analyzeTab", tabId: tabId }, function (res) {
      if (chrome.runtime.lastError) { overlayErr(chrome.runtime.lastError.message); return; }
      if (!res || !res.success) {
        overlayErr((res && res.error) || "The analyzer did not respond. Reload the page and try again.");
        return;
      }
      var data = res.data;
      var ts = Date.now();
      var url = (data && data.page && data.page.url) || "";
      persistScan(data, ts, url, tabId);
      dashTabId = tabId;
      dashUrl = url;
      dashTs = ts;
      enterData(data);
      if (done) done();
    });
  }

  // ------------------------------------------------------------
  // Crawl progress
  // ------------------------------------------------------------
  // The crawler keeps streaming progress from the background worker, so the
  // dashboard needs a message listener of its own (it had none before the
  // Audit tab moved here). Same messages the popup used to handle.
  function handleCrawlProgress(msg) {
    var cst = document.getElementById("crawlStatus");
    if (!cst) return;
    // Drop progress from a run this UI already replaced or stopped. Messages
    // without a token (older workers) are still honored.
    if (msg && msg.runToken !== undefined && crawlState.runToken !== undefined && msg.runToken !== crawlState.runToken) return;
    var text = "";
    if (msg.phase === "page") {
      text = "Scanning page " + ((msg.done || 0) + 1) + " of " + (msg.total || "?") + " \u2014 "
        + (msg.currentTitle || msg.currentUrl || "Loading\u2026")
        + (msg.failed ? " (" + msg.failed + " unreachable)" : "");
    } else if (msg.phase === "probe") {
      text = "Verifying " + ((msg.extra && msg.extra.links) || 0) + " links and "
        + ((msg.extra && msg.extra.images) || 0) + " media URLs\u2026";
    } else if (msg.phase === "done") {
      text = "Scan complete \u2014 building the report\u2026";
    } else if (msg.phase === "status" && msg.text) {
      text = msg.text;
    } else if (msg.phase === "start") {
      text = "Scan started \u2014 loading the site\u2026";
    }
    if (!text) return;
    cst.className = "audit-status visible";
    cst.textContent = text;
  }

  var dashSideBtn = document.getElementById("dashSidePanelBtn");
  if (dashSideBtn) {
    dashSideBtn.addEventListener("click", function () {
      try {
        if (chrome.sidePanel && chrome.sidePanel.open) {
          chrome.windows.getCurrent(function (win) {
            try {
              // Pin the side panel to the scan context of the page this
              // dashboard was opened for, so it loads that page's data.
              chrome.storage.session.set({ wdSidePanelTabId: dashTabId });
              chrome.sidePanel.setOptions({ path: "dashboard.html" + (location.hash || ""), enabled: true });
              chrome.sidePanel.open({ windowId: win && win.id });
            } catch (e) {}
          });
          return;
        }
      } catch (e) {}
    });
  }

  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "session") return;
      if (changes.wdScan || changes.wdScanByTab || changes.wdSidePanelTabId) loadLatest();
    });
    chrome.tabs.onActivated.addListener(function () { loadLatest(); });
    chrome.windows.onFocusChanged.addListener(function (wid) {
      if (wid !== chrome.windows.WINDOW_ID_NONE) loadLatest();
    });
  } catch (e) {}

  try {
    chrome.runtime.onMessage.addListener(handleCrawlProgress);
  } catch (e) {}

  // ------------------------------------------------------------
  // Init
  // ------------------------------------------------------------
  try {
    chrome.storage.local.get("wdTheme", function (o) {
      document.documentElement.setAttribute("data-theme", o.wdTheme || "dark");
    });
  } catch (e) {}

  try {
    var v = chrome.runtime.getManifest().version;
    if (v) $("dashVersion").textContent = "v" + v;
    else $("dashVersion").hidden = true;
  } catch (e) { $("dashVersion").hidden = true; }

  // The header pill (window.WDUpdate handled by dashboard-update.js) just routes
  // the user to the Update section; the tab owns checking, download and install.
  $("dashUpdate").addEventListener("click", function () {
    var b = document.querySelector('#dashNav [data-sec="update"]');
    if (b) b.click();
    var m = document.querySelector(".dash-main");
    if (m) m.scrollTop = 0;
  });

  bind();
  window.addEventListener("hashchange", applyHash);
  $("dashApp").classList.remove("hidden");
  loadLatest();
})();