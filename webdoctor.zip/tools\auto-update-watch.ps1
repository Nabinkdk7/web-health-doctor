<#
Website Doctor auto-update watcher.
Polls GitHub for a newer tag, downloads webdoctor.zip, extracts it over the
unpacked extension folder (with a backup), and notifies you via Windows.
Run:  powershell -ExecutionPolicy Bypass -File tools\auto-update-watch.ps1
Keep it running in a terminal (or add it to your Startup folder).
#>
param(
  [int]$IntervalMinutes = 10,
  [switch]$Once
)

$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
$stateFile = Join-Path $root ".last-update-tag"
$logFile = Join-Path $root "auto-update.log"

function Log($msg) {
  $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $msg
  Add-Content -Path $logFile -Value $line
  Write-Host $line
}

function Toast($title, $msg) {
  try {
    Add-Type -AssemblyName System.Windows.Forms
    $n = New-Object System.Windows.Forms.NotifyIcon
    $n.Icon = [System.Drawing.SystemIcons]::Information
    $n.BalloonTipTitle = $title
    $n.BalloonTipText = $msg
    $n.Visible = $true
    $n.ShowBalloonTip(8000)
    Start-Sleep -Milliseconds 9000
    $n.Dispose()
  } catch {
    Log ("TOAST: " + $title + " - " + $msg)
  }
}

function Get-LatestTag {
  $url = "https://api.github.com/repos/Nabinkdk7/web-health-doctor/tags?per_page=5"
  $res = Invoke-RestMethod -Uri $url -Headers @{ "User-Agent" = "website-doctor-updater" } -TimeoutSec 30
  $tag = ($res | Where-Object { $_.name -match '^v\d+\.\d+\.\d+$' } | Select-Object -First 1).name
  if (-not $tag) { throw "No version tag found on GitHub." }
  return $tag
}

function SemVerGt($a, $b) {
  $pa = ($a -replace '^v','').Split('.') | ForEach-Object {[int]$_}
  $pb = ($b -replace '^v','').Split('.') | ForEach-Object {[int]$_}
  for ($i=0; $i -lt 3; $i++) { if ($pa[$i] -gt $pb[$i]) { return $true } if ($pa[$i] -lt $pb[$i]) { return $false } }
  return $false
}

do {
  try {
    $latest = Get-LatestTag
    $applied = ""; if (Test-Path $stateFile) { $applied = (Get-Content $stateFile -Raw).Trim() }
    if ($applied -eq "") {
      # First run: just record current tag, do not overwrite files.
      Set-Content -Path $stateFile -Value $latest
      Log ("Recorded current version {0}. Future updates will be applied automatically." -f $latest)
    } elseif (SemVerGt $latest $applied) {
      Log ("New version {0} found (installed: {1}). Downloading..." -f $latest, $applied)
      $zip = Join-Path $env:TEMP ("webdoctor-{0}.zip" -f $latest)
      Invoke-WebRequest -Uri "https://github.com/Nabinkdk7/web-health-doctor/raw/main/webdoctor.zip" -OutFile $zip -TimeoutSec 120

      $backupParent = Join-Path (Split-Path $root -Parent) "backups"
      New-Item -ItemType Directory -Force -Path $backupParent | Out-Null
      $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
      $backup = Join-Path $backupParent ("auto-backup-{0}" -f $stamp)
      Copy-Item -Path $root -Destination $backup -Recurse -Force
      Log ("Backup saved to {0}" -f $backup)

      Expand-Archive -Path $zip -DestinationPath $root -Force
      Set-Content -Path $stateFile -Value $latest
      Log ("Updated extension folder to {0}." -f $latest)

      Toast "Website Doctor" ("Updated to {0}. Reload the extension at chrome://extensions to finish." -f $latest)
      Start-Process "chrome://extensions"
    } else {
      Log ("No new version. Installed {0}, latest {1}." -f $applied, $latest)
    }
  } catch {
    Log ("ERROR: " + $_.Exception.Message)
  }

  if ($Once) { break }
  Start-Sleep -Seconds ($IntervalMinutes * 60)
} while ($true)
