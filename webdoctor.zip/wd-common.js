/*!
 * WEB DOCTOR 2 — shared data helpers
 * Consumed by popup.js AND dashboard.js so both surfaces always render the
 * exact same normalized issues, categories, CWV verdicts and detail facts from
 * the same real scan data (the analyze() result captured by content.js). Never
 * invent values here — every number shown comes from the page scan.
 */
(function () {
  var WD = {};

  // ------------------------------------------------------------
  // text / byte helpers
  // ------------------------------------------------------------
  function escapeHtml(str) {
    return String(str === undefined || str === null ? "" : str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  function formatBytes(bytes) {
    if (bytes === null || bytes === undefined || isNaN(bytes)) return "n/a";
    if (bytes < 1024) return bytes + " B";
    var units = ["KB", "MB", "GB", "TB"];
    var v = bytes;
    var u = -1;
    do { v /= 1024; u++; } while (v >= 1024 && u < units.length - 1);
    return v.toFixed(v >= 10 ? 0 : 1) + " " + units[u];
  }

  // ------------------------------------------------------------
  // categories / icons / severity
  // ------------------------------------------------------------
  var WD_CAT_LABEL = {
    seo: "SEO", performance: "Performance", accessibility: "Accessibility",
    responsive: "Responsive", dom: "DOM", hidden: "Hidden content",
    javascript: "JavaScript", css: "CSS", images: "Images", links: "Links",
    forms: "Forms", security: "Security", elementor: "WordPress / Elementor",
    technology: "Technology", structure: "Structure", typography: "Typography",
    cwv: "Core Web Vitals", other: "Other"
  };

  var CATEGORY_ORDER = ["seo", "performance", "accessibility", "responsive", "dom", "hidden", "javascript", "css", "images", "links", "forms", "security", "elementor", "technology", "structure", "typography", "cwv", "other"];

  var WD_ICON_STROKE = ' fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"';
  var WD_CAT_ICONS = {
    overview: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><rect x="3" y="3" width="7.5" height="7.5" rx="1.5"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.5"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.5"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="1.5"/></svg>',
    seo: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>',
    performance: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><path d="m13 2-9 12h7l-1 8 9-12h-7l1-8z"/></svg>',
    accessibility: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><circle cx="12" cy="4.8" r="1.8"/><path d="M4 9.5c2.7.7 5.3 1 8 1s5.3-.3 8-1"/><path d="M12 10.5V15"/><path d="m12 15-3.5 6"/><path d="m12 15 3.5 6"/></svg>',
    responsive: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><rect x="2" y="3.5" width="20" height="14" rx="2"/><path d="M8 21h8"/><path d="M12 17.5V21"/></svg>',
    devices: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><rect x="2" y="4" width="13" height="10" rx="2"/><path d="M5.5 18h6"/><rect x="17" y="9" width="5" height="11" rx="1.5"/></svg>',
    dom: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><path d="m12 2 8 4-8 4-8-4 8-4z"/><path d="m4 10 8 4 8-4"/><path d="m4 15 8 4 8-4"/></svg>',
    javascript: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><path d="M8 4c-2.2 0-3 1.2-3 3v2.2c0 1.4-1 2.3-2 2.8 1 .5 2 1.4 2 2.8V17c0 1.8.8 3 3 3"/><path d="M16 4c2.2 0 3 1.2 3 3v2.2c0 1.4 1 2.3 2 2.8-1 .5-2 1.4-2 2.8V17c0 1.8-.8 3-3 3"/></svg>',
    css: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><path d="m8 5-5.5 7L8 19"/><path d="m16 5 5.5 7L16 19"/></svg>',
    images: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5.5-5L6 21"/></svg>',
    links: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg>',
    forms: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/><path d="M7 14h4"/><path d="M7 17h2"/></svg>',
    ai: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><path d="M12 3l1.7 4.6 4.3 1.7-4.3 1.7L12 15.6l-1.7-4.6L6 9.3l4.3-1.7L12 3z"/><path d="M19 15l.9 2.1 2.1.9-2.1.9L19 21l-.9-2.1-2.1-.9 2.1-.9L19 15z"/></svg>',
    reports: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><path d="M6 2.5h8L18.5 7v14.5H6z"/><path d="M13.5 2.5V7H18"/><path d="M9 12.5h6"/><path d="M9 16.5h6"/></svg>',
    security: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3z"/><path d="m9 12 2 2 4-4"/></svg>',
    elementor: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><rect x="2.5" y="4" width="19" height="16" rx="2"/><path d="M6 8h5.5"/><path d="M6 12h5.5"/><path d="M6 16h5.5"/><path d="M14.5 8H18"/><path d="M14.5 12H18"/><path d="M14.5 16H18"/></svg>',
    technology: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><rect x="3" y="7" width="18" height="10" rx="2"/><path d="M3 12h18"/><path d="M7 4h2"/><path d="M11 4h2"/><path d="M15 4h2"/></svg>',
    structure: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><path d="M3 6h18"/><path d="M3 6v12h18V6"/><path d="M3 12h18"/></svg>',
    typography: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><path d="M4 7V5h16v2"/><path d="M12 5v14"/><path d="M9 19h6"/></svg>',
    cwv: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><path d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z"/><path d="M12 8v4l3 2"/></svg>',
    other: '<svg viewBox="0 0 24 24"' + WD_ICON_STROKE + '><rect x="3" y="3" width="8" height="8" rx="1"/><rect x="13" y="3" width="8" height="8" rx="1"/><rect x="3" y="13" width="8" height="8" rx="1"/><rect x="13" y="13" width="8" height="8" rx="1"/></svg>'
  };

  var WD_SEV_ICON = {
    critical: '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4 21 20H3L12 4z"/><path d="M12 10v4"/><path d="M12 17.4h.01"/></svg>',
    warning: '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5 21 19H3L12 5z"/><path d="M12 10v4"/></svg>',
    good: '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>',
    info: '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><path d="M12 8h.01"/></svg>'
  };
  var WD_CHEV_DOWN = '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>';
  var WD_CHEV_UP = '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg>';

  var WD_CATEGORY_RULES = [
    ["cwv", /\b(lcp|inp|cls|core web vital|vital)\b/i],
    ["seo", /(title|meta description|canonical|noindex|social metadata|og:image|og:title|meta description)/i],
    ["accessibility", /(alt text|alt coverage|labels|accessible name|aria|contrast|skip link|iframe|screen reader|navigation)/i],
    ["structure", /(landmark|header|footer|main element|main landmark|language|h1 heading)/i],
    ["responsive", /(responsive|viewport|overflow|fixed-width|offscreen|mobile|touch|tap target)/i],
    ["elementor", /elementor|wp-|wordpress/i],
    ["typography", /typography|font|text/i],
    ["security", /https|ssl|security|mixed content|certificate|referrer|cookie/i],
    ["forms", /form|input|field/i],
    ["links", /link|href|broken|fragment|404/i],
    ["images", /image|img|thumbnail/i],
    ["javascript", /javascript|script|js payload/i],
    ["css", /css|stylesheet|inline style/i],
    ["dom", /dom|element|nesting|container|id|wrapper/i],
    ["performance", /load|paint|resource|payload|weight|large|script tag|third-party|cache/i],
    ["technology", /technology|stack|cms|framework|platform|library/i]
  ];

  function wdCategoryOf(title) {
    if (!title) return "other";
    for (var i = 0; i < WD_CATEGORY_RULES.length; i++) {
      if (WD_CATEGORY_RULES[i][1].test(title)) return WD_CATEGORY_RULES[i][0];
    }
    return "other";
  }

  var WD_WHY = {
    seo: "Search engines use these signals to rank and describe your page; missing or broken metadata makes the page less visible and reduces click-through.",
    performance: "Speed keeps visitors engaged and is a Core Web Vitals / ranking factor; heavy resources delay first paint and interaction.",
    accessibility: "Accessible pages work for everyone - screen readers, keyboard users, and search engines all rely on these attributes.",
    responsive: "Responsive design keeps content readable on every screen; overflow and fixed widths break the layout on smaller devices.",
    dom: "Every element the browser builds costs memory and render time; deep or duplicated markup slows parsing and complicates styling.",
    hidden: "Sections kept from visitors may hide payment notes, disclaimers, or duplicate content that hurt trust and SEO.",
    javascript: "Scripts add interactivity, but render-blocking or oversized script payloads delay first paint and user interactions.",
    css: "Stylesheets shape the page; inline styles resist caching and make the design harder to review and maintain.",
    images: "Images usually dominate page weight; missing alt text also hides their meaning from assistive technology and search engines.",
    links: "Links connect content; broken or placeholder targets frustrate users and waste crawl budget.",
    forms: "Forms capture input; unlabeled or unsemantic fields are hard or impossible for assistive-technology users to complete.",
    security: "A secure connection protects visitors and is expected by browsers and search engines.",
    elementor: "WordPress and Elementor drive the structure; deep container nesting creates heavy, harder-to-maintain markup.",
    technology: "Knowing the platform and libraries in use helps judge maintenance effort, performance risk, and upgrade path.",
    structure: "Semantic landmarks and language declarations help browsers, search engines, and assistive tools interpret the page.",
    typography: "Typeface choices and font loads directly affect readability and load performance.",
    cwv: "Core Web Vitals (LCP, INP, CLS) measure real-world user experience and are a ranking factor in many searches.",
    other: "No dedicated category matches; even small issues can affect how the page feels and performs."
  };

  var WD_TECH = {
    seo: "<head> metadata: <title>, meta description, canonical, Open Graph",
    performance: "Resource Timing / Performance Timeline entries captured from the analyzed tab",
    accessibility: "Document snapshot: alt attributes, form labels, ARIA names, landmark elements",
    responsive: "viewport meta plus document scrollWidth vs clientWidth measurements",
    dom: "Document Object Model census: element counts, nesting depth, ids, inline styles",
    hidden: "DEV-MOD Hidden Content scanner: display:none / visibility:hidden / opacity:0 / zero-height closures",
    javascript: "<script> source analysis: external count, inline bytes, defer/async",
    css: "document.styleSheets, <style>/link stylesheets, and style attributes on elements",
    images: "<img> elements: count, alt attributes, intrinsic dimensions, lazy-loading",
    links: "<a> elements: href targets, external links, fragments, javascript: placeholders",
    forms: "<form> elements: inputs, fields, and label associations",
    security: "tab URL protocol plus on-page security markers (HTTPS, mixed content)",
    elementor: "Elementor markup: data-element_type containers, nesting depth, widget counts",
    technology: "window globals and markup signatures detected on the page",
    structure: "semantic elements (<header>, <main>, <footer>) and the html lang declaration",
    typography: "computed font stack and font resources on the page",
    cwv: "PerformanceTimeline: LCP, INP (long tasks), CLS estimates",
    other: "general page analysis"
  };

  // ------------------------------------------------------------
  // issue normalization (single source for popup AND dashboard)
  // ------------------------------------------------------------
  function itemsOf(source, key) {
    return (source && source.items && source.items[key]) || [];
  }

  function mergeItems(issue, items) {
    if (!issue.items) issue.items = [];
    (items || []).forEach(function (it) {
      if (issue.items.length >= 8) return;
      issue.items.push(it);
    });
  }

  // Attach the real per-element evidence the content.js analyzers captured so
  // the WHAT / WHERE / EVIDENCE detail view can show exact selectors + snippets.
  function attachEvidence(issues, data) {
    var idx = {};
    issues.forEach(function (i) {
      if (idx[i.title] === undefined) idx[i.title] = [];
      idx[i.title].push(i);
    });
    function grab(title, items) {
      (idx[title] || []).forEach(function (issue) { mergeItems(issue, items); });
    }
    if (data.accessibility) {
      grab("Missing image ALT text", itemsOf(data.accessibility, "missingAlt"));
      grab("Form inputs without labels", itemsOf(data.accessibility, "inputsNoLabel"));
      grab("Buttons without accessible names", itemsOf(data.accessibility, "buttonsNoName"));
      grab("Links without accessible text", itemsOf(data.accessibility, "linksNoText"));
      grab("Iframes without titles", itemsOf(data.accessibility, "iframesNoTitle"));
      grab("Navigation without accessible name", itemsOf(data.accessibility, "navsNoName"));
    }
    if (data.headings && data.headings.emptyHeadingItems) {
      grab("Empty headings", data.headings.emptyHeadingItems);
    }
    if (data.links && data.links.items) {
      grab("Broken link targets", (data.links.items.placeholder || []).concat(data.links.items.fragment || []));
    }
    if (data.dom && data.dom.duplicateIds) {
      var dupItems = [];
      data.dom.duplicateIds.forEach(function (d) {
        (d.items || []).forEach(function (it) {
          if (dupItems.length < 8) dupItems.push(it);
        });
      });
      grab("Duplicate IDs", dupItems);
    }
    return issues;
  }

  function collectIssues(data) {
    if (!data) return [];
    // Normalize partial scans: a detector that failed on the page leaves its
    // section as null, so default each to a harmless empty shape (the scan
    // notice reports the real reason in the UI).
    data.page = data.page || {};
    data.dom = data.dom || {};
    if (!data.dom.duplicateIds) data.dom.duplicateIds = [];
    if (!data.dom.elementor) data.dom.elementor = {};
    data.performance = data.performance || { largeResources: [] };
    if (!data.performance.largeResources) data.performance.largeResources = [];
    data.seo = data.seo || {};
    data.headings = data.headings || { counts: {}, headings: [], issues: [] };
    if (!data.headings.counts) data.headings.counts = {};
    if (!data.headings.headings) data.headings.headings = [];
    if (!data.headings.issues) data.headings.issues = [];
    data.structure = data.structure || {};
    data.technology = data.technology || { groups: {} };
    data.accessibility = data.accessibility || {};
    data.forms = data.forms || {};
    data.links = data.links || {};
    data.brokenLinks = data.brokenLinks || {};
    data.images = data.images || {};
    data.responsive = data.responsive || {};
    var issues = [];

    // DOM issues — every recommendation names the measured value and the
    // concrete next step, so it reads as a fix ticket, not a slogan.
    if (data.dom.totalElements > 1500) {
      var domCut = data.dom.totalElements - 1500;
      var domHint = data.dom.largestParent ? " \u2014 start with repeated <" + data.dom.largestParent + "> blocks and duplicated sections" : "";
      issues.push({
        level: data.dom.totalElements > 3000 ? "critical" : "warning",
        title: "Excessive DOM size",
        desc: data.dom.totalElements.toLocaleString() + " DOM elements detected.",
        rec: "Cut about " + domCut.toLocaleString() + " elements to get under ~1,500" + domHint + "."
      });
    }
    if (data.dom.maxDepth > 15) {
      issues.push({
        level: data.dom.maxDepth > 20 ? "critical" : "warning",
        title: "Deep DOM nesting",
        desc: "Maximum nesting depth: " + data.dom.maxDepth + ".",
        rec: "Restructure the subtree below depth ~10 so the maximum of " + data.dom.maxDepth + " drops under 15 \u2014 prefer flat CSS Grid/Flexbox layouts over nested wrappers."
      });
    }
    if (data.dom.duplicateIds.length > 0) {
      issues.push({
        level: "critical",
        title: "Duplicate IDs",
        desc: data.dom.duplicateIds.length + " duplicate ID(s) found.",
        rec: "Rename or scope the " + data.dom.duplicateIds.length + " duplicated id(s) so each appears exactly once \u2014 duplicates break getElementById, label association, and assistive tech (see Affected elements)."
      });
    }
    if (data.dom.excessiveNestingCount > 5) {
      issues.push({
        level: "warning",
        title: "Excessive nesting",
        desc: data.dom.excessiveNestingCount + " elements with excessive nesting depth.",
        rec: "Remove the redundant parent containers around the " + data.dom.excessiveNestingCount + " deeply nested elements."
      });
    }
    if (data.dom.emptyElements > 30) {
      issues.push({
        level: "warning",
        title: "Many empty elements",
        desc: data.dom.emptyElements + " empty elements found.",
        rec: "Delete the " + data.dom.emptyElements + " empty elements (or fill them) to shrink parse and render work."
      });
    }
    if (data.dom.maxContainerNesting >= 8 || data.dom.nestedContainerCount > 300) {
      issues.push({
        level: "warning",
        title: "Deeply nested layout containers",
        desc: "Containers nest up to " + data.dom.maxContainerNesting +
          " levels deep (" + data.dom.nestedContainerCount.toLocaleString() + " nested containers).",
        rec: "Bring nesting below 8 levels (now " + data.dom.maxContainerNesting + ") and split the " + data.dom.nestedContainerCount.toLocaleString() + " nested containers into flatter sections \u2014 every level adds markup the browser must render and style."
      });
    }
    if (data.dom.elementor && data.dom.elementor.detected &&
        data.dom.elementor.excessive && data.dom.elementor.excessive.level !== "good") {
      var elExtra = "";
      try {
        var elc = data.dom.elementor.containers, elm = data.dom.elementor.maxNesting;
        if (elc || elm) elExtra = " (page has " + (elc || "?") + " containers at up to depth " + (elm || "?") + ")";
      } catch (e) {}
      issues.push({
        level: data.dom.elementor.excessive.level === "critical" ? "critical" : "warning",
        title: "Excessive Elementor container usage",
        desc: data.dom.elementor.excessive.message,
        rec: "Replace deep inner sections/columns with lightweight wrappers and reuse templates" + elExtra + "."
      });
    }
    if ((data.dom.inlineStyleCount || 0) > 150) {
      issues.push({
        level: data.dom.inlineStyleCount > 400 ? "critical" : "warning",
        title: "Heavy inline style usage",
        desc: data.dom.inlineStyleCount.toLocaleString() + " elements use inline style attributes.",
        rec: "Extract the " + data.dom.inlineStyleCount.toLocaleString() + " inline style attributes into a cached stylesheet \u2014 start with the most repeated declarations."
      });
    }
    var brokenLinkCount = (data.brokenLinks && data.brokenLinks.counts && data.brokenLinks.counts.broken) || 0;
    if (brokenLinkCount > 0) {
      issues.push({
        level: brokenLinkCount > 5 ? "critical" : "warning",
        title: "Broken link targets",
        desc: brokenLinkCount + " link(s) point to a \u201C#\u201D or javascript: placeholder, or to a fragment with no matching element on this page.",
        rec: "Fix the " + brokenLinkCount + " placeholder/fragment links (see Affected elements), then re-run the Broken Links check to verify."
      });
    }

    // Performance issues
    if (data.performance.loadTime !== null && data.performance.loadTime > 3000) {
      var loadSecs = (data.performance.loadTime / 1000).toFixed(1);
      var bigRes = data.performance.largeResources.length;
      issues.push({
        level: data.performance.loadTime > 5000 ? "critical" : "warning",
        title: "Slow page load",
        desc: "Load time: " + loadSecs + "s.",
        rec: "Bring load under ~3s from " + loadSecs + "s" + (bigRes ? ": compress the " + bigRes + " resource(s) over 200KB, defer non-critical JS, and enable caching" : " by cutting server response time and deferring non-critical JS") + "."
      });
    }
    if (data.performance.firstContentfulPaint !== null && data.performance.firstContentfulPaint > 1800) {
      var fcpSecs = (data.performance.firstContentfulPaint / 1000).toFixed(1);
      issues.push({
        level: data.performance.firstContentfulPaint > 3000 ? "critical" : "warning",
        title: "Slow First Contentful Paint",
        desc: "FCP: " + fcpSecs + "s.",
        rec: "Bring FCP under ~1.8s from " + fcpSecs + "s: inline critical CSS, defer render-blocking scripts, and preload the hero image."
      });
    }
    // Core Web Vitals as first-class issues (previously tiles-only): poor
    // field-equivalent scores here fail the same bar Google uses (LCP 2.5s,
    // INP 200ms, CLS 0.1; critical at 4s / 500ms / 0.25).
    if (data.performance.largestContentfulPaint !== null && data.performance.largestContentfulPaint !== undefined && data.performance.largestContentfulPaint > 2500) {
      var lcpSecs = (data.performance.largestContentfulPaint / 1000).toFixed(1);
      issues.push({
        level: data.performance.largestContentfulPaint > 4000 ? "critical" : "warning",
        title: "Slow Largest Contentful Paint",
        desc: "LCP: " + lcpSecs + "s.",
        rec: "Bring LCP under 2.5s from " + lcpSecs + "s: preload the LCP image, serve it in a modern format at exact display size, and remove render-blocking requests ahead of it."
      });
    }
    if (data.performance.interactionToNextPaint !== null && data.performance.interactionToNextPaint !== undefined && data.performance.interactionToNextPaint > 200) {
      issues.push({
        level: data.performance.interactionToNextPaint > 500 ? "critical" : "warning",
        title: "Slow interaction response (INP)",
        desc: "INP: " + Math.round(data.performance.interactionToNextPaint) + "ms.",
        rec: "Bring INP under 200ms from " + Math.round(data.performance.interactionToNextPaint) + "ms: break up long tasks over 50ms on interaction paths and defer third-party JS."
      });
    }
    if (data.performance.cumulativeLayoutShift !== null && data.performance.cumulativeLayoutShift !== undefined && data.performance.cumulativeLayoutShift > 0.1) {
      var clsVal = Math.round(data.performance.cumulativeLayoutShift * 1000) / 1000;
      issues.push({
        level: data.performance.cumulativeLayoutShift > 0.25 ? "critical" : "warning",
        title: "Layout shift (CLS)",
        desc: "CLS: " + clsVal + ".",
        rec: "Bring CLS under 0.1 from " + clsVal + ": reserve width/height on images, ads, and embeds, and never inject content above what is already rendered."
      });
    }
    if (data.performance.thirdPartyCount > 15) {
      issues.push({
        level: "warning",
        title: "Many third-party resources",
        desc: data.performance.thirdPartyCount + " third-party resources detected.",
        rec: "Remove or async/defer the least-essential of the " + data.performance.thirdPartyCount + " third-party resources \u2014 each adds DNS, TLS, and parse cost on the critical path."
      });
    }
    if (data.performance.largeResources.length > 0) {
      var biggest = data.performance.largeResources[0] || {};
      var biggestTxt = biggest.name ? " \u2014 biggest is \u201C" + biggest.name + "\u201D" + (biggest.bytes ? " (" + Math.round(biggest.bytes / 1024) + "KB" + (biggest.type ? ", " + biggest.type : "") + ")" : "") : "";
      issues.push({
        level: "warning",
        title: "Large resources",
        desc: data.performance.largeResources.length + " resource(s) over 200KB.",
        rec: "Compress/convert the " + data.performance.largeResources.length + " resources over 200KB" + biggestTxt + "."
      });
    }
    if ((data.performance.inlineScriptBytes || 0) > 40 * 1024) {
      var inlineKb = Math.round((data.performance.inlineScriptBytes || 0) / 1024);
      var inlineBlocks = data.performance.inlineScriptCount || 0;
      issues.push({
        level: "warning",
        title: "Large inline script payload",
        desc: "Inline <script> blocks total around " + inlineKb + "KB of source.",
        rec: "Move the " + inlineKb + "KB across " + inlineBlocks + " inline <script> block(s) into deferred external files so the HTML stays lean and cacheable."
      });
    }
    if ((data.performance.scriptTagCount || 0) > 40) {
      issues.push({
        level: "warning",
        title: "Many script tags",
        desc: (data.performance.scriptTagCount || 0) + " <script> tags on the page (" + (data.performance.externalScriptCount || 0) + " external).",
        rec: "Consolidate the " + data.performance.scriptTagCount + " <script> tags (" + (data.performance.externalScriptCount || 0) + " external) with bundling, and defer/async everything below the fold."
      });
    }

    // SEO issues
    if (!data.seo.hasTitle) {
      issues.push({ level: "critical", title: "Missing page title", desc: "No <title> tag found.", rec: "Add one descriptive 30\u201360 character title with the primary keyword first \u2014 it is the single highest-leverage SEO fix here." });
    } else if (!data.seo.titleOk) {
      var titleDelta = data.seo.titleLength < 30 ? "add ~" + (30 - data.seo.titleLength) + " characters" : "trim ~" + (data.seo.titleLength - 60) + " characters";
      issues.push({ level: "warning", title: "Title length issue", desc: "Title is " + data.seo.titleLength + " characters.", rec: "Rewrite to 30\u201360 characters (now " + data.seo.titleLength + ": " + titleDelta + "), front-loading the primary keyword." });
    }
    if (!data.seo.hasDescription) {
      issues.push({ level: "critical", title: "Missing meta description", desc: "No meta description found.", rec: "Add a 120\u2013160 character click-worthy summary \u2014 it directly controls the search-result snippet." });
    } else if (!data.seo.descriptionOk) {
      var descDelta = data.seo.descriptionLength < 120 ? "add ~" + (120 - data.seo.descriptionLength) + " characters" : "trim ~" + (data.seo.descriptionLength - 160) + " characters";
      issues.push({ level: "warning", title: "Meta description length issue", desc: "Description is " + data.seo.descriptionLength + " characters.", rec: "Rewrite to 120\u2013160 characters (now " + data.seo.descriptionLength + ": " + descDelta + ")." });
    }
    if (!data.seo.hasCanonical) {
      issues.push({ level: "warning", title: "Missing canonical tag", desc: "No canonical URL specified.", rec: "Add a canonical link to prevent duplicate content issues." });
    }
    if (data.seo.multipleCanonicals) {
      issues.push({ level: "warning", title: "Multiple canonical tags", desc: "More than one canonical URL is declared.", rec: "Keep exactly one canonical URL per page so search engines follow the intended one." });
    }
    if (data.seo.hasNoindex) {
      issues.push({ level: "warning", title: "Page blocked from search (noindex)", desc: "The meta robots tag includes noindex.", rec: "Remove noindex unless you intend this page to stay out of search results." });
    }
    if ((data.seo.hasTitle || data.seo.hasDescription) && (!data.seo.hasOgTitle || !data.seo.hasOgImage)) {
      issues.push({
        level: "warning",
        title: "Incomplete social metadata",
        desc: (data.seo.hasOgTitle ? "og:title is set but " : "og:title and/or ") + (data.seo.hasOgImage ? "" : "og:image is ") + "missing for link-sharing previews.",
        rec: "Add og:title and og:image so shared links render a proper labeled preview."
      });
    }
    if (!data.headings.hasH1) {
      issues.push({ level: "critical", title: "Missing H1 heading", desc: "No H1 heading found on the page.", rec: "Add exactly one descriptive H1 naming the page topic \u2014 crawlers and screen readers orient on it first." });
    } else if (!data.headings.singleH1) {
      issues.push({ level: "warning", title: "Multiple H1 headings", desc: data.headings.counts.h1 + " H1 headings found.", rec: "Demote " + (data.headings.counts.h1 - 1) + " of the " + data.headings.counts.h1 + " H1s to H2 so the outline has a single top level." });
    }
    var emptyHeadingCount = 0;
    if (data.headings.headings) {
      data.headings.headings.forEach(function (h) { if (h.empty) emptyHeadingCount++; });
    }
    if (emptyHeadingCount > 0) {
      issues.push({ level: "warning", title: "Empty headings", desc: emptyHeadingCount + " heading(s) have no readable text.", rec: "Give the " + emptyHeadingCount + " empty heading(s) meaningful text, or remove them if purely decorative (see Affected elements)." });
    }
    if (data.headings.skippedLevels) {
      issues.push({ level: "warning", title: "Skipped heading levels", desc: "Heading levels jump somewhere in the outline (e.g. H2 to H4).", rec: "Renumber the jumped headings so levels run sequentially (H2 \u2192 H3, never H2 \u2192 H4)." });
    }

    // Accessibility issues
    if (data.accessibility.imagesMissingAlt > 0) {
      issues.push({
        level: "critical",
        title: "Missing image ALT text",
        desc: data.accessibility.imagesMissingAlt + " image(s) missing alt attributes.",
        rec: "Write descriptive alt text for the " + data.accessibility.imagesMissingAlt + " image(s) (see Affected elements); mark purely decorative ones alt=\"\"."
      });
    }
    if (data.accessibility.inputsNoLabel > 0) {
      issues.push({
        level: "warning",
        title: "Form inputs without labels",
        desc: data.accessibility.inputsNoLabel + " input(s) without associated labels.",
        rec: "Label the " + data.accessibility.inputsNoLabel + " input(s) with for/id or aria-label (see Affected elements)."
      });
    }
    if ((data.accessibility.buttonsNoName || 0) > 0) {
      issues.push({
        level: "warning",
        title: "Buttons without accessible names",
        desc: data.accessibility.buttonsNoName + " button(s) have no visible text, aria-label, or title.",
        rec: "Add visible text or an aria-label to the " + data.accessibility.buttonsNoName + " unnamed button(s) so their purpose can be announced."
      });
    }
    if ((data.accessibility.linksNoText || 0) > 0) {
      issues.push({
        level: "warning",
        title: "Links without accessible text",
        desc: data.accessibility.linksNoText + " link(s) have no text, aria-label, or image alt.",
        rec: "Give the " + data.accessibility.linksNoText + " link(s) a meaningful accessible name for screen readers and keyboard users."
      });
    }
    if ((data.accessibility.iframesNoTitle || 0) > 0) {
      issues.push({
        level: "warning",
        title: "Iframes without titles",
        desc: data.accessibility.iframesNoTitle + " iframe(s) are missing a title attribute.",
        rec: "Add a title describing the embedded content to the " + data.accessibility.iframesNoTitle + " iframe(s)."
      });
    }
    if ((data.accessibility.navsNoName || 0) > 0) {
      issues.push({
        level: "warning",
        title: "Navigation without accessible name",
        desc: data.accessibility.navsNoName + " <nav> element(s) lack an aria-label or aria-labelledby.",
        rec: "Label the " + data.accessibility.navsNoName + " navigation region(s) (e.g. aria-label=\"Primary\") so assistive tech can distinguish them."
      });
    }

    // Structure issues
    if (!data.structure.hasMain) {
      issues.push({ level: "warning", title: "Missing main landmark", desc: "No <main> element found.", rec: "Use <main> to identify the primary content of the page." });
    }
    if (!data.structure.hasHeader) {
      issues.push({ level: "warning", title: "Missing header", desc: "No <header> element found.", rec: "Add a <header> element for better semantic structure." });
    }
    if (!data.structure.hasFooter) {
      issues.push({ level: "warning", title: "Missing footer", desc: "No <footer> element found.", rec: "Add a <footer> element for better semantic structure." });
    }
    var htmlLang = (data.structure && data.structure.htmlLang) || "";
    if (!htmlLang) {
      issues.push({
        level: "warning",
        title: "Missing document language",
        desc: "No lang attribute on the <html> element.",
        rec: "Add lang=\"...\" to <html> so screen readers, translators, and spell checkers pick the right language."
      });
    }

    // Good items
    if (data.seo.hasTitle && data.seo.titleOk) {
      issues.push({ level: "good", title: "SEO title", desc: "Title is present and within a reasonable length (" + data.seo.titleLength + " chars).", rec: "" });
    }
    if (data.seo.hasDescription && data.seo.descriptionOk) {
      issues.push({ level: "good", title: "Meta description", desc: "Description is present and well-sized (" + data.seo.descriptionLength + " chars).", rec: "" });
    }
    if (data.seo.hasCanonical) {
      issues.push({ level: "good", title: "Canonical tag", desc: "Canonical URL is set.", rec: "" });
    }
    if (data.headings.hasH1 && data.headings.singleH1 && !data.headings.skippedLevels) {
      issues.push({ level: "good", title: "Heading hierarchy", desc: "Single H1 with proper heading hierarchy.", rec: "" });
    }
    if (data.structure.hasMain && data.structure.hasHeader && data.structure.hasFooter) {
      issues.push({ level: "good", title: "Semantic landmarks", desc: "Header, main, and footer landmarks present.", rec: "" });
    }
    if (htmlLang) {
      issues.push({ level: "good", title: "Document language", desc: "The page declares its language (lang=\"" + htmlLang + "\").", rec: "" });
    }
    if ((data.dom.inlineStyleCount || 0) > 0 && data.dom.inlineStyleCount <= 20) {
      issues.push({ level: "good", title: "Inline styles contained", desc: "Only " + data.dom.inlineStyleCount + " element(s) carry inline style attributes.", rec: "" });
    }
    var imageTotal = (data.images && data.images.total) || 0;
    var imageWithAlt = (data.images && data.images.withAlt) || 0;
    if (imageTotal > 0 && (data.accessibility && data.accessibility.imagesMissingAlt || 0) === 0) {
      issues.push({ level: "good", title: "Image alt coverage", desc: "All " + imageTotal + " image(s) carry alt text.", rec: "" });
    }
    if ((data.performance.jsBytes || 0) > 0 && data.performance.jsBytes < 200 * 1024) {
      issues.push({ level: "good", title: "JavaScript weight", desc: "JS payload is light at about " + Math.round(data.performance.jsBytes / 1024) + "KB.", rec: "" });
    }
    if (data.dom.elementor && data.dom.elementor.detected &&
        data.dom.elementor.excessive && data.dom.elementor.excessive.level === "good") {
      issues.push({ level: "good", title: "Elementor container usage", desc: "Container nesting and count are within healthy limits.", rec: "" });
    }

    // ---- v2: info items (informational, neutral) ----
    if (data.page && typeof data.page.viewport === "string") {
      if (data.page.viewport) {
        issues.push({ level: "info", title: "Viewport configured", desc: "The page declares its viewport: \"" + data.page.viewport + "\".", rec: "", category: "responsive" });
      } else {
        issues.push({ level: "info", title: "No viewport meta", desc: 'The page has no <meta name="viewport"> tag, so mobile browsers may render it at desktop width.', rec: '<meta name="viewport" content="width=device-width, initial-scale=1">', category: "responsive" });
      }
    }
    var techNames2 = [];
    var techGroups2 = (data.technology && data.technology.groups) || {};
    ["cms", "frameworks", "libraries", "ecommerce", "pageBuilders", "cssFrameworks"].forEach(function (k) {
      (techGroups2[k] || []).forEach(function (t) { techNames2.push(t.name || t); });
    });
    if (techNames2.length) {
      issues.push({ level: "info", title: "Technology stack detected", desc: "On-page detection found: " + techNames2.slice(0, 8).join(", ") + (techNames2.length > 8 ? " and " + (techNames2.length - 8) + " more" : "") + ".", rec: "", category: "technology" });
    }
    var linkTotal2 = (data.links && data.links.total) || 0;
    if (linkTotal2 > 0) {
      issues.push({ level: "info", title: "Link volume", desc: linkTotal2 + " anchor link(s) found" + (data.links && data.links.external != null ? " \u00B7 " + data.links.external + " external" : "") + ".", rec: "", category: "links" });
    }

    // ---- per-element evidence from the scan ----
    attachEvidence(issues, data);

    // ---- v2: category mapping ----
    issues.forEach(function (it) { it.category = wdCategoryOf(it.title); });

    // Sort: critical first, then warning, then info, then good
    var order = { critical: 0, warning: 1, info: 2, good: 3 };
    issues.sort(function (a, b) { return order[a.level] - order[b.level]; });
    return issues;
  }

  // Enriched detail view: WHAT / WHERE / EVIDENCE / WHY / FIX / VERIFY.
  function wdIssueDetail(issue) {
    var cat = issue.category || "other";
    return {
      problem: issue.title,
      why: WD_WHY[cat] || WD_WHY.other,
      evidence: issue.desc,
      fix: issue.rec || (issue.level === "good" ? "No action required - this check passes." : "No specific fix provided."),
      tech: issue.tech || (WD_TECH[cat] || WD_TECH.other),
      value: issue.value,
      unit: issue.unit,
      verify: issue.verify || ""
    };
  }

  // ------------------------------------------------------------
  // performance / CWV helpers
  // ------------------------------------------------------------
  function cwvVerdict(m, ok) {
    if (!ok) return "not available";
    if (m.value <= m.good) return "good";
    if (m.value <= m.bad) return "needs work";
    return "poor";
  }

  function naNote(perf) {
    var missing = [];
    if (perf.largestContentfulPaint === null) missing.push("LCP");
    if (perf.interactionToNextPaint === null) missing.push("INP");
    if (perf.cumulativeLayoutShift === null) missing.push("CLS");
    if (missing.length === 0) return "All three Core Web Vitals were measured.";
    return "Could not read " + missing.join(", ") + " \u2014 the page cleared or never reported those entries before this scan.";
  }

  function cwvOf(perf) {
    if (!perf) perf = {};
    var defs = [
      { key: "lcp", label: "LCP", full: "Largest Contentful Paint", value: perf.largestContentfulPaint, unit: "s", good: 2500, bad: 4000, fmt: function (v) { return (v / 1000).toFixed(2); } },
      { key: "inp", label: "INP", full: "Interaction to Next Paint", value: perf.interactionToNextPaint, unit: "ms", good: 200, bad: 500, fmt: function (v) { return String(v); } },
      { key: "cls", label: "CLS", full: "Cumulative Layout Shift", value: perf.cumulativeLayoutShift, unit: "", good: 0.1, bad: 0.25, fmt: function (v) { return Number(v).toFixed(3); } }
    ];
    return defs.map(function (m) {
      var ok = m.value !== null && m.value !== undefined;
      return {
        key: m.key, label: m.label, full: m.full, value: m.value, unit: m.unit,
        ok: ok, cls: ok ? (m.value <= m.good ? "green" : m.value <= m.bad ? "yellow" : "red") : "na",
        judgment: cwvVerdict(m, ok), display: ok ? m.fmt(m.value) : "\u2014"
      };
    });
  }

  function getPerfStatus(val, good, bad) {
    if (val === null || val === undefined) return "gray";
    if (val <= good) return "green";
    if (val <= bad) return "yellow";
    return "red";
  }

  // ------------------------------------------------------------
  // platform helper (real data only)
  // ------------------------------------------------------------
  var PLATFORM_BLUEPRINTS = {
    wordpress: { label: "WordPress", hint: "PHP-based CMS. Check for heavy page-builder output (Elementor/Divi), plugin bloat, and outdated themes.", checks: ["Plugin count", "Theme support", "Elementor nesting", "Injected inline styles"], icon: "wp" },
    shopify: { label: "Shopify", hint: "Managed e-commerce platform. Heavy theme JS, app widgets, and large product assets commonly drive CLS and slow LCP.", checks: ["Theme JS payload", "App widget count", "Product image sizes", "Checkout links"], icon: "shop" },
    wix: { label: "Wix", hint: "Website builder. Wix sites load many runtime scripts; large hero images and embedded apps can delay LCP and shift layout.", checks: ["Wix runtime scripts", "Hero media size", "Embedded apps", "Layout shift on load"], icon: "wix" },
    bigcommerce: { label: "BigCommerce", hint: "E-commerce platform. Watch stencil theme bundle size, app/script widgets, and unoptimized product media.", checks: ["Theme bundle size", "App scripts", "Product image sizes", "Search assets"], icon: "big" },
    elementor: { label: "Elementor", hint: "WordPress page builder. Deep container nesting adds DOM weight; unused widgets and duplicate stylesheets slow the page.", checks: ["Container nesting depth", "Widget count", "Extra stylesheets", "Inline style bloat"], icon: "ele" },
    wixsite: { label: "Wix", hint: "Website builder. Wix sites load many runtime scripts; large hero images and embedded apps can delay LCP and shift layout.", checks: ["Wix runtime scripts", "Hero media size", "Embedded apps", "Layout shift on load"], icon: "wix" }
  };

  function platformOf(tech) {
    if (!tech) return { known: false };
    var groups = tech.groups || {};
    var primary = (tech.primary && (tech.primary.name || "")) || "";
    var names = [primary.toLowerCase()];
    Object.keys(groups).forEach(function (k) {
      (groups[k] || []).forEach(function (t) { names.push(String((t.name) || "").toLowerCase()); });
    });
    var joined = " " + names.join(" ") + " ";
    function has(kw) { return joined.indexOf(kw) !== -1; }
    if (has("wix")) return extend("wix");
    if (has("shopify") || has("shopify themes")) return extend("shopify");
    if (has("bigcommerce")) return extend("bigcommerce");
    if (has("wordpress") || has("elementor") && !has("shopify")) {
      if (has("elementor") && !has("wordpress")) return extend("elementor");
      return extend("wordpress");
    }
    if (primary) {
      return { known: false, name: primary, groups: groups };
    }
    return { known: false };
    function extend(slug) {
      var b = PLATFORM_BLUEPRINTS[slug];
      return { known: true, slug: slug, label: b.label, hint: b.hint, checks: b.checks, icon: b.icon, name: primary, primary: tech.primary, groups: groups };
    }
  }

  WD.escapeHtml = escapeHtml;
  WD.formatBytes = formatBytes;
  WD.CATEGORY_ORDER = CATEGORY_ORDER;
  WD.WD_CAT_LABEL = WD_CAT_LABEL;
  WD.WD_CAT_ICONS = WD_CAT_ICONS;
  WD.WD_SEV_ICON = WD_SEV_ICON;
  WD.WD_CHEV_DOWN = WD_CHEV_DOWN;
  WD.WD_CHEV_UP = WD_CHEV_UP;
  WD.WD_WHY = WD_WHY;
  WD.WD_TECH = WD_TECH;
  WD.wdCategoryOf = wdCategoryOf;
  WD.collectIssues = collectIssues;
  WD.wdIssueDetail = wdIssueDetail;
  WD.cwvVerdict = cwvVerdict;
  WD.naNote = naNote;
  WD.cwvOf = cwvOf;
  WD.getPerfStatus = getPerfStatus;
  WD.platformOf = platformOf;

  window.WDCommon = WD;
})();