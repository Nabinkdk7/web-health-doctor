/*!
 * WEB DOCTOR 2 — AI CORE (provider-independent)
 *
 * The scanner never depends on this file. AI is a pure enhancement layer:
 * if no provider is configured, or every provider is unavailable, every other
 * feature still works and the UI says so clearly.
 *
 * One common adapter contract -> many providers. Adding a provider means
 * registering an adapter; nothing else in the system changes.
 *
 * Security rules honored here:
 *  - API keys live only in chrome.storage.local (extension-private), never in
 *    scan data, exports, or any page the user hasn't granted.
 *  - A provider key is only ever sent to that provider's own endpoint.
 *  - Diagnostic context sent to AI providers is sanitized (keys, tokens,
 *    cookies, passwords stripped) before it leaves the machine.
 *
 * No fake numbers, no fabricated findings: AI output is labled "Detected"
 * (facts straight from the scan) vs "Possible cause" (assistant reasoning).
 */
(function () {
  "use strict";

  // ------------------------------------------------------------------ //
  // Provider registry & constants
  // ------------------------------------------------------------------ //
  var PROVIDERS = {};

  // Adapter contract (implemented by explicit/registered providers and the
  // OpenAI-compatible base): send(cfg, opts, hooks) -> {promise, stop}
  function registerProvider(def) {
    PROVIDERS[def.id] = def;
  }

  function providerList() {
    return Object.keys(PROVIDERS).map(function (id) { return PROVIDERS[id]; });
  }

  // Guess which provider an API key belongs to, purely by its prefix.
  // Only unambiguous prefixes are matched; "" means "unknown / let user pick".
  function detectProviderByKey(key) {
    var k = String(key || "").trim().replace(/^["'\s]+|["'\s]+$/g, "");
    if (!k) return "";
    if (/^sk-or-[a-z0-9]/i.test(k)) return "openrouter";   // OpenRouter keys: sk-or-…
    if (/^gsk_[a-z0-9]/i.test(k)) return "groq";            // Groq keys: gsk_…
    if (/^AIza[a-zA-Z0-9_-]{15,}/.test(k)) return "gemini"; // Google API keys: AIza…
    if (/^sk-[a-z0-9]/i.test(k)) return "openai";           // OpenAI (and Cerebras) keys: sk-…
    return "";
  }

  // Curated *maintained config* used only when model discovery is unavailable.
  // Marked clearly as a maintenance list, not a live capability claim.
  var CURATED_MODELS = {
    openrouter: [
      { id: "anthropic/claude-3.7-sonnet", name: "Claude 3.7 Sonnet", ctx: 200000, tools: true, vision: true, coding: true },
      { id: "openai/gpt-4o-mini", name: "GPT-4o mini", ctx: 128000, tools: true, vision: true, coding: true },
      { id: "google/gemini-2.5-flash", name: "Gemini 2.5 Flash", ctx: 1000000, tools: true, vision: true, coding: true },
      { id: "meta-llama/llama-3.3-70b-instruct", name: "Llama 3.3 70B", ctx: 131072, tools: false, vision: false, coding: true }
    ],
    gemini: [
      { id: "gemini-2.5-pro", name: "Gemini 2.5 Pro", ctx: 1048576, tools: true, vision: true, coding: true },
      { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash", ctx: 1048576, tools: true, vision: true, coding: true },
      { id: "gemini-2.0-flash", name: "Gemini 2.0 Flash", ctx: 1048576, tools: true, vision: true, coding: true },
      { id: "gemini-1.5-flash", name: "Gemini 1.5 Flash", ctx: 1048576, tools: true, vision: true, coding: true }
    ],
    groq: [
      { id: "llama-3.3-70b-versatile", name: "Llama 3.3 70B Versatile", ctx: 131072, tools: true, vision: false, coding: true },
      { id: "llama-3.1-8b-instant", name: "Llama 3.1 8B Instant", ctx: 131072, tools: false, vision: false, coding: false },
      { id: "gemma2-9b-it", name: "Gemma 2 9B IT", ctx: 8192, tools: false, vision: false, coding: false }
    ],
    cerebras: [
      { id: "llama-3.3-70b", name: "Llama 3.3 70B", ctx: 128000, tools: false, vision: false, coding: true },
      { id: "llama-3.1-8b", name: "Llama 3.1 8B", ctx: 128000, tools: false, vision: false, coding: false }
    ],
    mistral: [
      { id: "mistral-large-latest", name: "Mistral Large", ctx: 128000, tools: true, vision: true, coding: true },
      { id: "mistral-small-latest", name: "Mistral Small", ctx: 128000, tools: true, vision: false, coding: true },
      { id: "codestral-latest", name: "Codestral", ctx: 256000, tools: false, vision: false, coding: true },
      { id: "pixtral-large-latest", name: "Pixtral Large", ctx: 128000, tools: true, vision: true, coding: true }
    ],
    openai: [
      { id: "gpt-4o", name: "GPT-4o", ctx: 128000, tools: true, vision: true, coding: true },
      { id: "gpt-4o-mini", name: "GPT-4o mini", ctx: 128000, tools: true, vision: true, coding: true },
      { id: "gpt-4.1-mini", name: "GPT-4.1 mini", ctx: 1000000, tools: true, vision: true, coding: true }
    ],
    agentrouter: [
      { id: "auto", name: "Auto (best available)", ctx: 128000, tools: true, vision: true, coding: true },
      { id: "gpt-4o", name: "GPT-4o", ctx: 128000, tools: true, vision: true, coding: true },
      { id: "gpt-4o-mini", name: "GPT-4o mini", ctx: 128000, tools: true, vision: true, coding: true },
      { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash", ctx: 1048576, tools: true, vision: true, coding: true },
      { id: "claude-sonnet-4-5", name: "Claude Sonnet 4.5", ctx: 200000, tools: true, vision: true, coding: true }
    ]
  };
  CURATED_MODELS["openai-compatible"] = CURATED_MODELS.openai;

  // Free-tier eligibility: a best-effort maintained hint, never a guarantee.
  // Actual pricing / availability is decided by each provider at request time.
  var CURATED_FREE = {
    openrouter: [
      "nousresearch/hermes-3-llama-3.1-405b:free",
      "meta-llama/llama-3.3-70b-instruct:free",
      "meta-llama/llama-3.1-8b-instruct:free",
      "microsoft/phi-3.5-mini-128k-instruct:free"
    ],
    gemini: ["gemini-1.5-flash", "gemini-2.0-flash"],
    groq: ["llama-3.3-70b-versatile", "llama-3.1-8b-instant"],
    cerebras: [],
    mistral: ["mistral-small-latest"],
    openai: [],
    agentrouter: [],
    "openai-compatible": []
  };

  // Task -> required capabilities. We route on technical requirements, never
  // "best model" marketing.
  var TASK_REQS = {
    css:      { coding: true, reason: false },
    js:       { coding: true, reason: true },
    dom:      { coding: false, reason: false },
    network:  { coding: false, reason: false },
    performance: { coding: false, reason: true },
    seo:      { coding: false, reason: false },
    accessibility: { coding: false, reason: false },
    responsive: { coding: true, reason: false },
    images:   { coding: false, reason: false, vision: false },
    screenshot: { vision: true },
    html:     { coding: true },
    largeau:  { longCtx: true },
    question: { fast: true },
    general:  {}
  };

  // Simple capability inference from ids for curated fallback tagging.
  var TAG_RULES = {
    coding: [/claude/i, /gpt/i, /gemini/i, /llama/i, /qwen/i, /mistral/i, /codestral/i, /deepseek/i, /glm/i, /grok/i, /o1/i, /o3/i, /4o/i, /2\.5/i],
    vision:  [/vision/i, /gemini/i, /gpt-4o/i, /gpt-4\.1/i, /claude/i, /pixtral/i, /llava/i, /qwen2?-vl/i],
    fast:    [/mini/i, /flash/i, /small/i, /instant/i, /nano/i, /turbo/i, /lite/i, /haiku/i],
    longCtx: [/128k/i, /256k/i, /1m/i, /million/i, /gemini-2\.5/i, /claude-3-5-sonnet/i, /gpt-4-1/i, /gpt-4\.1/i, /qwen2-5/i],
    reason:  [/o1/i, /o3/i, /o4/i, /thinking/i, /deepseek-r1/i, /gemini-2\.5/i, /claude/i]
  };

  function tagsOf(model) {
    var tags = { vision: !!model.vision, tools: !!model.tools, coding: !!model.coding };
    var id = String(model.id || "");
    Object.keys(TAG_RULES).forEach(function (k) {
      if (tags[k] !== undefined) return;
      var hit = TAG_RULES[k].some(function (re) { return re.test(id); });
      if (k === "vision") tags.vision = hit;
      else if (k === "tools") tags.tools = hit;
      else if (k === "coding") tags.coding = hit;
      else if (k === "fast") tags.fast = hit;
      else if (k === "longCtx") tags.longCtx = hit;
      else if (k === "reason") tags.reason = hit;
    });
    if (model.contextLength) tags.longCtx = model.contextLength >= 120000;
    return tags;
  }

  function capabilityOf(model, task) {
    var tags = tagsOf(model);
    var req = TASK_REQS[task] || TASK_REQS.general;
    var ok = true;
    ["vision", "coding", "longCtx", "fast", "reason"].forEach(function (k) {
      if (req[k] && !tags[k]) ok = false;
    });
    return { ok: ok, tags: tags, req: req };
  }

  function modelContextLength(providerId, m) {
    var n =
      m.contextLength || m.contextWindow || m.context_length ||
      m.maxContextTokens || m.limits && m.limits.context_window || m.ctx;
    if (n) return n;
    var curated = CURATED_MODELS[providerId] || [];
    for (var i = 0; i < curated.length; i++) {
      if (curated[i].id === m.id) return curated[i].ctx;
    }
    return 0;
  }

  // Normalize ANY model record (curated, discovered, or already tagged) into one
  // shape with inferred capability tags and a real context length. Single source
  // of truth for scoring, pickers, and model lists.
  function normRecord(m, providerId) {
    var t = tagsOf(m || {});
    return {
      id: m && m.id,
      contextLength: modelContextLength(providerId, m || {}),
      free: (m && m.free === true) || isFreeModel(providerId, m || {}),
      vision: !!t.vision, tools: !!t.tools, coding: !!t.coding,
      fast: !!t.fast, reason: !!t.reason, longCtx: !!t.longCtx
    };
  }

  function isFreeModel(providerId, m) {
    var list = CURATED_FREE[providerId] || [];
    var id = String(m.id || "");
    if (list.indexOf(id) !== -1) return true;
    // OpenRouter returns byte-level costs; all-zero object = free model.
    try {
      var c = m.pricing;
      if (c && typeof c === "object" && c.prompt !== undefined) {
        var allZero = ["prompt", "completion", "image", "request"]
          .every(function (k) { return !c[k] || c[k] === 0; });
        if (allZero) return true;
      }
    } catch (e) {}
    return false;
  }

  // ------------------------------------------------------------------ //
  // Config storage (extension-local, keys never leave the extension)
  // ------------------------------------------------------------------ //
  function defaults() {
    return {
      wdAiProviders: [],
      wdAiMode: "auto",
      wdAiSession: { history: [], task: "general", issue: null, sentCount: 0 }
    };
  }

  function load(cb) {
    if (!(typeof chrome !== "undefined" && chrome.storage && chrome.storage.local)) {
      cb(null);
      return;
    }
    chrome.storage.local.get(defaults(), function (o) {
      if (chrome.runtime.lastError) { cb(null); return; }
      cb(o);
    });
  }

  function save(partial, cb) {
    if (!(typeof chrome !== "undefined" && chrome.storage && chrome.storage.local)) {
      if (cb) cb();
      return;
    }
    chrome.storage.local.set(partial, function () {
      if (chrome.runtime.lastError) { /* storage full etc: surface at caller */ }
      if (cb) cb();
    });
  }

  function makeId() { return "prov_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }

  function maskKey(key) {
    var s = String(key || "");
    if (!s) return "";
    if (s.length <= 8) return "••••••••";
    return "••••••••" + s.slice(-4);
  }

  function stripKey(key) {
    return String(key || "").replace(/^[\s]+|[\s]+$/g, "");
  }

  // Best-effort key validation. Never blocks on unguessable prefixes — only on
  // empty/no-length keys — but returns actionable hints when the shape of the
  // key does not look like what the selected provider issues.
  function validateProviderKey(kind, key) {
    var k = stripKey(key);
    if (!k) return { ok: false, code: "empty", message: "API key is required.", warning: "" };
    if (k.length < 8) return { ok: false, code: "short", message: "That does not look like a complete API key (too short). Paste the full key.", warning: "" };
    if (/[\s]/i.test(k)) return { ok: false, code: "whitespace", message: "The API key contains spaces or line breaks. Paste a single value.", warning: "" };
    var hints = [];
    if (kind === "gemini" && !/^AIza/i.test(k)) hints.push("Gemini keys usually start with AIza\u2026");
    if (kind === "groq" && !/^gsk_/i.test(k)) hints.push("Groq keys usually start with gsk_\u2026");
    if (kind === "openrouter" && !/^sk-or-/i.test(k)) hints.push("OpenRouter keys usually start with sk-or-\u2026");
    if (kind === "openai" && !/^sk-[a-z]/i.test(k)) hints.push("OpenAI keys usually start with sk-\u2026");
    if (kind === "agentrouter" && !/^sk-[a-z]|^[a-zA-Z0-9]{20,}/i.test(k)) hints.push("Tried AgentRouter with a key that may belong to another provider.");
    if (kind === "openai-compatible") hints.push("OpenAI-compatible endpoints keep the key exactly as the provider issued it.");
    return { ok: true, code: "ok", message: "", warning: hints.join(" ") };
  }

  function withoutSecrets(cfg) {
    var c = {};
    Object.keys(cfg || {}).forEach(function (k) {
      if (k === "apiKey") { c.apiKey = "@key"; return; }
      c[k] = cfg[k];
    });
    return c;
  }

  // ------------------------------------------------------------------ //
  // Sanitizer — never leak credentials/keys/tokens/cookies to AI providers
  // ------------------------------------------------------------------ //
  var SENSITIVE_PATTERNS = [
    /(api[_-]?key\s*=|authorization\s*[:=]|bearer\s+)[^\s"',;]{6,}/ig,
    /(AIza[0-9A-Za-z_-]{14,})/g,
    /(sk-[0-9A-Za-z_-]{16,})/g,
    /(sk-[0-9A-Za-z_]{20,})/g,
    /(ya29\.[0-9A-Za-z._-]{20,})/g,
    /(ghp_[0-9A-Za-z]{20,})/g,
    /\btoken\s*[:=]+\s*[^\s"',;]{6,}/gi,
    /(password|passwd|pwd)\s*[:=]+\s*[^\s"',;]{4,}/gi,
    /\bphone\s*[:=]+\s*[^\s"',;]{5,}/gi,
    // JSON-ish quoted credentials: "api_key": "abcdef" / 'secret': 'xyz'
    /(["'])(api[_-]?key|token|secret|pass(?:word)?|pwd|auth)\1\s*[:=]\s*["']?[^"'\s,;{}]{6,}/gi
  ];
  function sanitize(text) {
    var s = String(text || "");
    SENSITIVE_PATTERNS.forEach(function (re) { s = s.replace(re, "[REDACTED]"); });
    // strip query strings that smell like credentials
    try {
      s = s.replace(/(\?|&)([a-z_]*key|token|auth|pass|secret)[^&\s]*/gi, "$1$2=[REDACTED]");
    } catch (e) {}
    return s;
  }

  // ------------------------------------------------------------------ //
  // HTTP helpers
  // ------------------------------------------------------------------ //
  function httpError(status) {
    if (status === 401 || status === 403) return "auth";
    if (status === 404) return "model_unavailable";
    if (status === 429) return "rate_limit";
    if (status === 402 || status === 409) return "quota";
    if (status === 408 || status === 504) return "timeout";
    if (status >= 500) return "server";
    return "unknown";
  }

  function classifyError(err, res) {
    var cls = "network";
    var msg = (err && err.message) || String(err);
    if (res) {
      cls = httpError(res.status);
      msg = "HTTP " + res.status + ": " + msg;
      return { cls: cls, msg: msg, retryAfter: res.retryAfter || 0, permanent: cls === "auth" || cls === "model_unavailable" };
    }
    if (/abort/i.test(msg) && err && err.name === "AbortError") return { cls: "stopped", msg: "Stopped.", permanent: true, retryAfter: 0 };
    if (/timeout|timed out|ETIMEDOUT/i.test(msg)) return { cls: "timeout", msg: "Request timeout.", retryAfter: 0, permanent: false };
    return { cls: cls, msg: msg, retryAfter: 0, permanent: false };
  }

  function fetchJson(url, opts, timeoutMs) {
    var ctrl = new AbortController();
    var t = setTimeout(function () { ctrl.abort(); }, timeoutMs || 30000);
    var p = fetch(url, { cache: "no-store", signal: opts && opts.signal ? opts.signal : ctrl.signal })
      .then(function (res) {
        return res.text().then(function (txt) {
          var retry = parseInt((res.headers.get("retry-after") || "0"), 10) || 0;
          var out = { ok: res.ok, status: res.status, body: null, retryAfter: retry };
          try { out.body = txt ? JSON.parse(txt) : {}; } catch (e) { out.body = { text: txt }; }
          return out;
        });
      }).finally(function () { clearTimeout(t); });
    return p;
  }

  // ------------------------------------------------------------------ //
  // OpenAI-compatible chat streaming (OpenRouter / Groq / Cerebras /
  // Mistral / OpenAI / any compatible endpoint) and Gemini.
  // ------------------------------------------------------------------ //
  function sseParser(reader, dec, onDelta, onDone, onErr) {
    var buf = "";
    return reader.read().then(function pump(result) {
      if (result.done) { onDone(); return; }
      buf += dec.decode(result.value, { stream: true });
      var nl;
      while ((nl = buf.indexOf("\n")) !== -1) {
        var line = buf.slice(0, nl).trim();
        buf = buf.slice(nl + 1);
        if (!line || line.charAt(0) === ":") continue;
        if (line.indexOf("data:") !== 0) continue;
        var payload = line.slice(5).trim();
        if (payload === "[DONE]") { onDone(); return; }
        try {
          var j = JSON.parse(payload);
          var txt = OpenAICompat.deltaText(j);
          if (txt) onDelta(txt);
        } catch (e) {}
      }
      return reader.read().then(pump);
    }).catch(function (err) { onErr(err); });
  }

  var OpenAICompat = {
    deltaText: function (j) {
      try {
        if (j.choices && j.choices[0]) {
          var c = j.choices[0];
          if (c.delta && typeof c.delta.content === "string") return c.delta.content;
          if (c.message && typeof c.message.content === "string") return c.message.content;
        }
      } catch (e) {}
      return "";
    },
    send: function (cfg, body, signal, hooks) {
      return fetch(cfg.baseUrl + "/chat/completions", {
        method: "POST",
        cache: "no-store",
        signal: signal,
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + cfg.apiKey
        },
        body: JSON.stringify(body)
      }).then(function (res) {
        hooks.status("connected", res.status);
        if (!res.ok) {
          return res.text().then(function (txt) {
            var retry = parseInt((res.headers.get("retry-after") || "0"), 10) || 0;
            throw { __http: true, status: res.status, text: txt.slice(0, 500), retryAfter: retry };
          });
        }
        if (!body.stream) {
          return res.json().then(function (j) { return { ok: true, json: j, full: OpenAICompat.deltaText(j) }; });
        }
        var reader = res.body.getReader();
        var dec = new TextDecoder();
        return new Promise(function (resolve, reject) {
          sseParser(reader, dec, hooks.delta, function () { resolve({ ok: true, stream: true }); }, reject);
        });
      });
    },
    discover: function (cfg, signal) {
      return fetchJson(cfg.baseUrl + "/models", { signal: signal }, 15000).then(function (r) {
        if (!r.ok) throw { __http: true, status: r.status, text: (r.body && (r.body.error && r.body.error.message || JSON.stringify(r.body))) || "" };
        var out = [];
        var list = (r.body && r.body.data) || [];
        list.forEach(function (m) {
          out.push({
            id: m.id,
            object: m.object,
            contextLength: m.context_length || m.max_context || 0,
            owned_by: m.owned_by
          });
        });
        return { models: out, source: "api" };
      });
    },
    usage: function (cfg, signal) {
      // OpenRouter credits endpoint (GET /credits). Unknown providers: null.
      if (!/openrouter/i.test(cfg.baseUrl)) return Promise.resolve(null);
      return fetchJson(cfg.baseUrl + "/credits", { signal: signal }, 15000).then(function (r) {
        if (!r.ok || !r.body) return null;
        return { usage: r.body };
      }).catch(function () { return null; });
    }
  };

  var Gemini = {
    deltaText: function (j) {
      try {
        if (j.candidates && j.candidates[0] && j.candidates[0].content) {
          var parts = j.candidates[0].content.parts || [];
          var out = "";
          parts.forEach(function (p) { if (typeof p.text === "string") out += p.text; });
          return out;
        }
      } catch (e) {}
      return "";
    },
    send: function (cfg, body, signal, hooks) {
      var url = cfg.baseUrl + "/models/" + encodeURIComponent(body.model)
        + (body.stream ? ":streamGenerateContent?alt=sse" : ":generateContent");
      var gBody = {
        contents: body.messages.filter(function (m) { return m.role === "user" || m.role === "model"; })
          .map(function (m) { return { role: m.role === "model" ? "model" : "user", parts: [{ text: m.content }] }; }),
        systemInstruction: body.systemInstruction ? { parts: [{ text: body.systemInstruction }] } : undefined,
        generationConfig: { temperature: body.temperature }
      };
      var payload = JSON.stringify(gBody);
      return fetch(url, {
        method: "POST",
        cache: "no-store",
        signal: signal,
        headers: { "Content-Type": "application/json", "x-goog-api-key": cfg.apiKey }
      }).then(function (res) {
        hooks.status("connected", res.status);
        if (!res.ok) {
          return res.text().then(function (txt) {
            var retry = parseInt((res.headers.get("retry-after") || "0"), 10) || 0;
            throw { __http: true, status: res.status, text: txt.slice(0, 500), retryAfter: retry };
          });
        }
        if (!body.stream) {
          return res.json().then(function (j) { return { ok: true, json: j, full: Gemini.deltaText(j) }; });
        }
        var reader = res.body.getReader();
        var dec = new TextDecoder();
        return new Promise(function (resolve, reject) {
          sseParser(reader, dec, hooks.delta, function () { resolve({ ok: true, stream: true }); }, reject);
        });
      });
    },
    discover: function (cfg, signal) {
      return fetchJson(cfg.baseUrl + "/models?pageSize=200", { signal: signal }, 15000).then(function (r) {
        if (!r.ok || !r.body) return { models: [], source: "api" };
        var out = [];
        (r.body.models || []).forEach(function (m) {
          if (!m.name) return;
          var id = m.name.indexOf("models/") === 0 ? m.name.slice(7) : m.name;
          var methods = m.supportedGenerationMethods || [];
          if (methods.indexOf("generateContent") === -1) return;
          var caps = m.supportedGenerationMethods || [];
          out.push({
            id: id,
            object: "model",
            contextLength: m.inputTokenLimit || m.maxInputTokens || 0,
            vision: /image/i.test(JSON.stringify(m.supportedModalities || m.supportedGenerationMethods || [])) || /gemini/.test(id),
            tools: m.supportedGenerationMethods.indexOf("TOOL_CALLING") !== -1 || /gemini/.test(id),
            owned_by: "google"
          });
        });
        return { models: out, source: "api", methods: caps };
      });
    },
    usage: function () { return Promise.resolve(null); }
  };

  function adapterFor(providerId) {
    if (providerId === "gemini") return Gemini;
    return OpenAICompat;
  }

  // ------------------------------------------------------------------ //
  // Registry
  // ------------------------------------------------------------------ //
  registerProvider({ id: "openrouter", label: "OpenRouter", baseUrl: "https://openrouter.ai/api/v1", checks: ["credits"], free: CURATED_FREE.openrouter, curated: CURATED_MODELS.openrouter });
  registerProvider({ id: "agentrouter", label: "AgentRouter", baseUrl: "https://agentrouter.org/v1", checks: ["credits"], free: CURATED_FREE.agentrouter, curated: CURATED_MODELS.agentrouter });
  registerProvider({ id: "gemini", label: "Google Gemini", baseUrl: "https://generativelanguage.googleapis.com/v1beta", checks: [], free: CURATED_FREE.gemini, curated: CURATED_MODELS.gemini });
  registerProvider({ id: "groq", label: "Groq", baseUrl: "https://api.groq.com/openai/v1", checks: [], free: CURATED_FREE.groq, curated: CURATED_MODELS.groq });
  registerProvider({ id: "cerebras", label: "Cerebras", baseUrl: "https://api.cerebras.ai/v1", checks: [], free: CURATED_FREE.cerebras, curated: CURATED_MODELS.cerebras });
  registerProvider({ id: "mistral", label: "Mistral", baseUrl: "https://api.mistral.ai/v1", checks: [], free: CURATED_FREE.mistral, curated: CURATED_MODELS.mistral });
  registerProvider({ id: "openai", label: "OpenAI", baseUrl: "https://api.openai.com/v1", checks: [], free: CURATED_FREE.openai, curated: CURATED_MODELS.openai });
  registerProvider({ id: "openai-compatible", label: "OpenAI-compatible", baseUrl: "", checks: [], free: CURATED_FREE["openai-compatible"], curated: CURATED_MODELS["openai-compatible"] });

  // ------------------------------------------------------------------ //
  // Model discovery + normalizing
  // ------------------------------------------------------------------ //
  function normalizeModels(providerId, raw) {
    var provider = PROVIDERS[providerId];
    if (!raw || !raw.models) return [];
    var out = raw.models.filter(function (m) { return m && m.id; }).map(function (m) {
      return normRecord(m, providerId);
    });
    if (!out.length && provider) out = provider.curated.slice();
    return out;
  }

  function discoverModels(cfg, cb) {
    var signal = new AbortController();
    var providerId = cfg.provider;
    if (!PROVIDERS[providerId]) { cb({ ok: false, error: "Unknown provider." }); return; }
    adapterFor(providerId).discover(cfg, signal.signal).then(function (raw) {
      var models = normalizeModels(providerId, raw);
      var list = curateForPicker(providerId, models, cfg);
      cb({ ok: true, models: models, picker: list, source: raw.source || "api" });
    }).catch(function (err) {
      var info = classifyError(err, err.__http ? { status: err.status, retryAfter: err.retryAfter } : null);
      // fall back to maintained config so the panel stays usable
      var curated = PROVIDERS[providerId] ? PROVIDERS[providerId].curated : [];
      var models = curateForPicker(providerId, curated, cfg);
      cb({ ok: true, models: curated, picker: models, source: "config", fallback: true, warning: info.msg });
    });
  }

  function curateForPicker(providerId, models, cfg) {
    var freeOnly = cfg && cfg.free;
    return models.slice(0, 30).map(function (raw) {
      var m = normRecord(raw, providerId);
      if (!m.id) return null;
      var tagList = [];
      ["vision", "tools", "coding", "fast", "reason"].forEach(function (k) { if (m[k]) tagList.push(k); });
      if (m.free) tagList.push("free");
      if (m.longCtx || m.contextLength >= 120000) tagList.push("long-context");
      if (freeOnly && !m.free) return null;
      return {
        id: m.id, contextLength: m.contextLength, free: m.free,
        vision: m.vision, tools: m.tools, coding: m.coding, fast: m.fast, reason: m.reason,
        tags: tagList
      };
    }).filter(Boolean);
  }

  function testConnection(cfg, cb) {
    if (!cfg || !cfg.apiKey) { cb({ ok: false, error: "No API key stored." }); return; }
    discoverModels(cfg, function (res) {
      if (!res.ok) { cb({ ok: false, error: res.error, at: Date.now() }); return; }
      // Choose a real model for a 1-token request: discovery alone cannot judge
      // a key (some providers serve GET /models without auth).
      var best = "";
      if (cfg.models && cfg.models.length) {
        var am = autoModel(cfg);
        best = am ? am.id : "";
      }
      var model = cfg.activeModel || best || (res.picker && res.picker[0] && res.picker[0].id) || "";
      if (!model) {
        cb({ ok: true, at: Date.now(), source: res.source, models: res.models.length, picker: res.picker || [], best: best, warning: res.warning || "" });
        return;
      }
      verifyProbe(cfg, model).then(function (v) {
        var at = Date.now();
        var warning = res.warning || "";
        if (v.status === 401 || v.status === 403) {
          cb({
            ok: false,
            error: "The API key was rejected by " + (cfg.label || cfg.provider) + " (HTTP " + v.status + "). Check the key and try again.",
            at: at, source: res.source, models: res.models.length, picker: res.picker || [], best: best
          });
          return;
        }
        if (!v.ok) warning = (warning ? warning + "; " : "") + "Connected to " + (cfg.label || cfg.provider) + " but a test request failed: " + v.text;
        cb({ ok: true, at: at, source: res.source, models: res.models.length, picker: res.picker || [], best: best, warning: warning });
      });
    });
  }

  // One minimal real request (1 output token) so a saved key is actually proven
  // against the endpoint, not just the model list. Hard 20s cap so the UI can
  // never hang on a dead / slow endpoint.
  function verifyProbe(cfg, modelId) {
    var adapter = adapterFor(cfg.provider);
    var ctrl = new AbortController();
    var timer = setTimeout(function () { ctrl.abort(); }, 20000);
    var body = {
      model: modelId,
      messages: [{ role: "user", content: "ping" }],
      stream: false,
      max_tokens: 1,
      temperature: 0.1
    };
    return adapter.send(cfg, body, ctrl.signal, { status: noopStatus, delta: noopDelta }).then(function () {
      clearTimeout(timer);
      return { ok: true, status: 200 };
    }, function (err) {
      clearTimeout(timer);
      if (err && err.__http) return { ok: false, status: err.status, text: String(err.text || "").slice(0, 300) };
      if (err && err.name === "AbortError") return { ok: false, status: 0, text: "request timed out" };
      var cls = classifyError(err, null);
      return { ok: false, status: 0, text: cls.msg };
    });
  }

  function noopStatus() {}
  function noopDelta() {}

  // ------------------------------------------------------------------ //
  // Router (fallback chains, retry policy, free mode, capability pick)
  // ------------------------------------------------------------------ //
  function buildChain(config, mode) {
    var provs = (config.wdAiProviders || []).filter(function (p) { return p && p.apiKey; });
    if (mode === "manual" && config.wdAiModeId) {
      var m = provs.find(function (p) { return p.id === config.wdAiModeId; });
      return m ? [m] : provs;
    }
    if (mode === "free") {
      return provs.filter(function (p) {
        return (PROVIDERS[p.provider] && (PROVIDERS[p.provider].free && PROVIDERS[p.provider].free.length)) ||
          (p.models || []).some(function (mm) { return mm.free; });
      });
    }
    return provs;
  }

  // Ordered, capability-aware candidates for a provider+task. Preference order
  // (for "high performance, low latency, max compatibility"):
  //   1. provider "auto" router ids (e.g. AgentRouter auto) — always first
  //   2. fast/low-latency tier (…mini / …flash / …small / …instant / …nano)
  //   3. capable larger models (reasoning / long-context)
  //   4. everything else that satisfies the task's required capabilities
  // Hard capabilities are coding + vision. fast/reason/longCtx are performance
  // preferences: when relaxSoft is set (fallback) they no longer filter so a
  // provider without a fast tier still answers (slower but never "no model").
  // Free-tier models win inside their tier; longer context wins ties.
  function scoredOrders(providerCfg, task, freeOnly, relaxSoft) {
    var models = providerCfg.models && providerCfg.models.length
      ? providerCfg.models
      : (PROVIDERS[providerCfg.provider] || { curated: CURATED_MODELS[providerCfg.provider] || [] }).curated || [];
    var req = TASK_REQS[task] || TASK_REQS.general;
    var out = [];
    models.forEach(function (raw) {
      var m = normRecord(raw, providerCfg.provider);
      if (!m.id) return;
      var match = true;
      if (req.coding && !m.coding) match = false;
      if (req.vision && !m.vision) match = false;
      if (!relaxSoft) {
        if (req.fast && !m.fast) match = false;
        if (req.reason && !m.reason) match = false;
        if (req.longCtx && !m.longCtx) match = false;
      }
      if (freeOnly && !m.free) match = false;
      if (!match) return;
      var tier = m.id === "auto" ? 4 : m.fast ? 3 : (m.reason || m.longCtx) ? 2 : 1;
      out.push({
        m: m,
        rating: tier * 100 + (m.free ? 40 : 0) + (req.fast && m.fast ? 5 : 0),
        len: m.contextLength || 0
      });
    });
    out.sort(function (a, b) {
      return b.rating - a.rating || b.len - a.len || String(a.m.id).localeCompare(String(b.m.id));
    });
    return out.map(function (s) { return s.m; });
  }

  // Pick a model for a task. Never "best" — technical capability match + fast
  // tier first, with a "maximum compatibility" fallback so a model always wins.
  function pickModel(providerCfg, task, freeOnly) {
    var order = scoredOrders(providerCfg, task, freeOnly);
    if (!order.length) order = scoredOrders(providerCfg, task, freeOnly, true);
    if (order.length) return order[0];
    if (freeOnly) return pickModel(providerCfg, task, false);
    var models = providerCfg.models && providerCfg.models.length
      ? providerCfg.models
      : (PROVIDERS[providerCfg.provider] || { curated: [] }).curated || [];
    return models[0] || null;
  }

  // Sensible default model for a provider (UI pre-selection and happy path):
  // flash/mini first, larger model as fallback, "auto" routers first overall.
  function autoModel(providerCfg) {
    var order = scoredOrders(providerCfg, "general", false);
    if (!order.length) order = scoredOrders(providerCfg, "general", false, true);
    if (order.length) return order[0];
    var models = providerCfg.models && providerCfg.models.length
      ? providerCfg.models
      : (PROVIDERS[providerCfg.provider] || { curated: [] }).curated || [];
    return models[0] || null;
  }

  // ------------------------------------------------------------------ //
  // Chat executor (single request, stream aware)
  // ------------------------------------------------------------------ //
  function executeOne(providerCfg, opts, hooks, signal) {
    var adapter = adapterFor(providerCfg.provider);
    var msgs = [];
    var hasSystem = opts.messages.some(function (m) { return m.role === "system"; });
    opts.messages.forEach(function (m) { if (m.role === "system" && providerCfg.provider === "gemini") { if (!opts.systemInstruction) opts.systemInstruction = m.content; return; } msgs.push(m); });
    if (!hasSystem) msgs = [{ role: "user", content: opts.messages.map(function (m) { return m.content; }).join("\n\n") }];
    if (providerCfg.provider === "gemini" && !opts.systemInstruction) {
      opts.systemInstruction = opts.messages[0] && opts.messages[0].role === "system" ? opts.messages[0].content : "";
    }
    var body = {
      model: opts.model,
      messages: msgs,
      stream: opts.stream,
      temperature: typeof opts.temperature === "number" ? opts.temperature : 0.25
    };
    return adapter.send(providerCfg, body, signal, hooks).then(function (res) {
      var full = res.full !== undefined ? res.full : "";
      return { ok: true, stream: res.stream === true, full: full, json: res.json || null };
    }).catch(function (err) {
      var resObj = err && err.__http ? { status: err.status, retryAfter: err.retryAfter } : null;
      throw classifyError(err, resObj);
    });
  }

  function providerLabel(cfg) {
    var p = PROVIDERS[cfg.provider];
    return (cfg.label || (p ? p.label : cfg.provider));
  }

  // ------------------------------------------------------------------ //
  // Public: AICore
  // ------------------------------------------------------------------ //
  var AI = {};
  AI.PROVIDERS = PROVIDERS;
  AI.providerList = providerList;
  AI.detectProviderByKey = detectProviderByKey;
  AI.curatedFree = CURATED_FREE;
  AI.tasks = TASK_REQS;

  AI.load = load;
  AI.save = save;
  AI.makeId = makeId;
  AI.maskKey = maskKey;
  AI.stripKey = stripKey;
  AI.validateProviderKey = validateProviderKey;
  AI.withoutSecrets = withoutSecrets;
  AI.sanitize = sanitize;
  AI.discoverModels = discoverModels;
  AI.testConnection = testConnection;
  AI.capabilityOf = capabilityOf;
  AI.tagsOf = tagsOf;
  AI.buildChain = buildChain;
  AI.pickModel = pickModel;
  AI.scoredOrders = scoredOrders;
  AI.autoModel = autoModel;
  AI.adapterFor = adapterFor;
  AI.classifyError = classifyError;

  // Chat: handle chain + retries + streaming. Returns a controller {stop}.
  AI.chat = function (opts, config, onEvent) {
    var controller = new AbortController();
    var mode = config.wdAiMode || "auto";
    var chain = buildChain(config, mode);
    var attempts = 0;
    var maxAttempts = 6;
    var failed = [];

    function emit(type, data) { try { onEvent && onEvent(type, data || {}); } catch (e) {} }

    function runChain(idx) {
      if (controller.signal.aborted) { emit("stopped", { why: "user" }); return Promise.resolve(null); }
      if (idx >= chain.length) {
        emit("error", { allFailed: true, failed: failed, message: buildFailureMessage(failed) });
        return Promise.resolve(null);
      }
      var cfg = chain[idx];
      var freeOnly = mode === "free";
      // Candidate models for this provider: an explicit pick (manual mode) or
      // the capability/fast-tier order. If the current model is unavailable at
      // the endpoint (404 etc.), the provider keeps trying its next candidate
      // before the chain falls back to a different provider.
      var task = opts.task || "general";
      var strict = scoredOrders(cfg, task, freeOnly).map(function (m) { return m.id; });
      var relax = scoredOrders(cfg, task, freeOnly, true).map(function (m) { return m.id; });
      // Fast/low-latency candidates first; if the picked model 404s at the
      // endpoint, the provider falls back to its slower capable models before
      // the chain moves to a different provider.
      var cands = opts.model
        ? [opts.model].concat(strict.concat(relax.filter(function (id) { return strict.indexOf(id) === -1; })).filter(function (id) { return id !== opts.model; }))
        : strict.concat(relax.filter(function (id) { return strict.indexOf(id) === -1; }));
      var ci = 0;
      function chosen() { return cands[ci] || null; }
      function chosenFree() {
        if (!cfg.models || !cfg.models.length) return false;
        for (var i = 0; i < cfg.models.length; i++) {
          if (String(cfg.models[i].id) === String(chosen())) return !!cfg.models[i].free;
        }
        return false;
      }
      if (!chosen()) { failed.push({ provider: providerLabel(cfg), error: "No eligible model." }); return runChain(idx + 1); }

      emit("route", { provider: providerLabel(cfg), model: chosen(), step: idx + 1, total: chain.length, free: chosenFree() });
      attempts++;

      var attempt = 0;
      var maxPerProvider = 2;

      function tryOnce() {
        if (controller.signal.aborted) { emit("stopped", { why: "user" }); return Promise.resolve(null); }
        attempt++;
        emit("starting", { provider: providerLabel(cfg), model: chosen(), attempt: attempt });
        return executeOne(cfg, {
          model: chosen(),
          messages: sanitizeMessages(opts.messages),
          stream: opts.stream !== false,
          task: opts.task,
          temperature: opts.temperature,
          systemInstruction: opts.systemInstruction
        }, {
          status: function (s, code) { emit("http", { provider: providerLabel(cfg), status: code, state: s }); },
          delta: function (text) { emit("delta", { provider: providerLabel(cfg), model: chosen(), text: text }); }
        }, controller.signal).then(function (res) {
          emit("done", { provider: providerLabel(cfg), model: chosen(), source: res && (res.json || res.full) });
          return res;
        }).catch(function (err) {
          if (err.cls === "stopped") { emit("stopped", { why: "user" }); return null; }
          // Model unavailable at the endpoint -> try the next candidate in this
          // provider before giving up on the provider entirely.
          if ((err.cls === "model_unavailable" || (err.cls === "unknown" && /model/i.test(err.msg))) && ci + 1 < cands.length && !controller.signal.aborted) {
            var prevId = cands[ci];
            ci++;
            emit("fallback", { from: prevId, to: cands[ci], reason: err.msg, model: true });
            emit("starting", { provider: providerLabel(cfg), model: cands[ci], attempt: attempt });
            return tryOnce();
          }
          if (err.permanent) {
            failed.push({ provider: providerLabel(cfg), cls: err.cls, error: err.msg });
            emit("failed", { provider: providerLabel(cfg), reason: err.msg, permanent: true });
            if (idx + 1 < chain.length && !controller.signal.aborted) {
              emit("fallback", { from: providerLabel(cfg), to: providerLabel(chain[idx + 1]), reason: err.msg });
            }
            return runChain(idx + 1);
          }
          if (attempt < maxPerProvider && attempts < maxAttempts) {
            var wait = 0;
            if (err.cls === "rate_limit") {
              wait = Math.min(err.retryAfter || 1, 30);
              if (!err.retryAfter) wait = 2;
              emit("retry", { provider: providerLabel(cfg), wait: wait, reason: err.msg, kind: "rate_limit", count: attempt });
            } else if (err.cls === "timeout" || err.cls === "server" || err.cls === "network") {
              wait = attempt * 1.5;
              emit("retry", { provider: providerLabel(cfg), wait: wait, reason: err.msg, kind: err.cls, count: attempt });
            } else {
              failed.push({ provider: providerLabel(cfg), cls: err.cls, error: err.msg });
              emit("failed", { provider: providerLabel(cfg), reason: err.msg, permanent: false });
              return runChain(idx + 1);
            }
            return delay(wait * 1000, controller.signal).then(function (ok) {
              if (!ok) { emit("stopped", { why: "user" }); return null; }
              return tryOnce();
            });
          }
          failed.push({ provider: providerLabel(cfg), cls: err.cls, error: err.msg });
          emit("failed", { provider: providerLabel(cfg), reason: err.msg, permanent: false });
          if (idx + 1 < chain.length) emit("fallback", { from: providerLabel(cfg), to: providerLabel(chain[idx + 1]), reason: err.msg });
          return runChain(idx + 1);
        });
      }
      return tryOnce().then(function (r) { if (r && r.ok) return r; return null; });
    }

    return { run: function () { return runChain(0); }, stop: function () { controller.abort(); } , signal: controller.signal };
  };

  function buildFailureMessage(failed) {
    if (!failed.length) return "No AI provider is connected yet. Open the AI Chat tab and press Enable AI (paste any provider's API key), or manage keys under AI Providers.";
    return "All " + failed.length + " configured provider(s) failed:\n" + failed.map(function (f) { return "  \u2022 " + f.provider + " \u2014 " + f.error; }).join("\n");
  }

  function sanitizeMessages(msgs) {
    return (msgs || []).map(function (m) {
      return { role: m.role || "user", content: sanitize(String(m.content || "")) };
    });
  }

  function delay(ms, signal) {
    return new Promise(function (resolve) {
      if (signal && signal.aborted) { resolve(false); return; }
      var t = setTimeout(function () { resolve(true); }, ms);
      if (signal) signal.addEventListener("abort", function () { clearTimeout(t); resolve(false); }, { once: true });
    });
  }

  // ------------------------------------------------------------------ //
  // AI context builder — real scan data only, sanitized on the way out.
  // ------------------------------------------------------------------ //
  var NUM = function (v, unit, d) { return v === null || v === undefined ? "n/a" : (v / (unit || 1)).toFixed(2) + " " + d; };

  function buildContext(data, opts) {
    var out = [];
    var task = (opts && opts.task) || "general";
    var issue = opts && opts.issue;

    out.push("WEB DOCTOR - REAL SCAN CONTEXT");
    if (data && data.page) {
      try { var u = new URL(data.page.url || ""); out.push("Page: " + u.hostname + u.pathname); } catch (e) { out.push("Page: " + (data.page.url || "(unknown)")); }
      if (data.page.title) out.push("Title: " + data.page.title);
      out.push("Theme: " + (data.page.viewport ? "viewport present" : "no viewport meta"));
    }

    if (data && data.scores) out.push("Health score: " + (typeof data.scores.overall === "number" ? data.scores.overall + "/100" : "n/a"));

    var p = (data && data.performance) || {};
    out.push("-- Performance --");
    var perf = [
      ["LCP", p.largestContentfulPaint, 1, "ms"],
      ["FCP", p.firstContentfulPaint, 1, "ms"],
      ["INP", p.interactionToNextPaint, 1, "ms"],
      ["CLS", p.cumulativeLayoutShift, 1, ""],
      ["TTFB", p.ttfb, 1, "ms"],
      ["Load time", p.loadTime, 1, "ms"]
    ];
    perf.forEach(function (kv) { out.push(kv[0] + ": " + (kv[1] === null || kv[1] === undefined ? "not reported" : kv[1]) + (kv[3] || "")); });
    if (typeof p.resourceCount === "number") out.push("Requests: " + p.resourceCount + "; third-party: " + p.thirdPartyCount);
    if (p.largeResources && p.largeResources.length) {
      out.push("Large resources (>200KB):");
      p.largeResources.slice(0, 8).forEach(function (r) { out.push("  - " + (r.name || "?") + " (" + r.bytes + " bytes, " + (r.type || "?") + ")"); });
    }

    var dom = (data && data.dom) || {};
    out.push("-- DOM --");
    if (dom.totalElements) out.push("Elements: " + dom.totalElements + "; max depth: " + dom.maxDepth);
    if (dom.duplicateIds && dom.duplicateIds.length) out.push("Duplicate IDs: " + dom.duplicateIds.length);
    if (dom.inlineStyleCount) out.push("Inline style attrs: " + dom.inlineStyleCount);

    var seo = (data && data.seo) || {};
    out.push("-- SEO --");
    out.push("Title: " + (seo.hasTitle ? (seo.titleLength + " chars, ok=" + !!seo.titleOk) : "missing"));
    out.push("Meta description: " + (seo.hasDescription ? (seo.descriptionLength + " chars, ok=" + !!seo.descriptionOk) : "missing"));
    out.push("Canonical: " + (seo.hasCanonical ? "set" : "missing") + "; noindex: " + !!seo.hasNoindex);

    var a11y = (data && data.accessibility) || {};
    out.push("-- Accessibility --");
    var a11yKeys = [["imagesMissingAlt", "images missing alt"], ["inputsNoLabel", "inputs without labels"], ["buttonsNoName", "buttons without names"], ["linksNoText", "links without text"], ["iframesNoTitle", "iframes without titles"]];
    a11yKeys.forEach(function (k) { if (a11y[k[0]]) out.push(k[1] + ": " + a11y[k[0]]); });

    var rel = taskToDeps(task);
    if (rel.css && data && data.css) {
      out.push("-- CSS --");
      out.push("Stylesheets: " + (p.cssCount || 0) + " (" + (p.cssBytes || 0) + " bytes); inline style attrs: " + (dom.inlineStyleCount || 0));
    }
    if (rel.js && data && data.javascript) {
      out.push("-- JavaScript --");
      out.push("Script tags: " + (p.scriptTagCount || 0) + " (" + (p.externalScriptCount || 0) + " external); inline bytes: " + (p.inlineScriptBytes || 0));
      if (data.javascript.consoleErrors) out.push("Console errors: " + data.javascript.consoleErrors);
    }
    if (rel.imgs && data && data.images) {
      out.push("-- Images --");
      out.push("Total: " + (data.images.total || 0) + "; with alt: " + (data.images.withAlt || 0));
    }
    if (rel.links && data && data.links) {
      out.push("-- Links --");
      out.push("Total: " + (data.links.total || 0) + "; external: " + (typeof data.links.external === "number" ? data.links.external : "?"));
    }
    if (rel.tech && data && data.technology) {
      var names = [];
      var g = data.technology.groups || {};
      Object.keys(g).forEach(function (k) { (g[k] || []).forEach(function (t) { if (t && t.name) names.push(t.name); }); });
      if (names.length) out.push("-- Technology --\n" + names.slice(0, 12).join(", "));
    }

    if (issue && issue.title) {
      out.push("-- ISSUE BEING DEBUGGED --");
      out.push("Issue: " + issue.title);
      if (issue.desc) out.push("Evidence: " + issue.desc);
      if (issue.rec) out.push("Normal recommendation: " + issue.rec);
      if (issue.category) out.push("Category: " + issue.category);
      if (issue.items && issue.items.length) {
        out.push("Affected elements:");
        issue.items.slice(0, 6).forEach(function (it, n) {
          out.push("  [" + (n + 1) + "] selector=" + (it.selector || "?"));
          if (it.url) out.push("      url=" + it.url);
          if (it.snippet !== undefined && it.snippet !== null) out.push("      html=" + String(it.snippet).slice(0, 320));
        });
      }
    }

    var raw = out.join("\n");
    return AI.sanitize(raw);
  }

  function taskToDeps(task) {
    return {
      css: task === "css" || task === "html" || task === "responsive",
      js: task === "js" || task === "network",
      imgs: task === "images",
      links: task === "links" || task === "seo",
      tech: true
    };
  }

  AI.buildContext = buildContext;
  AI.sanitizeMessages = sanitizeMessages;

  // ------------------------------------------------------------------ //
  // Session context
  // ------------------------------------------------------------------ //
  var session = { history: [], issue: null, task: "general" };

  AI.getSession = function () { return session; };
  AI.setSessionIssue = function (issue) { session.issue = issue; };
  AI.clearSession = function () { session.history = []; session.issue = null; session.task = "general"; };
  AI.pushMessage = function (role, content, meta) {
    session.history.push({ role: role, role_full: role, content: content, meta: meta || {}, at: Date.now() });
    if (session.history.length > 60) session.history = session.history.slice(-60);
    return AI.persistSession();
  };
  AI.truncateHistory = function () {
    // Keep the last 10 messages so context length stays bounded.
    if (session.history.length > 10) session.history = session.history.slice(-10);
    return AI.persistSession();
  };
  AI.persistSession = function () {
    save({ wdAiSession: { history: session.history.slice(0, 30), task: session.task, issue: session.issue } });
  };
  AI.restoreSession = function (stored) {
    if (stored && stored.history) session.history = stored.history.slice();
    if (stored) { session.task = stored.task || "general"; session.issue = stored.issue || null; }
  };

  AI.example = {
    colorFor: function (prov) { return PROVIDERS[prov] ? PROVIDERS[prov].label : prov; }
  };

  window.AICore = AI;
})();