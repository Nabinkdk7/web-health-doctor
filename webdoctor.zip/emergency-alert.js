(function () {
  "use strict";
  if (window.__wdEmergencyAlertInstalled) return;
  window.__wdEmergencyAlertInstalled = true;

  var ALERT_DURATION_MS = 3000;
  var HOST_ID = "wd-emergency-alert-host";
  var MAX_ERRORS = 5;
  var MAX_LISTED_ISSUES = 3;
  var errors = [];
  var alertTimer = null;
  var fadeTimer = null;
  var gestureReplayArmed = false;
  var alertEnabled = true;
  try {
    if (window.chrome && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get("wdEmergencyAlert", function (o) {
        if (o && o.wdEmergencyAlert === "off") alertEnabled = false;
      });
      chrome.storage.onChanged.addListener(function (changes, area) {
        if (area === "local" && changes && changes.wdEmergencyAlert) {
          alertEnabled = changes.wdEmergencyAlert.newValue !== "off";
        }
      });
    }
  } catch (e) {}

  function isTestMode() {
    return window.__wdEmergencyAlertTestMode === true;
  }

  function pageAllowsAutoAlert() {
    try {
      if (window.top !== window.self) return false;
      var protocol = String(window.location.protocol || "");
      if (protocol !== "http:" && protocol !== "https:") return false;
      var href = String(window.location.href || "");
      if (/^(about|chrome|chrome-extension|edge|brave|opera|vivaldi)-[a-z]*:/i.test(href)) return false;
      if (document.documentElement && document.documentElement.hasAttribute("data-wd-emergency-suppress")) return false;
      return true;
    } catch (e) {
      return false;
    }
  }

  function cleanText(value, max) {
    var text = String(value === undefined || value === null ? "" : value);
    text = text.replace(/\s+/g, " ").trim();
    if (text.length > max) text = text.substring(0, max - 1) + "\u2026";
    return text;
  }

  function escapeHtml(value) {
    return cleanText(value, 220)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  // Never count the extension's own injected code as a page defect.
  function isOwnScriptError(event) {
    try {
      var src = "";
      if (event) {
        if (event.filename) src = String(event.filename);
        else if (event.target && event.target.src) src = String(event.target.src);
      }
      if (!src && event && event.reason && event.reason.stack) src = String(event.reason.stack);
      if (!src) return false;
      return src.indexOf("chrome-extension://") !== -1 ||
        /\/content\.js(\?|#|$)/.test(src) ||
        /\/emergency-alert\.js(\?|#|$)/.test(src);
    } catch (e) {
      return false;
    }
  }

  function recordEmergencyError(kind, event) {
    if (errors.length >= MAX_ERRORS) return;
    if (isOwnScriptError(event)) return;
    var detail = "";
    try {
      if (event && event.message) detail = event.message;
      else if (event && event.reason) {
        detail = event.reason && event.reason.message ? event.reason.message : String(event.reason);
      } else if (event && event.target && event.target.tagName) {
        var target = event.target;
        detail = "A " + target.tagName.toLowerCase() + " resource failed to load" +
          (target.src ? ": " + target.src : target.href ? ": " + target.href : ".");
      }
    } catch (e) {
      detail = "An unknown page error occurred.";
    }
    errors.push({ kind: kind, detail: cleanText(detail || "A page script reported an error.", 180) });
  }

  function installErrorTraps() {
    try {
      window.addEventListener("error", function (event) {
        try {
          if (event && event.target && event.target !== window && event.target.tagName) {
            recordEmergencyError("resource", event);
          } else {
            recordEmergencyError("script", event);
          }
        } catch (e) {}
      }, true);
      window.addEventListener("unhandledrejection", function (event) {
        try { recordEmergencyError("promise", event); } catch (e) {}
      });
    } catch (e) {}
  }

  function pageIsSecure() {
    try {
      return String(window.location.protocol || "").toLowerCase() === "https:";
    } catch (e) {
      return false;
    }
  }

  function hasInsecurePasswordForm() {
    try {
      var inputs = document.querySelectorAll('input[type="password"]');
      for (var i = 0; i < inputs.length; i++) {
        var form = inputs[i].form;
        var action = form && form.getAttribute("action");
        if (!pageIsSecure()) return true;
        if (action && /^http:\/\//i.test(action)) return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  function mixedActiveContentCount() {
    if (!pageIsSecure()) return 0;
    try {
      return document.querySelectorAll('script[src^="http://"], iframe[src^="http://"], embed[src^="http://"], object[data^="http://"]').length;
    } catch (e) {
      return 0;
    }
  }

  function horizontalOverflowPx() {
    try {
      var root = document.documentElement;
      if (!root) return 0;
      var scrollWidth = Number(root.scrollWidth || 0);
      var clientWidth = Number(root.clientWidth || window.innerWidth || 0);
      if (!(scrollWidth > 0) || !(clientWidth > 0)) return 0;
      return Math.max(0, scrollWidth - clientWidth);
    } catch (e) {
      return 0;
    }
  }

  function brokenVisibleImageCount() {
    try {
      var images = document.images || document.querySelectorAll("img");
      var broken = 0;
      var limit = Math.min(images.length, 300);
      for (var i = 0; i < limit; i++) {
        var img = images[i];
        if (!img || !img.isConnected) continue;
        // Only completed images can be judged; loading or lazy images are not failures.
        if (img.complete !== true || typeof img.naturalWidth !== "number" || img.naturalWidth !== 0) continue;
        var rect = null;
        try { rect = img.getBoundingClientRect(); } catch (e) { rect = null; }
        if (rect && (rect.width < 4 || rect.height < 4)) continue;
        var src = img.currentSrc || img.src || "";
        if (!src || /^data:/i.test(src)) continue;
        broken++;
      }
      return broken;
    } catch (e) {
      return 0;
    }
  }

  function hasViewportMeta() {
    try {
      return !!document.querySelector('meta[name="viewport"]');
    } catch (e) {
      return true;
    }
  }

  function collectEmergencySignals() {
    var critical = [];
    var high = [];
    try {
      errors.forEach(function (entry) {
        critical.push({
          code: "js-error",
          title: "JavaScript error detected",
          detail: entry.detail
        });
      });

      if (hasInsecurePasswordForm()) {
        critical.push({
          code: "insecure-password",
          title: "Insecure password form",
          detail: "This page asks for a password without a secure HTTPS submission target."
        });
      }

      var mixed = mixedActiveContentCount();
      if (mixed > 0) {
        critical.push({
          code: "mixed-active-content",
          title: "Blocked or unsafe active content",
          detail: mixed + " script, frame, or plugin URL still uses insecure HTTP on this secure page."
        });
      }

      var title = "";
      try { title = document.title || ""; } catch (e) { title = ""; }
      if (!title.trim()) {
        high.push({
          code: "missing-title",
          title: "Missing page title",
          detail: "Search results, tabs, and assistive technology have no usable page name."
        });
      }

      var overflow = horizontalOverflowPx();
      if (overflow > 8) {
        high.push({
          code: "horizontal-overflow",
          title: "Horizontal page overflow",
          detail: "Content extends about " + Math.round(overflow) + "px beyond the viewport width."
        });
      }

      var brokenImages = brokenVisibleImageCount();
      if (brokenImages > 0) {
        high.push({
          code: "broken-images",
          title: "Broken images",
          detail: brokenImages + " visible image" + (brokenImages === 1 ? "" : "s") + " failed to load."
        });
      }

      var narrow = false;
      try { narrow = Number(window.innerWidth || 0) > 0 && Number(window.innerWidth) < 768; } catch (e) { narrow = false; }
      if (narrow && !hasViewportMeta()) {
        high.push({
          code: "missing-viewport",
          title: "Missing mobile viewport",
          detail: "This narrow viewport has no responsive viewport meta tag."
        });
      }

      return { critical: critical, high: high, jsErrors: errors.length };
    } catch (e) {
      return { critical: [], high: [], jsErrors: errors.length, scanError: true };
    }
  }

  function shouldTriggerAlert(signals) {
    if (!signals || signals.scanError) return false;
    return (signals.critical && signals.critical.length > 0) ||
      (signals.high && signals.high.length > 0);
  }

  function getEmergencyCopy(signals) {
    var criticalCount = signals.critical.length;
    var highCount = signals.high.length;
    var title = criticalCount > 0
      ? "Urgent: critical website issue" + (criticalCount + highCount === 1 ? "" : "s") + " need immediate action"
      : "High-priority website issue" + (highCount === 1 ? "" : "s") + " need immediate action";
    var summary = "Web Doctor found " +
      (criticalCount > 0 ? criticalCount + " critical" + (criticalCount === 1 ? "" : "s") : "no critical issues") +
      " and " + highCount + " high-priority finding" + (highCount === 1 ? "" : "s") + ".";
    var items = signals.critical.slice(0, MAX_LISTED_ISSUES)
      .map(function (item) { return { severity: "Critical", title: item.title, detail: item.detail }; })
      .concat(signals.high.slice(0, Math.max(0, MAX_LISTED_ISSUES - Math.min(signals.critical.length, MAX_LISTED_ISSUES)))
        .map(function (item) { return { severity: "High priority", title: item.title, detail: item.detail }; }));
    return { title: title, summary: summary, items: items };
  }

  function alertStyles() {
    return ".wd-alert{pointer-events:auto;display:flex;gap:12px;align-items:flex-start;width:min(420px,calc(100vw - 20px));" +
      "background:#171019;border:1px solid rgba(251,113,133,.55);border-radius:14px;padding:10px 12px 8px;" +
      "box-shadow:0 18px 50px rgba(0,0,0,.48),0 0 0 3px rgba(251,113,133,.12);color:#fff;" +
      "font-family:inherit;opacity:1;transition:opacity .18s ease}" +
      ".wd-alert.is-leaving{opacity:0}" +
      ".wd-badge{flex:0 0 auto;width:30px;height:30px;border-radius:999px;display:flex;align-items:center;justify-content:center;" +
      "font-weight:800;font-size:18px;color:#fff;background:linear-gradient(135deg,#fb7185,#e11d48);}" +
      ".wd-main{flex:1 1 auto;min-width:0}" +
      ".wd-kicker{font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#fda4af;margin-bottom:2px}" +
      ".wd-title{font-size:13px;font-weight:800;line-height:1.25;margin:0 0 3px}" +
      ".wd-msg{font-size:11.5px;line-height:1.45;color:#ffe4e6;margin:0 0 7px}" +
      ".wd-items{list-style:none;margin:0 0 8px;padding:0;display:grid;gap:5px}" +
      ".wd-items li{font-size:12px;line-height:1.4;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);" +
      "border-radius:9px;padding:6px 8px}" +
      ".wd-sev{display:inline-block;font-size:10px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;" +
      "border-radius:999px;padding:1px 7px;margin-right:6px;color:#fff;background:#e11d48}" +
      ".wd-sev.high{background:#b45309}" +
      ".wd-detail{display:block;color:#ffe4e6;opacity:.92;margin-top:2px}" +
      ".wd-meta{display:flex;align-items:center;gap:8px}" +
      ".wd-count{font-size:11px;color:#fecdd3}" +
      ".wd-close{margin-left:auto;flex:0 0 auto;border:1px solid rgba(255,255,255,.22);background:transparent;color:#fff;" +
      "border-radius:999px;font-size:11px;font-weight:700;padding:4px 10px;cursor:pointer}" +
      ".wd-close:hover{background:rgba(255,255,255,.12)}" +
      ".wd-bar{height:3px;border-radius:999px;background:rgba(255,255,255,.16);margin-top:8px;overflow:hidden}" +
      ".wd-bar span{display:block;height:100%;width:100%;background:#fb7185;transform-origin:left;animation:wdAlertShrink 3s linear forwards}" +
      "@keyframes wdAlertShrink{from{transform:scaleX(1)}to{transform:scaleX(0)}}";
  }

  function removeHost() {
    try {
      var host = document.getElementById(HOST_ID);
      if (host && host.parentNode) host.parentNode.removeChild(host);
    } catch (e) {}
  }

  function dismissEmergencyAlert() {
    if (alertTimer) { clearTimeout(alertTimer); alertTimer = null; }
    if (fadeTimer) { clearTimeout(fadeTimer); fadeTimer = null; }
    try {
      var host = document.getElementById(HOST_ID);
      if (!host) return false;
      var card = null;
      try {
        card = host.shadowRoot ? host.shadowRoot.querySelector(".wd-alert") : host.querySelector(".wd-alert");
      } catch (e) { card = null; }
      if (card) card.classList.add("is-leaving");
      fadeTimer = setTimeout(removeHost, 190);
      return true;
    } catch (e) {
      removeHost();
      return true;
    }
  }

  function showEmergencyOverlay(signals, options) {
    options = options || {};
    if (!alertEnabled) return { shown: false, reason: "disabled-by-setting" };
    if (!shouldTriggerAlert(signals)) return { shown: false, reason: "no-trigger" };
    if (window.__wdEmergencyAlertShown && !options.force) return { shown: false, reason: "already-shown" };
    if (!document.documentElement) return { shown: false, reason: "no-document" };

    var durationMs = typeof options.durationMs === "number"
      ? options.durationMs
      : (typeof window.__wdEmergencyAlertDurationMs === "number" ? window.__wdEmergencyAlertDurationMs : ALERT_DURATION_MS);
    if (!(durationMs > 0)) durationMs = ALERT_DURATION_MS;

    var copy = getEmergencyCopy(signals);
    removeHost();
    if (alertTimer) { clearTimeout(alertTimer); alertTimer = null; }

    var host = document.createElement("div");
    host.id = HOST_ID;
    host.setAttribute("data-wd-own", "1");
    host.setAttribute("role", "presentation");
    host.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:2147483647;pointer-events:none;" +
      "display:flex;justify-content:center;padding:12px;box-sizing:border-box;";

    var itemsHtml = copy.items.map(function (item) {
      return '<li><span class="wd-sev' + (item.severity === "High priority" ? " high" : "") + '">' +
        escapeHtml(item.severity) + "</span><strong>" + escapeHtml(item.title) + "</strong>" +
        '<span class="wd-detail">' + escapeHtml(item.detail) + "</span></li>";
    }).join("");

    var root = host.shadowRoot || host;
    try {
      if (host.attachShadow) root = host.attachShadow({ mode: "open" });
    } catch (e) {
      root = host;
    }
    root.innerHTML = "<style>" + alertStyles() + "</style>" +
      '<div class="wd-alert" role="alert" aria-live="assertive">' +
      '<div class="wd-badge" aria-hidden="true">!</div>' +
      '<div class="wd-main">' +
      '<div class="wd-kicker">Web Doctor emergency alert</div>' +
      '<p class="wd-title">' + escapeHtml(copy.title) + "</p>" +
      '<p class="wd-msg">' + escapeHtml(copy.summary) + " This notice closes automatically.</p>" +
      '<ul class="wd-items">' + itemsHtml + "</ul>" +
      '<div class="wd-meta"><span class="wd-count">Auto closes in 4 seconds</span>' +
      '<button class="wd-close" type="button" data-wd-alert-close="1">Dismiss</button></div>' +
      '<div class="wd-bar" aria-hidden="true"><span></span></div>' +
      "</div></div>";

    try {
      var closeButton = root.querySelector('[data-wd-alert-close="1"]');
      if (closeButton) closeButton.addEventListener("click", dismissEmergencyAlert);
    } catch (e) {}

    try {
      document.documentElement.appendChild(host);
    } catch (e) {
      return { shown: false, reason: "append-failed" };
    }

    window.__wdEmergencyAlertShown = true;
    alertTimer = setTimeout(dismissEmergencyAlert, durationMs);
    requestEmergencyChime();
    return { shown: true, reason: "shown", durationMs: durationMs };
  }

  function getAudioContextConstructor() {
    try {
      return window.AudioContext || window.webkitAudioContext || null;
    } catch (e) {
      return null;
    }
  }

  // Modern emergency chime: a short rising E5 -> B5 -> E6 motif with soft
  // sine voices, gentle attack/decay, and a warm low-pass. Deliberately free
  // of pitch slides, square waves, and loud repeating siren cycles.
  function playEmergencyChimeNow(ctx) {
    if (!ctx) return { played: false, reason: "no-context" };
    try {
      var now = ctx.currentTime || 0;
      var master = ctx.createGain();
      master.gain.value = 0.13;
      var filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 3400;
      master.connect(filter);
      filter.connect(ctx.destination);

      function note(freq, at, dur, gain) {
        var osc = ctx.createOscillator();
        var voice = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now + at);
        voice.gain.setValueAtTime(0.0001, now + at);
        voice.gain.exponentialRampToValueAtTime(gain, now + at + 0.018);
        voice.gain.exponentialRampToValueAtTime(0.0001, now + at + dur);
        osc.connect(voice);
        voice.connect(master);
        osc.start(now + at);
        osc.stop(now + at + dur + 0.05);
      }

      note(659.26, 0, 0.2, 0.16);    // E5
      note(987.77, 0.1, 0.22, 0.14); // B5
      note(1318.51, 0.2, 0.32, 0.18);// E6
      return { played: true, reason: "played", notes: [659.26, 987.77, 1318.51] };
    } catch (e) {
      return { played: false, reason: "play-failed" };
    }
  }

  function isSoundEnabledSync() {
    if (typeof window.__wdEmergencyAlertSound === "boolean") return window.__wdEmergencyAlertSound;
    return true;
  }

  function requestEmergencyChime() {
    if (isSoundEnabledSync() === false) return { attempted: false, played: false, reason: "disabled" };
    var Ctor = getAudioContextConstructor();
    if (!Ctor) return { attempted: false, played: false, reason: "unsupported" };

    var readSetting = function (done) {
      if (typeof window.__wdEmergencyAlertSound === "boolean") {
        done(window.__wdEmergencyAlertSound);
        return;
      }
      try {
        if (window.chrome && chrome.storage && chrome.storage.local && chrome.storage.local.get) {
          chrome.storage.local.get("wdSound", function (stored) {
            try {
              done(!stored || stored.wdSound !== "off");
            } catch (e) {
              done(true);
            }
          });
          return;
        }
      } catch (e) {}
      done(true);
    };

  function userGestured() {
    try {
      if (navigator.userActivation) {
        return !!(navigator.userActivation.isActive || navigator.userActivation.hasBeenActive);
      }
    } catch (e) {}
    return false;
  }

  // One-shot: on the next pointer/key gesture, build the context (allowed
  // there, so no console warning) and play the chime while the overlay is
  // still up. Used when the alert fires with no gesture in progress.
  function armGestureCreate() {
    if (gestureReplayArmed) return;
    gestureReplayArmed = true;
    var create = function () {
      gestureReplayArmed = false;
      try {
        window.removeEventListener("pointerdown", create);
        window.removeEventListener("keydown", create);
        window.removeEventListener("touchend", create);
      } catch (e) {}
      try {
        if (!document.getElementById(HOST_ID)) return;
        var C2 = getAudioContextConstructor();
        if (!C2) return;
        var ctx2 = null;
        try { ctx2 = new C2(); } catch (e) { ctx2 = null; }
        if (!ctx2) return;
        var play = function () { try { playEmergencyChimeNow(ctx2); } catch (e) {} };
        if (ctx2.state === "running") { play(); return; }
        try {
          var r2 = ctx2.resume();
          if (r2 && typeof r2.then === "function") r2.then(play, function () { armGestureReplay(ctx2); });
          else armGestureReplay(ctx2);
        } catch (e) { armGestureReplay(ctx2); }
      } catch (e) {}
    };
    try {
      window.addEventListener("pointerdown", create);
      window.addEventListener("keydown", create);
      window.addEventListener("touchend", create);
      setTimeout(function () {
        if (!gestureReplayArmed) return;
        gestureReplayArmed = false;
        try {
          window.removeEventListener("pointerdown", create);
          window.removeEventListener("keydown", create);
          window.removeEventListener("touchend", create);
        } catch (e) {}
      }, ALERT_DURATION_MS);
    } catch (e) {
      gestureReplayArmed = false;
    }
  }

    readSetting(function (enabled) {
      if (!enabled) return;
      // No gesture in progress (typical: the alert fired on page load). Do
      // NOT construct or resume an AudioContext here — Chrome would log "The
      // AudioContext was not allowed to start..." on the errors page. Defer
      // to the next real gesture instead; the overlay stays up 4 seconds.
      if (!userGestured()) { armGestureCreate(); return; }
      var ctx = null;
      try { ctx = new Ctor(); } catch (e) { ctx = null; }
      if (!ctx) return;
      try {
        if (ctx.state === "suspended") {
          var resumed = null;
          try { resumed = ctx.resume(); } catch (e) { resumed = null; }
          if (resumed && typeof resumed.then === "function") {
            resumed.then(function () {
              try {
                if (ctx.state === "running") playEmergencyChimeNow(ctx);
                else armGestureReplay(ctx);
              } catch (e) {}
            }, function () { armGestureReplay(ctx); });
          } else {
            armGestureReplay(ctx);
          }
          return;
        }
        playEmergencyChimeNow(ctx);
      } catch (e) {}
    });
    return { attempted: true, played: false, reason: "requested" };
  }

  function armGestureReplay(ctx) {
    if (gestureReplayArmed) return;
    gestureReplayArmed = true;
    var replay = function () {
      gestureReplayArmed = false;
      try {
        window.removeEventListener("pointerdown", replay);
        window.removeEventListener("keydown", replay);
        window.removeEventListener("touchend", replay);
      } catch (e) {}
      try {
        if (!document.getElementById(HOST_ID)) return;
        if (ctx.state === "suspended") {
          try { ctx.resume(); } catch (e) {}
        }
        if (ctx.state !== "suspended") playEmergencyChimeNow(ctx);
      } catch (e) {}
    };
    try {
      window.addEventListener("pointerdown", replay);
      window.addEventListener("keydown", replay);
      window.addEventListener("touchend", replay);
      setTimeout(function () {
        if (!gestureReplayArmed) return;
        gestureReplayArmed = false;
        try {
          window.removeEventListener("pointerdown", replay);
          window.removeEventListener("keydown", replay);
          window.removeEventListener("touchend", replay);
        } catch (e) {}
      }, ALERT_DURATION_MS);
    } catch (e) {
      gestureReplayArmed = false;
    }
  }

  function runEmergencyCheck() {
    if (window.__wdEmergencyAlertShown) return { shown: false, reason: "already-shown" };
    if (!pageAllowsAutoAlert()) return { shown: false, reason: "page-skipped" };
    var signals = collectEmergencySignals();
    return showEmergencyOverlay(signals);
  }

  function scheduleEmergencyCheck() {
    var scheduled = false;
    var kick = function () {
      if (scheduled) return;
      scheduled = true;
      try {
        if (document.hidden) {
          var onVisible = function () {
            try { document.removeEventListener("visibilitychange", onVisible); } catch (e) {}
            setTimeout(runEmergencyCheck, 650);
          };
          document.addEventListener("visibilitychange", onVisible);
          return;
        }
      } catch (e) {}
      setTimeout(runEmergencyCheck, 750);
    };

    try {
      if (document.readyState === "complete") {
        kick();
        return;
      }
      window.addEventListener("DOMContentLoaded", kick, { once: true });
      window.addEventListener("load", function () {
        if (!window.__wdEmergencyAlertShown) setTimeout(runEmergencyCheck, 450);
      }, { once: true });
      // Fallback for pages whose load event is delayed or already missed.
      setTimeout(function () {
        if (!window.__wdEmergencyAlertShown && !document.hidden) runEmergencyCheck();
      }, 5000);
    } catch (e) {}
  }

  window.__wdEmergencyAlert = {
    version: 1,
    durationMs: ALERT_DURATION_MS,
    collectEmergencySignals: collectEmergencySignals,
    shouldTriggerAlert: shouldTriggerAlert,
    getEmergencyCopy: getEmergencyCopy,
    showEmergencyOverlay: showEmergencyOverlay,
    dismissEmergencyAlert: dismissEmergencyAlert,
    playEmergencyChimeNow: playEmergencyChimeNow,
    requestEmergencyChime: requestEmergencyChime,
    runEmergencyCheck: runEmergencyCheck
  };

  installErrorTraps();
  if (!isTestMode()) {
    if (pageAllowsAutoAlert()) scheduleEmergencyCheck();
  }
})();
